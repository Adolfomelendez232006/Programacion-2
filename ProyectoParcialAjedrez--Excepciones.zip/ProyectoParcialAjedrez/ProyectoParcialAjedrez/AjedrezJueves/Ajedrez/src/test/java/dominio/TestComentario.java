package dominio;

import org.example.dominio.Comentario;

public class TestComentario {
    public static void main(String[] args) {
        Comentario comentario = new Comentario("Juan", "Me gusta mucho la aplicacion");

        System.out.println(comentario);
        System.out.println();

        comentario.registrarComentario("Ana", "Excelente aplicacion, muy útil!");
        comentario.registrarComentario("Carlos", "Me gustó mucho, gracias por construir");
        comentario.registrarComentario("Pedro", "Totalmente de acuerdo con el funcionamiento");
        comentario.registrarComentario("Laura", "Interesante aplicacion para ampliar el conocimiento");
        System.out.println();

        System.out.println("Lista de comentarios:");
        comentario.listarComentarios();
        System.out.println(comentario.getCantidadComentarios());
        System.out.println();


        System.out.println("Ingrese el indice del comentario a eliminar");
        comentario.eliminarComentario(2);
        System.out.println();

        System.out.println("Lista después de eliminar:");
        comentario.listarComentarios();
        System.out.println("Cantidad actual: " + comentario.getCantidadComentarios());
        System.out.println();

        System.out.println("Autor: " + comentario.getAutor());
        System.out.println("Contenido: " + comentario.getContenido());
        System.out.println("Fecha: " + comentario.getFecha());
        System.out.println();

        System.out.println("Modificando autor y contenido:");
        comentario.setAutor("Juan Carlos");
        comentario.setContenido("Este es el comentario esta actualizado");
        System.out.println("Comentario modificado: " + comentario);
        System.out.println();

        System.out.println("Lista de comentarios:");
        comentario.listarComentarios();
        System.out.println(comentario.getCantidadComentarios());
        System.out.println();

    }
}
