package org.example.dominio;

import org.example.ordenamientos.OrdenarComentarioFecha;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Representa un jugador en el sistema, almacenando su informacion personal,
 * nivel de conocimiento, fecha de registro y recompensas obtenidas
 *
 * <p>la clase incliye con validaciones para garantixar la integridad de los
 * datos del jugador al momento de su creacion.</p>
 * @autores Adolfo Melendes- Daniel Riofrio - Karol Gomez- Dana Palacios
 */
public class Jugador implements Comparable<Jugador>{
    public String nombre;
    private String apellido;
    private final int idJugador;
    private String conocimientoDeJuego;
    private LocalDateTime fechaDeRegistro;
    private static List<SolicitudDeRecompensa> recompensas;
    private static List<Comentario> comentarios;
    private static List<Recompensa> recompensasObtenidas; //Revisar
    private List<Logro> logros;
    private int puntosAcumulados;
    private Genero genero;
    private static int contadorComentarios;
    private int contadorRecompensas;
    private int contadorRecompensasObtenidas;
    private int contadorLogros;

    Comentario comen = new Comentario();

    public Jugador() {
        this(1, "sinnombre", "sinapellido", "intermedio", LocalDateTime.now(), Genero.OTRO);
    }
    /**
     * Constructor por defecto que inicializa un jugador con valores por defecto
     */
    public Jugador(int i, String nombre, String apellido, String conocimiento, LocalDateTime now) {
        this.idJugador = i;
        this.nombre = nombre;
        this.apellido = apellido;
        this.conocimientoDeJuego = conocimiento;
        this.fechaDeRegistro = now;
        inicializar();
    }
    /**
     * Constructor con parámetros
     */
    public Jugador(int idJugador, String nombre,String apellido,String conocimientoDeJuego, LocalDateTime fechaDeRegistro, Genero genero){
        // Validar el ID del jugador
        if (idJugador <= 0) {
            throw new IllegalArgumentException("El ID del jugador debe ser un número positivo.");
        }

        // Validación del nombre
        if (nombre == null || !nombre.matches("[a-zA-Z]+")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras");
        }
        if (nombre.length() < 2) {
            throw new IllegalArgumentException("El nombre debe tener al menos 2 caracteres");
        }

        //Validacion de apellido
        if (apellido == null || !apellido.matches("[a-zA-Z]+")) {
            throw new IllegalArgumentException("El apellido solo puede contener letras");
        }

        //Validacion de conocimiento de juego
        if (conocimientoDeJuego == null || !conocimientoDeJuego.matches("(?i)(principiante|intermedio|avanzado)")) {
            throw new IllegalArgumentException("El nivel de conocimiento debe ser 'principiante', 'intermedio' o 'avanzado'");
        }

        // Validación del género
        if (genero == null) {
            throw new IllegalArgumentException("El género es obligatorio.");
        }

        this.idJugador = idJugador;
        this.nombre = nombre;
        this.apellido = apellido;
        this.conocimientoDeJuego = conocimientoDeJuego;
        this.fechaDeRegistro = fechaDeRegistro;
        this.genero=genero;
        this.recompensasObtenidas = new ArrayList<>();
        this.recompensas = new ArrayList<>();
        this.comentarios = new ArrayList<>();
        this.logros = new ArrayList<>();
        inicializar();
        inicializarComentarios();
    }
    public String inicializar() {
        StringBuilder resul=new StringBuilder();
        try{
            Recompensa re = new Logro("Ganador 100 veces", "Logro obtenido por ganar 100 partidas", 500, true);
            Recompensa re1 = new Logro("Ganador 50 veces", "Logro obtenido por ganar 50 partidas", 250, true);
            Recompensa re2 = new Logro("Ganador 200 veces", "Logro obtenido por ganar 200 partidas", 700, false);
            Recompensa re3 = new Logro("Invicto x10", "Logro obtenido por ganar 10 partidas seguidas", 400, false);
            Recompensa re4 = new Logro("Empezando con pie derecho", "Logro obtenido por ganar tu primera partida", 100, true);
            agregarSolicitudRecompensa(EstadoDeSolicitud.APROBADA, re);
            agregarSolicitudRecompensa(EstadoDeSolicitud.PENDIENTE, re1);
            agregarSolicitudRecompensa(EstadoDeSolicitud.PROCESADA, re2);
            agregarSolicitudRecompensa(EstadoDeSolicitud.RECHAZADA, re3);
            agregarSolicitudRecompensa(EstadoDeSolicitud.APROBADA, re4);

        }catch (Exception e){
            resul.append("Error al Inicializar").append(e.getMessage());
        }
        return resul.toString();
    }

    /**
     * Obtiene el Id del jugador
     * @return el identificador unico del jugador
     */

    public int getIdJugador(){return idJugador;}

    /**
     * Obtiene el nombre del jugador
     * @return El nombre actual del jugador
     */
    public String getNombre(){return nombre;}

    /**
     * Establece el nombre del jugador
     * @param nombre
     */
    public void setNombre(String nombre){this.nombre = nombre;}

    /**
     * Obtiene el apellido del juagro
     * @return El apellido actual del jugador
     */
    public String getApellido(){
        return apellido;
    }

    /**
     * Establece el apellido del jugador
     * @param apellido
     */
    public void setApellido(String apellido){
        this.apellido = apellido;
    }

    /**
     * Obtiene el nivel de conocimiento del juego.
     * @return El nivel actual de conocimiento
     */
    public String getConocimientoDeJuego(){
        return conocimientoDeJuego;
    }

    /**
     * Establece el nivel de conocimiento del juego
     * @param conocimientoDeJuego
     */
    public void setConocimientoDeJuego(String conocimientoDeJuego){
        this.conocimientoDeJuego = conocimientoDeJuego;
    }

    /**
     * Obtiene la fecha de registro del jugador
     * @return la fecha y hora en que se registro el jugador
     */
    public LocalDateTime getFechaDeRegistro(){
        return fechaDeRegistro;
    }

    /**
     * Actualiza la fecha de registro con la fecha y hora actuales
     */
    public void setFechaDeRegistro(){
        this.fechaDeRegistro = LocalDateTime.now();
    }

    public int getPuntosAcumulados() { return puntosAcumulados; }
    public void setPuntosAcumulados(int puntosAcumulados) {
        this.puntosAcumulados = Math.max(0, puntosAcumulados);
    }
    /**
     * Obtiene copia de los comentarios activos
     */
    public List<Comentario> getComentarios(){
        return new ArrayList<>(comentarios);
    }
    /**
     * Obtiene copia de las recompensas activas
     */
    public List<SolicitudDeRecompensa> getRecompensas(){
        return new ArrayList<>(recompensas);
    }
    /**
     * Valida si un objeto ya existe en las asociaciones
     */
    public static boolean validarDuplicado(Object obj){
        if (obj == null) return false;

        if (obj instanceof Comentario) {
            return comentarios.equals(obj);
        } else if (obj instanceof SolicitudDeRecompensa) {
            return recompensas.equals(obj);
        } else if (obj instanceof Recompensa) {
            return recompensasObtenidas.equals(obj);
        }
        return false;
    }

    /**
     * Calcula el total de puntos acumulados por todas las recompensas
     * @return La suma total de puntos de todas las recompensas
     */
    public int calcularTotalPuntos() {
        int total = 0;
        for (Recompensa r : this.recompensasObtenidas) {
            if (r != null) {
                total += r.getPuntos();
            }
        }
        for (Logro l : this.logros) {
            if (l != null && l.getCompletado()) {
                total += l.getPuntos();
            }
        }
        this.puntosAcumulados = total;
        return total;
    }
    /**
     * Registra una recompensa obtenida por el jugador
     * @param recompensa la recompensa a registrar
     */
    public void registrarRecompensa(Recompensa recompensa) {
        if (recompensa != null && this.contadorRecompensasObtenidas < this.recompensasObtenidas.size()) {
            // Verificar si la recompensa ya existe
            boolean existe = false;
            for (int i = 0; i < this.contadorRecompensasObtenidas; i++) {
                if (this.recompensasObtenidas.get(i) != null && this.recompensasObtenidas.get(i).equals(recompensa)) {
                    existe = true;
                    break;
                }
            }
            if (!existe) {
                this.recompensasObtenidas.add(recompensa);
                this.contadorRecompensasObtenidas++;
                this.calcularTotalPuntos(); // Actualizar puntos automáticamente
            }
        }
    }
    /**
     * Obtiene una copia de las recompensas obtenidas
     * @return array con las recompensas obtenidas
     */
    public List<Recompensa> getRecompensasObtenidas() {
        return new ArrayList<>(recompensasObtenidas);
    }

    /**
     * Registra un logro para el jugador
     * @param logro el logro a registrar
     */
    public void registrarLogro(Logro logro) {
        if (logro != null && !logros.equals(logro)) {
            this.logros.add(logro);
        }
    }
    /**
     * Obtiene una copia de los logros del jugador
     * @return array con los logros
     */
    public List<Logro> getLogros() {
        return new ArrayList<>(logros);
    }

    /**
     * Completa un logro específico por nombre
     * @param nombreLogro nombre del logro a completar
     * @return true si se completó exitosamente, false en caso contrario
     */
    public boolean completarLogro(String nombreLogro) {
        if (nombreLogro == null || nombreLogro.trim().isEmpty()) {
            return false;
        }
        for (int i = 0; i < this.contadorLogros; i++) {
            Logro logro = this.logros.get(i);
            if (logro != null && logro.getNombre().equalsIgnoreCase(nombreLogro.trim()) && !logro.getCompletado()) {
                logro.completarLogro(logro.getNombre());
                this.calcularTotalPuntos();
                return true;
            }
        }
        return false;
    }

    /**
     * Obtiene la cantidad de logros completados
     * @return número de logros completados
     */
    public int getLogrosCompletados() {
        int completados = 0;
        for (int i = 0; i < this.contadorLogros; i++) {
            if (this.logros.get(i) != null && this.logros.get(i).getCompletado()) {
                completados++;
            }
        }
        return completados;
    }
    /**
     * Obtiene solo las recompensas aprobadas
     */
    public SolicitudDeRecompensa[] obtenerRecompensasAprobadas() {
        List<SolicitudDeRecompensa> aprobadasList = new ArrayList<>();
        for (SolicitudDeRecompensa solicitud : recompensas) {
            if (solicitud != null && solicitud.estaAprobada()) {
                aprobadasList.add(solicitud);
            }
        }
        return aprobadasList.toArray(new SolicitudDeRecompensa[0]);
    }
    /**
     * Muestra todas las recompensas del jugador
     * @return String con la información de todas las recompensas
     */
    public String mostrarRecompensas() {
        StringBuilder sb = new StringBuilder();

        // Verificar que el nombre no sea null
        String nombreCompleto = (this.nombre != null ? this.nombre : "Sin nombre") +
                " " + (this.apellido != null ? this.apellido : "Sin apellido");

        sb.append("=== RECOMPENSAS DE ").append(nombreCompleto).append(" ===\n\n");

        // SECCIÓN 1: SOLICITUDES DE RECOMPENSA
        sb.append(" SOLICITUDES DE RECOMPENSA (").append(this.contadorRecompensas).append("):\n");
        if (this.contadorRecompensas == 0) {
            sb.append(" No tiene solicitudes de recompensa.\n");
        } else {
            for (int i = 0; i < this.contadorRecompensas; i++) {
                if (this.recompensas.get(i) != null) {
                    SolicitudDeRecompensa solicitud = this.recompensas.get(i);
                    sb.append((i + 1)).append(". ");

                    if (solicitud.estaAprobada()) {
                        sb.append(" APROBADA - ");
                    } else {
                        sb.append(" PENDIENTE - ");
                    }

                    sb.append(solicitud.toString()).append("\n");
                }
            }
        }

        sb.append("\n");

        // SECCIÓN 2: RECOMPENSAS OBTENIDAS
        sb.append(" RECOMPENSAS OBTENIDAS (").append(this.contadorRecompensasObtenidas).append("):\n");
        if (this.contadorRecompensasObtenidas == 0) {
            sb.append(" No tiene recompensas obtenidas.\n");
        } else {
            int puntosDeRecompensas = 0;
            for (int i = 0; i < this.contadorRecompensasObtenidas; i++) {
                if (this.recompensasObtenidas.get(i) != null) {
                    Recompensa recompensa = this.recompensasObtenidas.get(i);
                    sb.append((i + 1)).append(". 🎁 ")
                            .append(recompensa.getNombre())
                            .append(" - ").append(recompensa.getPuntos()).append(" puntos\n");

                    if (recompensa.getDescripcion() != null && !recompensa.getDescripcion().trim().isEmpty()) {
                        sb.append("   📝 ").append(recompensa.getDescripcion()).append("\n");
                    }

                    puntosDeRecompensas += recompensa.getPuntos();
                }
            }
            sb.append("\n💎 Total puntos de recompensas: ").append(puntosDeRecompensas).append("\n");
        }

        return sb.toString();
    }

    /**
     * Muestra solo las recompensas aprobadas del jugador
     * @return String con la información de las recompensas aprobadas
     */

    public String mostrarRecompensasAprobadas() {
        SolicitudDeRecompensa[] aprobadas = this.obtenerRecompensasAprobadas();

        if (aprobadas.length == 0) {
            return "El jugador " + this.nombre + " " + this.apellido + " no tiene recompensas aprobadas.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Recompensas aprobadas de ").append(this.nombre).append(" ").append(this.apellido).append(":\n");

        for (SolicitudDeRecompensa recompensa : aprobadas) {
            sb.append("- ").append(recompensa.toString()).append("\n");
        }

        return sb.toString();
    }

    /**
     * Muestra los logros alcanzados por el jugador
     * @return String con información de los logros
     */
    public String mostrarLogros() {
        StringBuilder sb = new StringBuilder();

        // Verificar que el nombre no sea null
        String nombreCompleto = (this.nombre != null ? this.nombre : "Sin nombre") +
                " " + (this.apellido != null ? this.apellido : "Sin apellido");

        sb.append("=== LOGROS DE ").append(nombreCompleto).append(" ===\n");
        sb.append("Puntos totales acumulados: ").append(this.puntosAcumulados).append("\n");
        sb.append("Total de logros registrados: ").append(this.contadorLogros).append("\n");
        sb.append("Logros completados: ").append(this.getLogrosCompletados()).append("\n");
        sb.append("Recompensas obtenidas: ").append(this.contadorRecompensasObtenidas).append("\n");
        sb.append("Comentarios realizados: ").append(this.contadorComentarios).append("\n");
        sb.append("Nivel de conocimiento: ").append(this.conocimientoDeJuego != null ? this.conocimientoDeJuego : "No definido").append("\n\n");

        // Mostrar cada logro individual
        if (this.contadorLogros == 0) {
            sb.append("❌ No tiene logros registrados.\n");
        } else {
            sb.append("📋 DETALLE DE LOGROS:\n");
            for (int i = 0; i < this.contadorLogros; i++) {
                if (this.logros.get(i) != null) {
                    Logro logro = this.logros.get(i);
                    sb.append((i + 1)).append(". ");

                    if (logro.getCompletado()) {
                        sb.append("✅ ");
                    } else {
                        sb.append("⏳ ");
                    }

                    sb.append(logro.getNombre())
                            .append(" - ").append(logro.getPuntos()).append(" puntos")
                            .append(" (").append(logro.getCompletado() ? "COMPLETADO" : "PENDIENTE").append(")\n");

                    if (logro.getDescripcion() != null && !logro.getDescripcion().trim().isEmpty()) {
                        sb.append("   📝 ").append(logro.getDescripcion()).append("\n");
                    }
                    sb.append("\n");
                }
            }
        }

        return sb.toString();
    }

    public String seleccionarModoDeJuego(){
        String modoSeleccionado;
        switch (conocimientoDeJuego.toLowerCase()) {
            case "principiante":
            case "basico":
                modoSeleccionado = "Modo Fácil";
                break;
            case "intermedio":
                modoSeleccionado = "Modo Normal";
                break;
            case "avanzado":
            case "experto":
                modoSeleccionado = "Modo Difícil";
                break;
            default:
                modoSeleccionado = "Modo Normal"; // Por defecto
                break;
        }

        System.out.println("Jugador " + nombre + " ha seleccionado: " + modoSeleccionado);
        return modoSeleccionado;
    }
    /**
     * Sobrecarga: Agregar comentario por texto
     */
    public static boolean agregarComentario(String texto){
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("El texto del comentario no puede estar vacío");
        }
        if (contadorComentarios < comentarios.size()) {
            Comentario nuevoComentario = new Comentario();

            if (!validarDuplicado(nuevoComentario)) {
                comentarios.add(nuevoComentario);
                contadorComentarios++;
                return true;
            }
        }
        return false;
    }
    /**
     * Sobrecarga: Agregar comentario por objeto
     */
    public static boolean agregarComentario(Comentario comentario) {
        if (comentario==null){
            return false;
        }
        if(!comentarios.equals(comentario)){
            return comentarios.add(comentario);
        }
        return false;
    }
    /**
     * Agrega una solicitud de recompensa por parámetros
     */
    public boolean agregarSolicitudRecompensa(EstadoDeSolicitud tipoRecompensa, Recompensa puntosRequeridos){
        if (tipoRecompensa == null) {
            throw new IllegalArgumentException("El tipo de recompensa no puede estar vacío");
        }
        if (contadorRecompensas < recompensas.size()) {
            SolicitudDeRecompensa nuevaRecompensa = new SolicitudDeRecompensa();

            if (!validarDuplicado(nuevaRecompensa)) {
                recompensas.add(nuevaRecompensa);
                contadorRecompensas++;
                return true;
            }
        }
        return false;
    }
    /**
     * Agrega una solicitud de recompensa por objeto
     */
    public boolean agregarSolicitudRecompensa(SolicitudDeRecompensa recompensa) {
        if (recompensa == null) {
            throw new IllegalArgumentException("La recompensa no puede ser null");
        }

        if (contadorRecompensas < recompensas.size()) {
            if (!validarDuplicado(recompensa)) {
                recompensas.add(recompensa);
                contadorRecompensas++;
                return true;
            }
        }
        return false;
    }

    public boolean aprobarRecompensa(int idRecompensa){
        for (SolicitudDeRecompensa recompensa : recompensas) {
            if (recompensa != null && recompensa.getId() == idRecompensa) {
                recompensa.estaAprobada();
                return true;
            }
        }
        return false;
    }

    public boolean eliminarComentario(int indice) {
        if (indice >= 0 && indice < contadorComentarios) {
            // Mover elementos hacia la izquierda
            for (int i = indice; i < contadorComentarios - 1; i++) {
                comentarios.set(i, comentarios.get(i + 1));
            }
            contadorComentarios--;
            comentarios.set(contadorComentarios, null); // limpiar referencia
            return true;
        }
        return false;
    }

    public boolean eliminarSolicitudRecompensa(int idRecompensa) {
        for (int i = 0; i < contadorRecompensas; i++) {
            if (recompensas.get(i) != null && recompensas.get(i).getId() == idRecompensa) {
                for (int j = i; j < contadorRecompensas - 1; j++) {
                    recompensas.set(j, recompensas.get(j + 1));
                }
                contadorRecompensas--;
                recompensas.set(contadorRecompensas, null);
                return true;
            }
        }
        return false;
    }

    public boolean actualizarComentario(int indice, String nuevoTexto) {
        if (indice >= 0 && indice < contadorComentarios) {
            comentarios.get(indice).setContenido(nuevoTexto);
            comentarios.get(indice).getFecha(); // actualizar fecha
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sub= new StringBuilder();
        sub.append("******* JUGADOR *******\n");
        sub.append(String.format("ID: %-10d | Nombre: %-15s | Apellido: %-15s | Género: %-10s",
                idJugador, nombre, apellido, genero));
//        sub.append(String.format("Conocimiento: %-15s | Fecha Registro: %s\n",
//                conocimientoDeJuego, fechaDeRegistro));
//        sub.append("Recompensas:\n");
//        for (int i = 0; i < contadorRecompensas; i++) {
//            if (recompensas.get(i) != null) {
//                sub.append(" - ").append(recompensas.get(i).toString()).append("\n");
//            }
//        }
//
//        sub.append("Comentarios:\n");
//        for (int i = 0; i < contadorComentarios; i++) {
//            if (comentarios.get(i) != null) {
//                sub.append(" - ").append(comentarios.get(i).toString()).append("\n");
//            }
//        }
//
//        sub.append("Recompensas Obtenidas:\n");
//        for (int i = 0; i < contadorRecompensasObtenidas; i++) {
//            if (recompensasObtenidas.get(i) != null) {
//                sub.append(" - ").append(recompensasObtenidas.get(i).toString()).append("\n");
//            }
//        }
        return sub.toString();
    }

    /**
     * Devueleve una representacion en cadena la informacion
     * del jugador
     * @return Cadena con los datos del jugador
     */

    public boolean equals(Object obj){
        if (this==obj)return true;
        if (obj==null) return false;
        if(!(obj instanceof Jugador)) return false;
        Jugador otroJugador=(Jugador)obj;
        return  this.idJugador==otroJugador.idJugador &&
                Objects.equals(this.nombre, otroJugador.nombre) &&
                Objects.equals(this.apellido, otroJugador.apellido);
    }
    /**
     * Metodo hashCode para mantener consistencia con equals
     */
    public int hashCode(){
        return Objects.hash(this.idJugador, this.nombre, this.apellido);
    }

    @Override
    public int compareTo(Jugador o) {
        int resultado = this.nombre.compareTo(o.getNombre());
        if(resultado>0){
            return 1;
        } else if (resultado<0) {
            return -1;
        }else
            //return 0;
            return this.getNombre().compareToIgnoreCase(o.getNombre());
    }

    public static void inicializarComentarios() {
        //List<Comentario> lista = new ArrayList<>();

        Comentario c1 = new Comentario("Ana", "Buen juego");
        c1.setFecha(LocalDateTime.of(2023, 5, 10, 14, 30));

        Comentario c2 = new Comentario("Luis", "Muy difícil");
        c2.setFecha(LocalDateTime.of(2023, 2, 1, 9, 45));

        Comentario c3 = new Comentario("Sara", "Me encantó");
        c3.setFecha(LocalDateTime.of(2023, 8, 20, 18, 10));

        agregarComentario(c1);
        agregarComentario(c2);
        agregarComentario(c3);
        agregarComentario("esta es una prueba");
    }
}



