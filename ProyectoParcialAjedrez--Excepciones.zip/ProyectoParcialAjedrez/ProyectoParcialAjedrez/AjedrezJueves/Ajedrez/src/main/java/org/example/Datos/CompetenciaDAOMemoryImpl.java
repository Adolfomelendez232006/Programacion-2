package org.example.Datos;

import org.example.dominio.*;
import java.time.LocalDateTime;
import java.util.Date;

public class CompetenciaDAOMemoryImpl implements CompetenciaDAO{
    public static final int CAPACIDAD_INICIAL_JUGADORES = 3;
    public static final int CAPACIDAD_INICIAL_RECOMPENSAS = 3;
    public static final int CAPACIDAD_INICIAL_PARTIDAS = 3;
    public static final int FACTOR_EXPANSION = 2;

    // Atributos de la competencia
    private String nombreTorneo;
    private Date fechaInicio;
    private Date fechaFin;
    private boolean iniciada;
    private boolean finalizada;
    private EstadoCompetencia estado;

    // Contador estático para llevar el control de competencias creadas
    private static int contadorCompetencias = 0;
    // Instancia única para el patrón Singleton
    private static CompetenciaDAOMemoryImpl instancia;
    // ID único de la competencia
    private final int idCompetencia;

    // Arreglos para manejar las entidades relacionadas
    private Jugador[] jugadores;
    private Recompensa[] recompensas;
    private Partida[] partidas;

    // Contadores para llevar el control de elementos actuales
    private int numJugadores = 0;
    private int numRecompensas = 0;
    private int numPartidas = 0;

    // Constructor privado para Singleton
    private CompetenciaDAOMemoryImpl() {
        this("Sin nombre de Torneo", new Date(), new Date());
    }

    private CompetenciaDAOMemoryImpl(String nombreTorneo, Date fechaInicio, Date fechaFin) {
        // Validaciones del nombre
        if (nombreTorneo == null || nombreTorneo.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (!nombreTorneo.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras");
        }
        if (nombreTorneo.length() < 2) {
            throw new IllegalArgumentException("El nombre debe tener al menos 2 caracteres");
        }

        // Validaciones de fechas
        if (fechaInicio == null || fechaFin == null) {
            throw new IllegalArgumentException("Las fechas no pueden ser nulas.");
        }
        if (fechaFin.before(fechaInicio)) {
            throw new IllegalArgumentException("La fecha de fin no puede ser anterior a la de inicio.");
        }

        this.idCompetencia = ++contadorCompetencias;
        this.nombreTorneo = nombreTorneo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.iniciada = false;
        this.finalizada = false;
        this.estado = EstadoCompetencia.NO_INICIADA;
        inicializarArreglos();
    }

    private void inicializarArreglos() {
        this.jugadores = new Jugador[CAPACIDAD_INICIAL_JUGADORES];
        this.recompensas = new Recompensa[CAPACIDAD_INICIAL_RECOMPENSAS];
        this.partidas = new Partida[CAPACIDAD_INICIAL_PARTIDAS];
        this.numJugadores = 0;
        this.numRecompensas = 0;
        this.numPartidas = 0;
    }

    // Métodos Singleton
    public static CompetenciaDAOMemoryImpl getInstancia() {
        if (instancia == null) {
            instancia = new CompetenciaDAOMemoryImpl();
        }
        return instancia;
    }

    public static CompetenciaDAOMemoryImpl getInstancia(String nombreTorneo, Date fechaInicio, Date fechaFin) {
        if (instancia == null) {
            instancia = new CompetenciaDAOMemoryImpl(nombreTorneo, fechaInicio, fechaFin);
        }
        return instancia;
    }

    public static void reiniciarInstancia() {
        instancia = null;
    }

    public static void reiniciarContador() {
        contadorCompetencias = 0;
    }

    public static int getTotalCompetenciasCreadas() {
        return contadorCompetencias;
    }

    // Implementación de métodos CRUD para Jugadores
    @Override
    public void registrarJugador(int id, String nombre, String apellido, String conocimiento,
                                 LocalDateTime fecha, Genero genero) {
        if (buscarJugador(id) != null) {
            throw new IllegalArgumentException("Ya existe un jugador con este id.");
        }

        if (numJugadores >= jugadores.length) {
            Jugador[] nuevoArreglo = new Jugador[jugadores.length * FACTOR_EXPANSION];
            System.arraycopy(jugadores, 0, nuevoArreglo, 0, jugadores.length);
            jugadores = nuevoArreglo;
        }

        jugadores[numJugadores] = new Jugador(id, nombre, apellido, conocimiento, fecha, genero);
        numJugadores++;
    }

    @Override
    public void registrarJugador(Jugador jugador) {
        if (jugador == null || buscarJugador(jugador.getIdJugador()) != null) return;

        if (numJugadores >= jugadores.length) {
            Jugador[] nuevoArreglo = new Jugador[jugadores.length * FACTOR_EXPANSION];
            System.arraycopy(jugadores, 0, nuevoArreglo, 0, jugadores.length);
            jugadores = nuevoArreglo;
        }

        jugadores[numJugadores] = jugador;
        numJugadores++;
    }

    @Override
    public Jugador buscarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                return jugadores[i];
            }
        }
        return null;
    }

    @Override
    public int buscarIndicePorId(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void modificarJugador(int indice, int id, String nombre, String apellido,
                                 String conocimiento, LocalDateTime fecha, Genero genero) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        jugadores[indice] = new Jugador(id, nombre, apellido, conocimiento, fecha, genero);
    }

    @Override
    public void modificarJugador(int indice, Jugador jugador) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo.");
        }

        boolean idCambiado = jugadores[indice].getIdJugador() != jugador.getIdJugador();
        boolean idYaExiste = buscarJugador(jugador.getIdJugador()) != null;

        if (idCambiado && idYaExiste) {
            throw new IllegalArgumentException("Ya existe otro jugador con ese ID.");
        }

        jugadores[indice] = jugador;
    }

    @Override
    public boolean borrarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                // Desplazar los jugadores a la izquierda
                for (int j = i; j < numJugadores - 1; j++) {
                    jugadores[j] = jugadores[j + 1];
                }
                jugadores[numJugadores - 1] = null;
                numJugadores--;
                return true;
            }
        }
        return false;
    }

    // Implementación de métodos CRUD para Recompensas
    @Override
    public void agregarRecompensa(Recompensa recompensa) {
        if (numRecompensas >= recompensas.length) {
            Recompensa[] nuevoArreglo = new Recompensa[recompensas.length * FACTOR_EXPANSION];
            System.arraycopy(recompensas, 0, nuevoArreglo, 0, recompensas.length);
            recompensas = nuevoArreglo;
        }
        recompensas[numRecompensas] = recompensa;
        numRecompensas++;
    }

    @Override
    public Recompensa buscarRecompensa(Recompensa recompensa) {
        for (int i = 0; i < numRecompensas; i++) {
            if (recompensas[i].equals(recompensa)) {
                return recompensas[i];
            }
        }
        return null;
    }

    @Override
    public Recompensa obtenerRecompensa(int indice) {
        if (indice >= 0 && indice < numRecompensas) {
            return recompensas[indice];
        }
        return null;
    }

    @Override
    public void editarRecompensa(int indice, Recompensa nuevaRecompensa) {
        if (indice < 0 || indice >= numRecompensas) {
            throw new IndexOutOfBoundsException("Índice de recompensa no válido.");
        }

        if (nuevaRecompensa == null) {
            throw new IllegalArgumentException("La recompensa no puede ser nula.");
        }

        for (int i = 0; i < numRecompensas; i++) {
            if (i != indice && recompensas[i].equals(nuevaRecompensa)) {
                throw new IllegalArgumentException("Ya existe una recompensa igual.");
            }
        }

        recompensas[indice] = nuevaRecompensa;
    }

    @Override
    public boolean borrarRecompensa(int indice) {
        if (indice < 0 || indice >= numRecompensas) {
            return false;
        }

        for (int i = indice; i < numRecompensas - 1; i++) {
            recompensas[i] = recompensas[i + 1];
        }

        recompensas[numRecompensas - 1] = null;
        numRecompensas--;
        return true;
    }

    // Implementación de métodos CRUD para Partidas
    @Override
    public void agregarPartida(Partida partida) {
        if (numPartidas >= partidas.length) {
            Partida[] nuevoArreglo = new Partida[partidas.length * FACTOR_EXPANSION];
            System.arraycopy(partidas, 0, nuevoArreglo, 0, partidas.length);
            partidas = nuevoArreglo;
        }
        partidas[numPartidas] = partida;
        numPartidas++;
    }

    @Override
    public Partida obtenerPartida(int indice) {
        if (indice >= 0 && indice < numPartidas) {
            return partidas[indice];
        }
        return null;
    }

    @Override
    public void editarPartida(int indice, Partida nuevaPartida) {
        if (indice < 0 || indice >= numPartidas) {
            throw new IndexOutOfBoundsException("Índice de partida no válido.");
        }

        if (nuevaPartida == null) {
            throw new IllegalArgumentException("La partida no puede ser nula.");
        }

        for (int i = 0; i < numPartidas; i++) {
            if (i != indice && partidas[i].equals(nuevaPartida)) {
                throw new IllegalArgumentException("Ya existe una partida igual.");
            }
        }

        partidas[indice] = nuevaPartida;
    }

    @Override
    public boolean borrarPartida(int indice) {
        if (indice < 0 || indice >= numPartidas) {
            return false;
        }

        for (int i = indice; i < numPartidas - 1; i++) {
            partidas[i] = partidas[i + 1];
        }

        partidas[numPartidas - 1] = null;
        numPartidas--;
        return true;
    }

    // Implementación de métodos de validación
    @Override
    public boolean validarDuplicado(Object obj) {
        if (obj == null) return false;

        // Validar duplicado de Jugador
        if (obj instanceof Jugador) {
            Jugador jugador = (Jugador) obj;
            for (int i = 0; i < numJugadores; i++) {
                if (jugadores[i] != null && jugadores[i].equals(jugador)) {
                    return true;
                }
            }
        }
        // Validar duplicado de Recompensa
        else if (obj instanceof Recompensa) {
            Recompensa recompensa = (Recompensa) obj;
            for (int i = 0; i < numRecompensas; i++) {
                if (recompensas[i] != null && recompensas[i].equals(recompensa)) {
                    return true;
                }
            }
        }
        // Validar duplicado de Partida
        else if (obj instanceof Partida) {
            Partida partida = (Partida) obj;
            for (int i = 0; i < numPartidas; i++) {
                if (partidas[i] != null && partidas[i].equals(partida)) {
                    return true;
                }
            }
        }

        return false;
    }

    // Implementación de métodos de control de competencia
    @Override
    public void iniciarCompetencia() {
        if (!iniciada) {
            this.iniciada = true;
            this.estado = EstadoCompetencia.EN_CURSO;
            System.out.println("Competencia iniciada.");
        } else {
            System.out.println("La competencia ya estaba iniciada.");
        }
    }

    @Override
    public void setIniciarCompetencia() {
        this.iniciada = true;
        this.estado = EstadoCompetencia.EN_CURSO;
    }

    @Override
    public void finalizarCompetencia() {
        this.finalizada = true;
        this.estado = EstadoCompetencia.FINALIZADA;
        System.out.println("Competencia finalizada.");
    }
    
}
