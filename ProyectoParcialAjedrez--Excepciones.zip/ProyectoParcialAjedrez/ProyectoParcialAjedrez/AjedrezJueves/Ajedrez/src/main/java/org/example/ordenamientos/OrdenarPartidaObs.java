package org.example.ordenamientos;

import org.example.dominio.Partida;

import java.util.Comparator;

public class OrdenarPartidaObs implements Comparator<Partida> {
    @Override
    public int compare(Partida o1, Partida o2) {
        int resultado= o1.getObservaciones().compareTo(o2.getObservaciones());
        if(resultado != 0){
            return resultado;
        }else
            return 0;
    }
}
