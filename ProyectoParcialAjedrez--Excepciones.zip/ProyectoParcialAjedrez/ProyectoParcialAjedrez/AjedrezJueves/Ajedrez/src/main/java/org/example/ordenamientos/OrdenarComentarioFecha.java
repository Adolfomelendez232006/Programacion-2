package org.example.ordenamientos;

import org.example.dominio.Comentario;

import java.util.Comparator;

public class OrdenarComentarioFecha implements Comparator<Comentario> {
    @Override
    public int compare(Comentario c1, Comentario c2) {
        int resultado = c1.getFecha().compareTo(c2.getFecha());
        if (resultado > 0) {
            return 1;
        } else if (resultado < 0) {
            return -1;
        } else {
            return 0;
        }
    }
}
