package org.example.consola;

import org.example.dominio.*;
import org.example.ordenamientos.OrdenarComentarioFecha;
import org.example.ordenamientos.OrdenarJugadorApellido;
import org.example.ordenamientos.OrdenarPartidaObs;
import org.example.util.Validador;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Clase que representa el submenú de gestión de partidas del sistema.
 * Permite crear, registrar y consultar partidas, así como gestionar comentarios.
 */
public class SubMenu2 {
    /**
     * Muestra el submenú de gestión de partidas y comentarios.
     * Ofrece al usuario diferentes opciones para administrar partidas,
     * ya sean contra la máquina, multijugador o tutorial, además de
     * permitir registrar, consultar y comentar partidas.
     */
    /**
     * Muestra el submenú de gestión de partidas y comentarios.
     * Ofrece al usuario diferentes opciones para administrar partidas,
     * ya sean contra la máquina, multijugador o tutorial, además de
     * permitir registrar, consultar y comentar partidas.
     */
    public static void subMenu2(String[] args) {
        Scanner sc = new Scanner(System.in);
        int op;
        int id = 0;
        boolean val1 = true, val2 = true;
        Scanner leer = new Scanner(System.in);
        Comentario gestor = new Comentario();
        Partida partida = new Partida();
        Competencia jugador = Competencia.getInstancia();

        while (val1 == true) {
            StringBuilder menu = new StringBuilder();
            menu.append("\n")
                    .append("\n╔══════════════════════════════════════════════════════════╗\n")
                    .append("║                    🎮 GESTIONAR PARTIDA 🎮               ║\n")
                    .append("╠══════════════════════════════════════════════════════════╣\n")
                    .append("║  1. 🆕 Crear partida                                     ║\n")
                    .append("║  2. 🔍 Consultar partida                                 ║\n")
                    .append("║  3. ✏  Editar partida                                    ║\n")
                    .append("║  4. 🗑  Eliminar partida                                 ║\n")
                    .append("║  5. 💬 Enviar comentario                                 ║\n")
                    .append("║  6. 🚪 Salir                                             ║\n")
                    .append("╚══════════════════════════════════════════════════════════╝\n")
                    .append("👉 Ingrese la opción que desea seleccionar: ");
            System.out.print(menu);
            op = Validador.pedirNumero(leer);
            switch (op) {
                case 1:
                    val2 = true;
                    while (val2 == true) {
                        StringBuilder crearMenu = new StringBuilder();
                        crearMenu.append("\n")
                                .append("╔══════════════════════════════════════════════════════════╗\n")
                                .append("║                     🎲 CREAR PARTIDA 🎲                  ║\n")
                                .append("╠══════════════════════════════════════════════════════════╣\n")
                                .append("║  1. 🤖 Crear partida contra la máquina                  ║\n")
                                .append("║  2. 👥 Crear partida multijugador                       ║\n")
                                .append("║  3. 🚪 Salir                                             ║\n")
                                .append("╚══════════════════════════════════════════════════════════╝\n")
                                .append("👉 Ingrese la opción que desea seleccionar: ");
                        System.out.print(crearMenu);
                        op = Validador.pedirNumero(leer);
                        System.out.println("");
                        switch (op) {
                            case 1:
                                boolean sa = false;

                                Jugador jugador1 = null;
                                System.out.println("H1.1.1. Crear partida contra la maquina");
                                partida.crearPartidaMaquina();
                                LocalDateTime fecha = LocalDateTime.now();
                                int puntajeJugador1 = 0;
                                int puntajeJugador2 = 0;
                                System.out.println("Ingrese su observacion: ");
                                String obs = Validador.solicitarTextoValido(leer);
                                leer.nextLine();
                                id = id + 1;
                                System.out.println("Partida contra máquina creada exitosamente\n" +
                                        "id: " + id);
                                Contrincante contrincante = Contrincante.MAQUINA;
                                jugador.registrarPartida(puntajeJugador1, puntajeJugador2, fecha, obs, contrincante, EstadoEnfrentamiento.EMPATE);
                                break;
                            case 2:
                                System.out.println("H1.1.2. Crear partida multijugador");
                                partida.crearPartidaMultijugador();
                                fecha = LocalDateTime.now();
                                puntajeJugador1 = 0;
                                puntajeJugador2 = 0;
                                System.out.println("Ingrese su observacion: ");
                                obs = Validador.solicitarTextoValido(leer);
                                //leer.nextLine();
                                System.out.println("Ingrese el id del Jugador#1: ");
                                int id1 = sc.nextInt();
                                System.out.println("Ingrese el id del jugador#2: ");
                                int id2 = sc.nextInt();
                                id = id + 1;
                                System.out.println("Partida multijugador creada exitosamente\n" +
                                        "id: " + id);
                                Contrincante contrincan = Contrincante.JUGADOR;
                                jugador.registrarPartida(puntajeJugador1, puntajeJugador2, fecha, obs, contrincan, EstadoEnfrentamiento.EMPATE);
                                System.out.println("Jugadores dentro de la partida: \n" +
                                        "Jugador#1: " + jugador.buscarJugador(id1) + "\n" +
                                        "Jugador#2: " + jugador.buscarJugador(id2));
                                break;
                            case 3:
                                val2 = false;
                                break;
                            default:
                                System.out.println("Esta opcion no es valida");
                        }
                    }
                    break;
                case 2:
                    List<Partida> listapar = new ArrayList<>(partida.getPartidas());
                    Comparator<Partida> porObs = new OrdenarPartidaObs();
                    Collections.sort(listapar, porObs);
                    System.out.println("");
                    System.out.println("==================================");
                    System.out.println("Ordendo por Observacion: ");
                    listapar.sort(new OrdenarPartidaObs());
                    for (Partida ju:listapar){
                        System.out.println(ju);
                    }
                    System.out.println("");
                    //System.out.println(partida.consultarPartida());
                    break;
                case 3:
                    System.out.println("H1.4. Editar partida");
                    System.out.println("Ingrese el numero de partida que quiere editar: ");
                    int idBuscado = Validador.pedirNumero(leer);

                    int indice = jugador.buscarPartidaPorId(idBuscado);

                    if (indice == -1) {
                        System.out.println("Partida con ID " + idBuscado + " no encontrado.");
                    } else {
                        Contrincante con1 = Contrincante.SINCONTRINCANTE;
                        int con = 0;
                        boolean va = false;
                        System.out.println("partida anterior: " + partida.partidas.get(indice));
                        int nuevoPuntajeJ1 = 0;
                        int nuevoPuntajeJ2 = 0;
                        System.out.println("Elige el contrincante: ");
                        System.out.println("1. Jugador\n" +
                                "2. Maquina\n" +
                                "3. Sin contrincante\n");
                        con = sc.nextInt();
                        va = false;
                        while (va == false) {
                            switch (con) {
                                case 1:
                                    con1 = Contrincante.JUGADOR;
                                    va = true;
                                    break;
                                case 2:
                                    con1 = Contrincante.MAQUINA;
                                    va = true;
                                    break;
                                case 3:
                                    con1 = Contrincante.SINCONTRINCANTE;
                                    va = true;
                                    break;
                                default:
                                    System.out.println("Esta opcion no es valida.");
                            }
                        }
                        System.out.print("Nueva observacion: ");
                        String nuevaObs = Validador.solicitarTextoValido(leer);
                        leer.nextLine();

                        LocalDateTime nuevaFecha = LocalDateTime.now();

                        jugador.editarPartida(indice, nuevoPuntajeJ1, nuevoPuntajeJ2, nuevaObs, nuevaFecha, EstadoEnfrentamiento.EMPATE, con1);
                    }
                    break;
                case 4:
                    System.out.println("H1.5. Eliminar partida.");
                    System.out.println("Ingrese el id de la partida que deseas eliminar: ");
                    int idEliminar = Validador.pedirNumero(leer);
                    leer.nextLine();

                    boolean eliminado = jugador.eliminarPartida(idEliminar);
                    if (eliminado) {
                        System.out.println("Partida eliminada correctamente.");
                    } else {
                        System.out.println("No se encontró ninguna partida con ese ID.");
                    }
                    break;
                case 5:
                    int opc;
                    val2 = true;
                    do {
                        System.out.println("\n--- Menú de Comentarios ---");
                        System.out.println("1. Registrar un comentario");
                        System.out.println("2. Ver todos los comentarios");
                        System.out.println("3. Eliminar un comentario");
                        System.out.println("4. Editar un comentario");
                        System.out.println("5. Ver comentarios ordenados por fecha");
                        System.out.println("6. Salir");
                        System.out.print("Seleccione una opción: ");
                        opc = Validador.pedirNumero(leer);
                        leer.nextLine();

                        switch (opc) {
                            case 1:
                                System.out.print("Nombre de usuario: ");
                                String usuario = Validador.pedirNombre(leer);
                                System.out.print("Escribe tu comentario: ");
                                String texto = Validador.pedirNombre(leer);
                                leer.nextLine();
                                gestor.registrarComentario(usuario, texto);
                                break;

                            case 2:
                                System.out.println(gestor.listarComentarios());
                                break;

                            case 3:
                                System.out.print("Índice del comentario a eliminar: ");
                                indice = Validador.pedirNumero(leer);
                                if (indice >= 0 && indice < gestor.getCantidadComentarios()) {
                                    System.out.println(gestor.eliminarComentario(indice));
                                } else {
                                    System.out.println("Índice inválido. Intenta de nuevo.");
                                }
                                break;

                            case 4:
                                System.out.print("Índice del comentario a editar: ");
                                int indiceEditar = Validador.pedirNumero(leer);
                                if (indiceEditar >= 0 && indiceEditar < gestor.getCantidadComentarios()) {
                                    System.out.print("Nuevo nombre de usuario: ");
                                    String nuevoAutor = Validador.pedirNombre(leer);
                                    System.out.print("Nuevo texto del comentario: ");
                                    String nuevoTexto = leer.nextLine();
                                    gestor.editarComentario(indiceEditar, nuevoAutor, nuevoTexto);
                                    System.out.println("Comentario actualizado.");
                                } else {
                                    System.out.println("Índice inválido. Intente de nuevo.");
                                }
                                break;

                            case 5:
//                                Comentario[] copia = gestor.obtenerCopiaComentarios();
                                System.out.println("Lista de comentarios: ");
                                Jugador.inicializarComentarios(); // <-- inicializa y ordena comentarios de prueba


//                                // Ordenar manualmente por fecha (Bubble Sort)
//                                for (int i = 0; i < copia.length - 1; i++) {
//                                    for (int j = 0; j < copia.length - i - 1; j++) {
//                                        OrdenarComentarioFecha comparador = new OrdenarComentarioFecha();
//                                        if (comparador.compare(copia[j], copia[j + 1]) > 0) {
//                                            Comentario temp = copia[j];
//                                            copia[j] = copia[j + 1];
//                                            copia[j + 1] = temp;
//                                        }
//                                    }
//                                }
//
//                                System.out.println("Comentarios ordenados por fecha:");
//                                for (Comentario c : copia) {
//                                    System.out.println(c);
//                                }
                                break;

                            case 6:
                                System.out.println("Saliendo del menú de comentarios...");
                                val2 = false;
                                break;

                            default:
                                System.out.println("Opción inválida. Intente de nuevo.");
                        }
                    } while (val2 == true);
                    break;
                case 6:
                    System.out.println("Saliendo del menu...");
                    val1 = false;
                    break;
                default:
                    System.out.println("Estos valores no estan permitidos");
            }
        }
    }

}
