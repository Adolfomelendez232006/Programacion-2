package org.example.dominio;

public enum Contrincante {
    MAQUINA("M", "Maquina"),
    JUGADOR("M", "Jugador"),
    SINCONTRINCANTE(" ", "Sin contrincante");

    private String simbolo;
    private String nombre;

    private Contrincante(String simbolo, String nombre) {
        this.simbolo = simbolo;
        this.nombre = nombre;
    }

    public String getSimbolo() {
        return simbolo;
    }

    public String getNombre() {
        return nombre;
    }
}
