package org.example.dominio;

import java.util.Objects;

/**
 * Proporciona un tutorial sobre ajedrez, incluyendo información
 * sobre piezas, fundamentos básicos, estrategias intermedias y
 * técnicas avanzadas.
 * <p>El tutorial está organizado en cuatro secciones principales:
 * <ol>
 *     <li>Descripción de las piezas de ajedrez</li>
 *     <li>Fundamentos básicos del juego</li>
 *     <li>Consejos y estrategias de nivel intermedio</li>
 *     <li>Técnicas avanzadas y tácticas</li>
 * </ol>
 * </p>
 */
public class Tutorial {
    public String piezasDeAjedrez;
    public String fundamentos;
    public String intermedio;
    public String avanzado;

    // final
    public static final String VERSION = "1.0";
    public static final String AUTOR = "Administrador";

    // Constructor predeterminado que configura el tutorial
    public Tutorial() {
        establecerTutorial();
    }

    // Este metodo estático puede mostrarse sin crear un objeto Tutorial
    public static void mostrarIntroduccion() {
        String separador = "=".repeat(50);
        System.out.printf("%s%n", separador);
        System.out.printf("%-5s Tutorial de Ajedrez v%s%n", "", VERSION);
        System.out.printf("%-5s Creado por: %s%n", "", AUTOR);
        System.out.printf("%s%n", separador);
        System.out.printf("%s ¡Aprende desde lo básico hasta técnicas avanzadas!%n", "");
        System.out.printf("%s%n", separador);
    }

    // Constructor predeterminado que configura el tutorial
        public void establecerTutorial() {
            this.piezasDeAjedrez = String.format("Las piezas de ajedrez son: %s, %s, %s, %s, %s y %s.",
                    "rey", "dama", "torre", "alfil", "caballo", "peón");

            this.fundamentos = String.format("El objetivo del juego es dar %s al %s del %s.",
                    "jaque mate", "rey", "oponente");

            this.intermedio = String.format("%s el %s, %s las %s y %s al %s (%s).",
                    "Controla", "centro", "desarrolla", "piezas", "protege", "rey", "enroque");

            this.avanzado = String.format("Tácticas: %s, %s, %s, y %s.",
                    "clavadas", "ataques dobles", "sacrificios", "finales estratégicos");
        }

    public String mostrarTutorial() {
        return String.format(
                "%n╔══════════════════════════════════════════╗%n" +
                "║            TUTORIAL DE AJEDREZ           ║%n" +
                "╠══════════════════════════════════════════╣%n" +
                "[1] Piezas de Ajedrez:   %-15s %n" +
                "[2] Fundamentos:         %-15s %n" +
                "[3] Nivel Intermedio:    %-15s %n" +
                "[4] Nivel Avanzado:      %-15s %n",
                this.piezasDeAjedrez, this.fundamentos, this.intermedio, this.avanzado
        );
    }

        // Metodo principal para editar secciones
        public String editarTutorial (String seccion, String nuevoContenido){
            switch (seccion.toLowerCase()) {
                case "piezas":
                    this.piezasDeAjedrez = nuevoContenido;
                    return "Sección 'piezas' actualizada.";
                case "fundamentos":
                    this.fundamentos = nuevoContenido;
                    return "Sección 'fundamentos' actualizada.";
                case "intermedio":
                    this.intermedio = nuevoContenido;
                    return "Sección 'intermedio' actualizada.";
                case "avanzado":
                    this.avanzado = nuevoContenido;
                    return "Sección 'avanzado' actualizada.";
                default:
                    return "Sección no válida.";
            }
        }

        // Sobrecarga: permite editar todas las secciones a la vez
        public void editarTutorial (String piezas, String fundamentos, String intermedio, String avanzado){
            this.piezasDeAjedrez = piezas;
            this.fundamentos = fundamentos;
            this.intermedio = intermedio;
            this.avanzado = avanzado;
        }

        // Elimina todo el contenido
        public void eliminarTutorial () {
            this.piezasDeAjedrez = "";
            this.fundamentos = "";
            this.intermedio = "";
            this.avanzado = "";
        }

        // Sobrecarga: elimina solo una sección específica
        public void eliminarTutorial (String seccion){
            switch (seccion.toLowerCase()) {
                case "piezas":
                    this.piezasDeAjedrez = "";
                    break;
                case "fundamentos":
                    this.fundamentos = "";
                    break;
                case "intermedio":
                    this.intermedio = "";
                    break;
                case "avanzado":
                    this.avanzado = "";
                    break;
            }
        }

        // equals y hashCode
        @Override
        public boolean equals (Object obj){
            if (this == obj) return true;
            if (!(obj instanceof Tutorial)) return false;
            Tutorial t = (Tutorial) obj;
            return Objects.equals(this.piezasDeAjedrez, t.piezasDeAjedrez) &&
                    Objects.equals(this.fundamentos, t.fundamentos) &&
                    Objects.equals(this.intermedio, t.intermedio) &&
                    Objects.equals(this.avanzado, t.avanzado);
        }

        @Override
        public int hashCode () {
            return Objects.hash(this.piezasDeAjedrez, this.fundamentos, this.intermedio, this.avanzado);
        }
}
