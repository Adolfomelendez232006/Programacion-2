package org.example.Datos;

import org.example.dominio.*;

public class JugadorDAOMemoryImpl implements JugadorDAO{

    private static Comentario[] comentarios;
    private static int cantComentarios;
    private static SolicitudDeRecompensa[] solicitudDeRecompensas;
    private static int cantSolicitudes;
    private static Logro[] logros;
    private static int cantLogros;
    private static Recompensa[] recompensasObtenidas;
    private static int cantRecompensas;
    private static int puntosAcumulados;

    static {
        comentarios = new Comentario[3];
        cantComentarios = 0;
        solicitudDeRecompensas = new SolicitudDeRecompensa[3];
        cantSolicitudes = 0;
        logros = new Logro[3];
        cantLogros = 0;
        recompensasObtenidas = new Recompensa[3];
        cantRecompensas = 0;
        puntosAcumulados = 0;
    }

    //Interfaz para la gestion de los puntos
    @Override
    public int calcularTotalPuntos() {
        int totalPuntos = puntosAcumulados;

        // Sumar puntos de logros completados
        for (int i = 0; i < cantLogros; i++) {
            if (logros[i] != null && logros[i].isCompletado()) {
                totalPuntos += logros[i].getPuntos();
            }
        }

        return totalPuntos;
    }

    //Para gestionar los comentarios
    @Override
    public boolean agregarComentario(String texto) {
        if (cantComentarios >= comentarios.length || texto == null || texto.trim().isEmpty()) {
            return false;
        }

        comentarios[cantComentarios] = new Comentario(texto);
        cantComentarios++;
        return true;
    }

    @Override
    public boolean eliminarComentario(int indice) {
        if (indice < 0 || indice >= cantComentarios) {
            return false;
        }

        // Desplazar elementos hacia la izquierda
        for (int i = indice; i < cantComentarios - 1; i++) {
            comentarios[i] = comentarios[i + 1];
        }

        comentarios[cantComentarios - 1] = null;
        cantComentarios--;
        return true;
    }

    @Override
    public boolean actualizarComentario(int indice, String nuevoTexto) {
        if (indice < 0 || indice >= cantComentarios || nuevoTexto == null || nuevoTexto.trim().isEmpty()) {
            return false;
        }

        comentarios[indice].setContenido(nuevoTexto);
        return true;
    }

    //Para la gestion de las recompensas
    @Override
    public boolean agregarSolicitudRecompensa(EstadoDeSolicitud estado, Recompensa recompensa) {
        if (cantSolicitudes >= solicitudDeRecompensas.length || recompensa == null) {
            return false;
        }

        solicitudDeRecompensas[cantSolicitudes] = new SolicitudDeRecompensa(estado, recompensa);
        cantSolicitudes++;
        return true;
    }

    @Override
    public boolean aprobarRecompensa(int idRecompensa) {
        if (idRecompensa < 0 || idRecompensa >= cantSolicitudes) {
            return false;
        }

        SolicitudDeRecompensa solicitud = solicitudDeRecompensas[idRecompensa];
        if (solicitud == null) {
            return false;
        }

        // Cambiar estado a aprobado
        solicitud.setEstado(EstadoDeSolicitud.APROBADA);

        // Agregar a recompensas obtenidas si hay espacio
        if (cantRecompensas < recompensasObtenidas.length) {
            recompensasObtenidas[cantRecompensas] = solicitud.getRecompensa();
            cantRecompensas++;
        }

        return true;
    }

    @Override
    public boolean eliminarSolicitudRecompensa(int idRecompensa) {
        if (idRecompensa < 0 || idRecompensa >= cantSolicitudes) {
            return false;
        }

        // Desplazar elementos hacia la izquierda
        for (int i = idRecompensa; i < cantSolicitudes - 1; i++) {
            solicitudDeRecompensas[i] = solicitudDeRecompensas[i + 1];
        }

        solicitudDeRecompensas[cantSolicitudes - 1] = null;
        cantSolicitudes--;
        return true;
    }

    @Override
    public SolicitudDeRecompensa[] obtenerRecompensasAprobadas() {
        // Contar recompensas aprobadas
        int cantAprobadas = 0;
        for (int i = 0; i < cantSolicitudes; i++) {
            if (solicitudDeRecompensas[i] != null &&
                    solicitudDeRecompensas[i].getEstado() == EstadoDeSolicitud.APROBADA) {
                cantAprobadas++;
            }
        }

        // Crear array con el tamaño exacto
        SolicitudDeRecompensa[] aprobadas = new SolicitudDeRecompensa[cantAprobadas];
        int index = 0;

        for (int i = 0; i < cantSolicitudes; i++) {
            if (solicitudDeRecompensas[i] != null &&
                    solicitudDeRecompensas[i].getEstado() == EstadoDeSolicitud.APROBADA) {
                aprobadas[index] = solicitudDeRecompensas[i];
                index++;
            }
        }

        return aprobadas;
    }

    @Override
    public String mostrarRecompensasAprobadas() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== RECOMPENSAS APROBADAS ===\n");

        SolicitudDeRecompensa[] aprobadas = obtenerRecompensasAprobadas();

        if (aprobadas.length == 0) {
            sb.append("No hay recompensas aprobadas.\n");
        } else {
            for (int i = 0; i < aprobadas.length; i++) {
                sb.append((i + 1)).append(". ");
                sb.append(aprobadas[i].getRecompensa().getNombre());
                sb.append(" (").append(aprobadas[i].getRecompensa()).append(" puntos)\n");
            }
        }

        return sb.toString();

    }

    @Override
    public String mostrarRecompensas() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== TODAS LAS SOLICITUDES DE RECOMPENSA ===\n");

        if (cantSolicitudes == 0) {
            sb.append("No hay solicitudes de recompensa.\n");
        } else {
            for (int i = 0; i < cantSolicitudes; i++) {
                if (solicitudDeRecompensas[i] != null) {
                    sb.append((i + 1)).append(". ");
                    sb.append(solicitudDeRecompensas[i].getRecompensa().getNombre());
                    sb.append(" - Estado: ").append(solicitudDeRecompensas[i].getEstado());
                    sb.append(" (").append(solicitudDeRecompensas[i].getRecompensa()).append(" puntos)\n");
                }
            }
        }

        return sb.toString();
    }

    //Para la gestion de los logros
    @Override
    public void registrarLogro(Logro logro) {
        if (cantLogros < logros.length && logro != null) {
            logros[cantLogros] = logro;
            cantLogros++;
        }
    }

    @Override
    public boolean completarLogro(String nombreLogro) {
        if (nombreLogro == null || nombreLogro.trim().isEmpty()) {
            return false;
        }

        for (int i = 0; i < cantLogros; i++) {
            if (logros[i] != null && logros[i].getNombre().equals(nombreLogro)) {
                if (!logros[i].isCompletado()) {
                    logros[i].setCompletado(true);
                    puntosAcumulados += logros[i].getPuntos();
                    return true;
                }
                return false; // Ya estaba completado
            }
        }

        return false; // No se encontró el logro
    }

    @Override
    public String mostrarLogros() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== LOGROS ===\n");

        if (cantLogros == 0) {
            sb.append("No hay logros registrados.\n");
        } else {
            for (int i = 0; i < cantLogros; i++) {
                if (logros[i] != null) {
                    sb.append((i + 1)).append(". ");
                    sb.append(logros[i].getNombre());
                    sb.append(" - ").append(logros[i].getPuntos()).append(" puntos");
                    sb.append(" [").append(logros[i].isCompletado() ? "COMPLETADO" : "PENDIENTE").append("]\n");
                    if (logros[i].getDescripcion() != null && !logros[i].getDescripcion().isEmpty()) {
                        sb.append("   Descripción: ").append(logros[i].getDescripcion()).append("\n");
                    }
                }
            }
        }

        sb.append("\nPuntos totales: ").append(calcularTotalPuntos()).append("\n");

        return sb.toString();
    }
}
