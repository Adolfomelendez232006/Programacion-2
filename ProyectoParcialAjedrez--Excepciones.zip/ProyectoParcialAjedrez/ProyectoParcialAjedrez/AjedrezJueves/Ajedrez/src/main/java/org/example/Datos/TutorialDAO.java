package org.example.Datos;

public interface TutorialDAO {

    void mostrarIntroduccion();
    void establecerTutorial();
    String mostrarTutorial();

    String editarTutorial(String seccion, String nuevoContenido);
    void editarTutorial(String piezas, String fundamentos, String intermedio, String avanzado);

    void eliminarTutorial();
    void eliminarTutorial(String seccion);
}
