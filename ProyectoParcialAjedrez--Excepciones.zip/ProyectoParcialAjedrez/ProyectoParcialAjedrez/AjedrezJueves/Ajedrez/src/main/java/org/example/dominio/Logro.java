package org.example.dominio;

public class Logro extends Recompensa{
    //Atributos
    private boolean completado;

    //Metodo constructor
    public Logro() {
        super();
        this.completado = false;
    }
    public Logro(String nombre, String descripcion, int puntos, boolean completado) {
        super(nombre, descripcion, puntos);
        this.completado = completado;
    }
    // Constructor adicional para crear logro específico sin completar
    public Logro(String tipoRecompensa) {
        super(tipoRecompensa);
        this.completado = false;
    }

    //Metodo get y set
    public boolean getCompletado() {
        return completado;
    }
    public void setCompletado(boolean completado) {
        this.completado = completado;
    }

    //Metodos adicionales
    /**
     * Marca el logro como completado
     *
     * @return
     */
    public String completarLogro(String nombreLogro) {
        this.setNombre(nombreLogro);
        this.completado = true;
        return nombreLogro;
    }

    /**
     * Reinicia el logro (lo marca como no completado)
     */
    public void reiniciarLogro() {
        this.completado = false;
    }

    /**
     * Verifica si el logro está pendiente (no completado)
     * @return true si está pendiente, false si está completado
     */
    public boolean estaPendiente() {
        return !completado;
    }

    /**
     * Obtiene el estado del logro como texto
     * @return "Completado" o "Pendiente"
     */
    public String getEstadoTexto() {
        return completado ? "Completado" : "Pendiente";
    }
    /**
     * Sobrescribe toString para incluir información del logro
     * @return representación en cadena del logro
     */
    @Override
    public String toString() {
        return String.format(
                "LOGRO:%n" +
                        "Nombre:      %-20s%n" +
                        "Descripción: %-30s%n" +
                        "Puntos:      %-10d%n" +
                        "Completado:  %-10s%n" +
                        "Estado:      '%s'",
                getNombre(), getDescripcion(), getPuntos(), completado, getEstadoTexto()
        );
    }

    public boolean isCompletado() {
        return completado;
    }
}
