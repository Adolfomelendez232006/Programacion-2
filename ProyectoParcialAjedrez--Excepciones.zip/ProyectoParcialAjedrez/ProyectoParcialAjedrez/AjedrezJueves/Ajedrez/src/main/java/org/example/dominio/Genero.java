package org.example.dominio;

public enum Genero {
    FEMENINO("F", "Femenino"),
    MASCULINO("M", "Masculino"),
    OTRO("O", "Otro");

    private String simbolo;
    private String nombre;

    private Genero(String simbolo, String nombre) {
        this.simbolo = simbolo;
        this.nombre = nombre;
    }

    public String getSimbolo() {
        return simbolo;
    }

    public String getNombre() {
        return nombre;
    }
}

