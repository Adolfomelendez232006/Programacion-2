package org.example.dominio;

import org.example.ordenamientos.OrdenarComentarioFecha;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Comentario {
    private static final int TAMAÑO_INICIAL = 3;  // Tamaño inicial constante para el arreglo
    private static int contadorTotalComentarios = 0; // Contador total de comentarios creados

    private String autor;
    private String contenido;
    private LocalDateTime fecha;


    private List<Comentario> comentarios;  // Lista de comentarios


    //metodo inicializar



    // Constructor por defecto
    public Comentario() {
        this.comentarios = new ArrayList<>();
//        this.comentarios = new Comentario[3];
//        this.cantidadComentarios = 0;
    }

    // Constructor con parámetros, usando this()
    public Comentario(String autor, String contenido) {
        //this();// llama al constructor por defecto
        this.autor = autor;
        this.contenido = contenido;
        this.fecha = LocalDateTime.now();
        contadorTotalComentarios++;
    }

    public Comentario(String contenido) {
        this();// llama al constructor por defecto
        this.contenido = contenido;
        this.fecha = LocalDateTime.now();
        contadorTotalComentarios++;
    }

    // Getters para el contador total
    public static int getContadorTotalComentarios() {
        return contadorTotalComentarios;
    }

    // Getters y setters
    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public int getCantidadComentarios() {
        return comentarios.size();
    }

    /**
     * Registra un nuevo comentario.
     */
    //int cantidadComentarios;
    //Comentario comentarios[] = new Comentario[3];
    public String registrarComentario(String usuario, String texto) {
        Comentario nuevoComentario = new Comentario(usuario, texto);
        comentarios.add(nuevoComentario);
        return "Comentario registrado con éxito.";
    }

    //sobrecarga: regirtrar un objeto comentario ya creado
    public String registrarComentario(Comentario nuevoComentario) {
        comentarios.add(nuevoComentario);
        return "Comentario registrado con éxito (desde objeto).";
    }

    /**
     * Lista todos los comentarios registrados.
     */
    public String listarComentarios() {
        StringBuilder resultado = new StringBuilder("Lista de comentarios:\n");
        for (Comentario c : comentarios) {
            resultado.append(c).append("\n");
        }
//        for (int i = 0; i < this.cantidadComentarios; i++) {
//            resultado.append(this.comentarios[i]).append("\n");
//        }
        return resultado.toString();
    }

    // Sobrecarga: listar comentarios por autor
    public String listarComentarios(String autorBuscado) {
        StringBuilder resultado = new StringBuilder("Comentarios del autor '" + autorBuscado + "':\n");
        boolean encontrado = false;
        for (Comentario c : comentarios) {
            if (c.getAutor().equalsIgnoreCase(autorBuscado)) {
                resultado.append(c).append("\n");
                encontrado = true;
            }
        }
        if (!encontrado) {
            resultado.append("No se encontraron comentarios de este autor.\n");
        }
        return resultado.toString();
    }

    /**
     * Elimina un comentario por su índice.
     */
    public String eliminarComentario(int indice) {
        if (indice >= 0 && indice < comentarios.size()) {
            comentarios.remove(indice);
            return "Comentario eliminado.";
        }
        return "Índice inválido.";
    }

    // Sobrecarga: eliminar por autor
    public String eliminarComentario(String autor) {
        for (int i = 0; i < comentarios.size(); i++) {
            if (comentarios.get(i).getAutor().equalsIgnoreCase(autor)) {
                comentarios.remove(i);
                return "Comentario del autor eliminado.";
            }
        }
        return "No se encontró comentario con ese autor.";
    }

    /**
     * Edita el contenido de un comentario según su índice.
     */
    public String editarComentario(int indice, String nuevoContenido) {
        if (indice >= 0 && indice < comentarios.size()) {
            comentarios.get(indice).setContenido(nuevoContenido); // ← Aquí estaba el problema
            return "Comentario editado.";
        }
        return "Índice inválido.";
    }

    // Sobrecarga: Editar autor y contenido
    public String editarComentario(int indice, String nuevoAutor, String nuevoContenido) {
        if (indice >= 0 && indice < this.comentarios.size()) {
            Comentario comentario = this.comentarios.get(indice);
            comentario.setAutor(nuevoAutor);
            comentario.setContenido(nuevoContenido);
            return "Autor y contenido del comentario editados.";
        } else {
            return "Índice inválido.";
        }
    }

    @Override
    public String toString() {
        return autor + " → " + fecha.toLocalDate() + " " + fecha.toLocalTime().withSecond(0).withNano(0)
                + (contenido != null ? ": " + contenido : "");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true; // Mismo objeto
        if (o == null) return false; // Null no es igual
        if (getClass() != o.getClass()) return false; // Diferente clase no es igual

        Comentario otro = (Comentario) o; // Cast manual

        if (autor == null) {
            if (otro.autor != null) return false;
        } else if (!autor.equals(otro.autor)) {
            return false;
        }

        if (fecha == null) {
            if (otro.fecha != null) return false;
        } else if (!fecha.equals(otro.fecha)) {
            return false;
        }

        return true; // Si todo coincide
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = 31 * result + (autor == null ? 0 : autor.hashCode());
        result = 31 * result + (fecha == null ? 0 : fecha.hashCode());
        return result;
    }

    public Comentario[] obtenerCopiaComentarios() {
        return comentarios.toArray(new Comentario[0]);
//        Comentario[] copia = new Comentario[this.cantidadComentarios];
//        for (int i = 0; i < this.cantidadComentarios; i++) {
//            copia[i] = this.comentarios[i];
//        }
//        return copia;
    }

    public int compareTo(Comentario o) {
        int resultado = this.fecha.compareTo(o.getFecha());
        if (resultado > 0) {
            return 1;
        } else if (resultado < 0) {
            return -1;
        } else {
            return 0;
        }
    }
}


