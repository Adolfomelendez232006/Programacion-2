package org.example.Datos;

public class TutorialDAOMemoryImpl implements TutorialDAO{
    private static String piezasDeAjedrez;
    private static String fundamentos;
    private static String intermedio;
    private static String avanzado;
    public static final String VERSION = "1.0";
    public static final String AUTOR = "Administrador";

    @Override
    public void mostrarIntroduccion() {
        System.out.println("=== Tutorial de Ajedrez v" + VERSION + " ===");
        System.out.println("Creado por: " + AUTOR);
        System.out.println("¡Aprende desde lo básico hasta técnicas avanzadas!");
    }

    @Override
    public void establecerTutorial() {
        this.piezasDeAjedrez = "Las piezas de ajedrez son: rey, dama, torre, alfil, caballo y peón.";
        this.fundamentos = "El objetivo del juego es dar jaque mate al rey del oponente.";
        this.intermedio = "Controla el centro, desarrolla las piezas y protege al rey (enroque).";
        this.avanzado = "Tácticas: clavadas, ataques dobles, sacrificios, y finales estratégicos.";
    }

    @Override
    public String mostrarTutorial() {
        return "\n=== Tutorial de Ajedrez ===\n" +
                "1. Piezas de Ajedrez: " + this.piezasDeAjedrez + "\n" +
                "2. Fundamentos: " + this.fundamentos + "\n" +
                "3. Nivel Intermedio: " + this.intermedio + "\n" +
                "4. Nivel Avanzado: " + this.avanzado + "\n";
    }

    @Override
    public String editarTutorial(String seccion, String nuevoContenido) {
        switch (seccion.toLowerCase()) {
            case "piezas":
                this.piezasDeAjedrez = nuevoContenido;
                return "Sección 'piezas' actualizada.";
            case "fundamentos":
                this.fundamentos = nuevoContenido;
                return "Sección 'fundamentos' actualizada.";
            case "intermedio":
                this.intermedio = nuevoContenido;
                return "Sección 'intermedio' actualizada.";
            case "avanzado":
                this.avanzado = nuevoContenido;
                return "Sección 'avanzado' actualizada.";
            default:
                return "Sección no válida.";
        }
    }

    @Override
    public void editarTutorial(String piezas, String fundamentos, String intermedio, String avanzado) {
        this.piezasDeAjedrez = piezas;
        this.fundamentos = fundamentos;
        this.intermedio = intermedio;
        this.avanzado = avanzado;
    }

    @Override
    public void eliminarTutorial() {
        this.piezasDeAjedrez = "";
        this.fundamentos = "";
        this.intermedio = "";
        this.avanzado = "";
    }

    @Override
    public void eliminarTutorial(String seccion) {
        switch (seccion.toLowerCase()) {
            case "piezas":
                this.piezasDeAjedrez = "";
                break;
            case "fundamentos":
                this.fundamentos = "";
                break;
            case "intermedio":
                this.intermedio = "";
                break;
            case "avanzado":
                this.avanzado = "";
                break;
        }
    }
}
