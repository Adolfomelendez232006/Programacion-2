package org.example.Datos;

import org.example.dominio.Comentario;

public class ComentarioDAOMemoryImpl implements ComentarioDAO{
    private static final int TAMAÑO_INICIAL = 3;
    private Comentario[] comentarios;
    private int cantidadComentarios;


    @Override
    public String registrarComentario(String usuario, String texto) {
        // Verificar si necesitamos expandir el arreglo
        if (this.cantidadComentarios >= this.comentarios.length) {
            Comentario[] nuevoArreglo = new Comentario[this.comentarios.length * 2];
            System.arraycopy(this.comentarios, 0, nuevoArreglo, 0, this.comentarios.length);
            this.comentarios = nuevoArreglo;
        }

        Comentario nuevoComentario = new Comentario(usuario, texto);
        this.comentarios[this.cantidadComentarios] = nuevoComentario;
        this.cantidadComentarios++;
        return "Comentario registrado con éxito.";
    }

    @Override
    public String registrarComentario(Comentario nuevoComentario) {
        // Verificar si necesitamos expandir el arreglo
        if (this.cantidadComentarios >= this.comentarios.length) {
            Comentario[] nuevoArreglo = new Comentario[this.comentarios.length * 2];
            System.arraycopy(this.comentarios, 0, nuevoArreglo, 0, this.comentarios.length);
            this.comentarios = nuevoArreglo;
        }

        this.comentarios[this.cantidadComentarios] = nuevoComentario;
        this.cantidadComentarios++;
        return "Comentario registrado con éxito (desde objeto).";
    }

    @Override
    public String listarComentarios() {
        if (this.cantidadComentarios == 0) {
            return "No hay comentarios registrados.";
        }

        StringBuilder resultado = new StringBuilder("Lista de comentarios:\n");
        for (int i = 0; i < this.cantidadComentarios; i++) {
            resultado.append("[").append(i).append("] ")
                    .append(this.comentarios[i].toString()).append("\n");
        }
        return resultado.toString();
    }

    @Override
    public String listarComentarios(String autorBuscado) {
        StringBuilder resultado = new StringBuilder("Comentarios del autor '" + autorBuscado + "':\n");
        boolean encontrado = false;

        for (int i = 0; i < this.cantidadComentarios; i++) {
            if (this.comentarios[i].getAutor() != null &&
                    this.comentarios[i].getAutor().equalsIgnoreCase(autorBuscado)) {
                resultado.append("[").append(i).append("] ")
                        .append(this.comentarios[i].toString()).append("\n");
                encontrado = true;
            }
        }

        if (!encontrado) {
            resultado.append("No se encontraron comentarios de este autor.\n");
        }
        return resultado.toString();
    }

    @Override
    public String eliminarComentario(int indice) {
        if (indice < 0 || indice >= this.cantidadComentarios) {
            return "Índice inválido.";
        }

        // Desplazar elementos hacia la izquierda
        for (int i = indice; i < this.cantidadComentarios - 1; i++) {
            this.comentarios[i] = this.comentarios[i + 1];
        }

        // Limpiar la última posición
        this.comentarios[this.cantidadComentarios - 1] = null;
        this.cantidadComentarios--;

        return "Comentario eliminado.";
    }

    @Override
    public String eliminarComentario(String autor) {
        for (int i = 0; i < this.cantidadComentarios; i++) {
            if (this.comentarios[i].getAutor() != null &&
                    this.comentarios[i].getAutor().equals(autor)) {
                return eliminarComentario(i);
            }
        }
        return "No se encontró comentario con ese autor.";
    }

    @Override
    public String editarComentario(int indice, String nuevoContenido) {
        if (indice < 0 || indice >= this.cantidadComentarios) {
            return "Índice inválido.";
        }

        this.comentarios[indice].setContenido(nuevoContenido);
        return "Comentario editado.";
    }

    @Override
    public String editarComentario(int indice, String nuevoAutor, String nuevoContenido) {
        if (indice < 0 || indice >= this.cantidadComentarios) {
            return "Índice inválido.";
        }

        this.comentarios[indice].setAutor(nuevoAutor);
        this.comentarios[indice].setContenido(nuevoContenido);
        return "Autor y contenido del comentario editados.";
    }

    @Override
    public int getCantidadComentarios() {
        return this.cantidadComentarios;
    }


    // Metodo adicional para obtener un comentario específico por índice
    public Comentario obtenerComentario(int indice) {
        if (indice >= 0 && indice < this.cantidadComentarios) {
            return this.comentarios[indice];
        }
        return null;
    }

    // Metodo para verificar si el repositorio está vacío
    public boolean estaVacio() {
        return this.cantidadComentarios == 0;
    }
}
