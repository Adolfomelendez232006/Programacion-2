package org.example.dominio;

import java.time.LocalDateTime;

public class Comentario {
    private static final int TAMAÑO_INICIAL = 3;  // Tamaño inicial constante para el arreglo
    private static int contadorTotalComentarios = 0; // Contador total de comentarios creados

    private String autor;
    private String contenido;
    private LocalDateTime fecha;

    // Constructor por defecto
    public Comentario() {
        this.comentarios = new Comentario[3];
        this.cantidadComentarios = 0;
    }

    // Constructor con parámetros, usando this()
    public Comentario(String autor, String contenido) {
        this();// llama al constructor por defecto
        this.autor = autor;
        this.contenido = contenido;
        this.fecha = LocalDateTime.now();
        contadorTotalComentarios++;
    }

    public Comentario(String contenido) {
        this();// llama al constructor por defecto
        this.contenido = contenido;
        this.fecha = LocalDateTime.now();
        contadorTotalComentarios++;
    }

    // Getters para el contador total
    public static int getContadorTotalComentarios() {
        return contadorTotalComentarios;
    }

    // Getters y setters
    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public int getCantidadComentarios() {
        return cantidadComentarios;
    }
    /**
     * Registra un nuevo comentario.
     */
    int cantidadComentarios;
    Comentario comentarios[] = new Comentario[3];
    public String registrarComentario(String usuario, String texto) {
        if (this.cantidadComentarios >= this.comentarios.length) {
            Comentario[] nuevoArreglo = new Comentario[this.comentarios.length * 2];
            System.arraycopy(this.comentarios, 0, nuevoArreglo, 0, this.comentarios.length);
        }
        Comentario nuevoComentario = new Comentario(usuario, texto);
        this.comentarios[this.cantidadComentarios] = nuevoComentario;
        cantidadComentarios++;
        return "Comentario registrado con éxito.";
    }

    //sobrecarga: regirtrar un objeto comentario ya creado
    public String registrarComentario(Comentario nuevoComentario) {
        if (this.cantidadComentarios >= this.comentarios.length) {
            Comentario[] nuevoArreglo = new Comentario[this.comentarios.length * 2];
            System.arraycopy(this.comentarios, 0, nuevoArreglo, 0, this.comentarios.length);
        }
        this.comentarios[this.cantidadComentarios++] = nuevoComentario;
        return "Comentario registrado con éxito (desde objeto).";
    }

    /**
     * Lista todos los comentarios registrados.
     */
    public String listarComentarios() {
        String resultado = "Lista de comentarios:\n";
        for (int i = 0; i < this.cantidadComentarios; i++) {
            resultado += this.comentarios[i].toString() + "\n";
        }
        return resultado;
    }

    // Sobrecarga: listar comentarios por autor
    public String listarComentarios(String autorBuscado) {
        StringBuilder resultado = new StringBuilder("Comentarios del autor '" + autorBuscado + "':\n");
        boolean encontrado = false;
        for (int i = 0; i < this.cantidadComentarios; i++) {
            if (this.comentarios[i].getAutor().equalsIgnoreCase(autorBuscado)) {
                resultado.append(this.comentarios[i]).append("\n");
                encontrado = true;
            }
        }
        if (!encontrado) {
            resultado.append("No se encontraron comentarios de este autor.\n");
        }
        return resultado.toString();
    }

    /**
     * Elimina un comentario por su índice.
     */
    public String eliminarComentario(int indice) {
        if (indice >= 0 && indice < this.cantidadComentarios) {
            for (int i = indice; i < this.cantidadComentarios - 1; i++) {
                this.comentarios[i] = comentarios[i + 1];
            }
            this.comentarios[this.cantidadComentarios - 1] = null;
            this.cantidadComentarios--;
            return "Comentario eliminado.";
        } else {
            return "Índice inválido.";
        }
    }

    // Sobrecarga: eliminar por autor
    public String eliminarComentario(String autor) {
        for (int i = 0; i < this.cantidadComentarios; i++) {
            if (this.comentarios[i].getAutor().equals(autor)) {
                return eliminarComentario(i);
            }
        }
        return "No se encontró comentario con ese autor.";
    }

    /**
     * Edita el contenido de un comentario según su índice.
     */
    public String editarComentario(int indice, String nuevoContenido) {
        if (indice >= 0 && indice < this.cantidadComentarios) {
            this.comentarios[indice].setContenido(nuevoContenido);
            return "Comentario editado.";
        } else {
            return "Índice inválido.";
        }
    }

    // Sobrecarga: Editar autor y contenido
    public String editarComentario(int indice, String nuevoAutor, String nuevoContenido) {
        if (indice >= 0 && indice < this.cantidadComentarios) {
            this.comentarios[indice].setAutor(nuevoAutor);
            this.comentarios[indice].setContenido(nuevoContenido);
            return "Autor y contenido del comentario editados.";
        } else {
            return "Índice inválido.";
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true; // Mismo objeto
        if (o == null) return false; // Null no es igual
        if (getClass() != o.getClass()) return false; // Diferente clase no es igual

        Comentario otro = (Comentario) o; // Cast manual

        if (autor == null) {
            if (otro.autor != null) return false;
        } else if (!autor.equals(otro.autor)) {
            return false;
        }

        if (fecha == null) {
            if (otro.fecha != null) return false;
        } else if (!fecha.equals(otro.fecha)) {
            return false;
        }

        return true; // Si todo coincide
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = 31 * result + (autor == null ? 0 : autor.hashCode());
        result = 31 * result + (fecha == null ? 0 : fecha.hashCode());
        return result;
    }

    public Comentario[] obtenerCopiaComentarios() {
        Comentario[] copia = new Comentario[this.cantidadComentarios];
        for (int i = 0; i < this.cantidadComentarios; i++) {
            copia[i] = this.comentarios[i];
        }
        return copia;
    }

    public int compareTo(Comentario o) {
        int resultado = this.fecha.compareTo(o.getFecha());
        if (resultado > 0){
            return  1;
        } else if (resultado < 0){
            return -1;
        }else {
            return 0;
        }
    }

}

