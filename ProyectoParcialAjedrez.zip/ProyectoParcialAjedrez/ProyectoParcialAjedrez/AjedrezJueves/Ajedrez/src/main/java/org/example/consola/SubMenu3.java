package org.example.consola;

import org.example.dominio.Competencia;
import org.example.dominio.Genero;
import org.example.dominio.Jugador;
import org.example.dominio.Partida;
import org.example.ordenamientos.OrdenarJugadorApellido;
import org.example.ordenamientos.OrdenarJugadorId;
import org.example.util.Validador;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Clase que representa el submenú para la gestión de jugadores.
 * Permite registrar, modificar, consultar y eliminar jugadores dentro de una jugador.
 */
public class SubMenu3 {
    /**
     * Muestra el submenú de gestión de jugadores.
     * Permite al usuario interactuar con el sistema para realizar
     * operaciones CRUD (crear, leer, actualizar, eliminar) sobre jugadores.
     *
     */
    public static void subMenu3(String[] args){
        Competencia jugador = new Competencia();
        Partida jugador1 = new Partida();
        Genero genero = null;
        int op;
        boolean val1= true;
        Scanner leer = new Scanner(System.in);

        while (val1 == true) {
            System.out.println("");
            System.out.printf(
                    "%n" +
                            "╔══════════════════════════════════════════════════════════╗%n" +
                            "║                   👤 GESTIONAR JUGADOR 👤                ║%n" +
                            "╠══════════════════════════════════════════════════════════╣%n" +
                            "║  1. ➕ Registrar jugador                                 ║%n" +
                            "║  2. ✏️  Modificar jugador                                ║%n" +
                            "║  3. 🔍 Consultar jugador                                 ║%n" +
                            "║  4. ❌ Eliminar jugador                                  ║%n" +
                            "║  5. Mostrar jugadores ordenados                          ║%n" +
                            "║  6. 🚪 Salir                                             ║%n" +
                            "╚══════════════════════════════════════════════════════════╝%n" +
                            "👉 Ingrese la opción que desea seleccionar: "
            );
            op = Validador.pedirNumero(leer);
            System.out.println("");
            switch (op) {
                case 1:
                    System.out.println("H2.1. Registrar jugador.");
                    //Scanner sc = new Scanner(System.in);
                    int id = -1;
                    System.out.print("Ingrese el ID del jugador: ");
                    id = Validador.pedirNumero(leer);
                    System.out.print("Ingrese el nombre del jugador: ");
                    String nom = Validador.pedirNombre(leer);
                    System.out.print("Ingrese el apellido del jugador: ");
                    String apel = Validador.pedirNombre(leer);
                    System.out.print("Ingrese el nivel de conocimiento del juego: (principiante, intermedio, avanzado)");
                    String nivel = Validador.pedirNivel(leer);
                    jugador.registrarJugador(id, nom, apel, nivel, LocalDateTime.now(), Validador.ejegirGenero());
                    if (jugador.validarDuplicado(jugador)) {  // Si tienes este método
                        System.out.println("ERROR: Ya existe un jugador con ID " + id + " o con nombre " + nom + " " + apel);
                        System.out.println("Por favor, verifique los datos e intente nuevamente.");
                    } else {
                        System.out.println("Jugador registrado exitosamente.");
                    }
                    break;

                case 2:
                    System.out.println("H2.2. Modificar jugador.");
                    System.out.println("Jugadores actuales: ");
                    for (int i = 0; i < jugador.getNumJugadores(); i++) {
                        System.out.println("[" + i + "] " + jugador.getJugadores(i));
                    }

                    System.out.print("Ingrese el id del jugador a modificar: ");
                    int idBuscado = Validador.pedirNumero(leer);

                    int indice = jugador.buscarIndicePorId(idBuscado);

                    if (indice == -1) {
                        System.out.println("Jugador con ID " + idBuscado + " no encontrado.");
                    } else {
                        System.out.println("Jugador anterior: " + jugador.jugadores[indice]);

                        // Pedir datos nuevos (por ejemplo)
                        System.out.print("Nuevo ID: ");
                        int nuevoId = leer.nextInt();

                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = leer.next();

                        System.out.print("Nuevo apellido: ");
                        String nuevoApellido = leer.next();

                        System.out.print("Nuevo nivel de conocimiento (principiante, intermedio, avanzado): ");
                        String nuevoNivel = leer.next();

                        jugador.modificarJugador(indice, nuevoId, nuevoNombre, nuevoApellido, nuevoNivel, LocalDateTime.now(),Validador.ejegirGenero());
                    }
                    break;
                case 3:
                    System.out.println("H2.1. Consultar jugador.");
                    System.out.print("Ingrese el ID del jugador a consultar: ");

                    int idConsulta = Validador.pedirNumero(leer);
                    leer.nextLine(); // limpiar salto

                    Jugador encontrado = jugador.buscarJugador(idConsulta);

                    if (encontrado != null) {
                        System.out.println("Jugador encontrado:");
                        System.out.println(encontrado);
                    } else {
                        System.out.println("No se encontró ningún jugador con ese ID.");
                    }
                    break;
                case 4:
                    System.out.println("H2.1. Eliminar jugador.");
                    System.out.print("Ingrese el ID del jugador que desea eliminar: ");
                    int idEliminar = Validador.pedirNumero(leer);
                    leer.nextLine();

                    boolean eliminado = jugador.borrarJugador(idEliminar);

                    if (eliminado) {
                        System.out.println("Jugador eliminado correctamente.");
                    } else {
                        System.out.println("No se encontró ningún jugador con ese ID.");
                    }
                    break;
                case 5:
                    System.out.println("H2.5 Jugadores ordenados por nombre");
                    List<Jugador> listaJugador= new ArrayList<>(4);
                    for (int i=0; i<jugador.getNumJugadores(); i++){
                        Jugador j= jugador.getJugadores(i);
                        if(j != null){
                            listaJugador.add(j);
                        }
                    }
                    // Comparator<Jugador> ordenId= new OrnedarJugadorId();
                    //Comparator<Jugador> ordenApellido= new OrdenarJugadorApellido();
                    System.out.println("==================================");
                    System.out.println("|> Ordendo por ID: ");
                    listaJugador.sort(new OrdenarJugadorId());
                    for (Jugador ju:listaJugador){
                        System.out.println(ju);
                    }
                    System.out.println("");
                    System.out.println("==================================");
                    System.out.println("|> Ordenado por nombre: ");
                    Set<Jugador> jugadoresOrdenados= new TreeSet<>();
                    for (int i=0; i< jugador.getNumJugadores();i++){
                        Jugador ju= jugador.getJugadores(i);
                        if (ju!=null){
                            jugadoresOrdenados.add(ju);
                        }
                    }
                    for (Jugador ju:jugadoresOrdenados){
                        System.out.println(ju);
                    }
                    System.out.println("");
                    System.out.println("==================================");
                    System.out.println("|> Ordendo por Apellido: ");
                    listaJugador.sort(new OrdenarJugadorApellido());
                    for (Jugador ju:listaJugador){
                        System.out.println(ju);
                    }
                    break;
                case 6:
                    val1 = false;
                    break;
                default:
                    System.out.println("Este valor no esta disponible.");
            }
        }
    }
}
