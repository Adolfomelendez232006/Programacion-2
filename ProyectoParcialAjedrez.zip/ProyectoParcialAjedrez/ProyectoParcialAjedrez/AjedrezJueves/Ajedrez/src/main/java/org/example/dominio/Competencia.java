package org.example.dominio;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

/**
 * Esta clase representa una competencia o torneo.
 * Aquí se guarda la información del torneo, como su nombre, las fechas,
 * los participantes y los enfrentamientos que se generan.
 */
public class Competencia {
    private String nombreTorneo;
    private Date fechaInicio;
    private Date fechaFin;
    private boolean iniciada;
    private boolean finalizada;
    private EstadoCompetencia estado;
    public static final int CAPACIDAD_INICIAL_JUGADORES = 3;
    public static final int CAPACIDAD_INICIAL_PARTIDAS = 3;
    public static final int FACTOR_EXPANSION = 2;
    // Contador estático para llevar el control de competencias creadas
    private static int contadorCompetencias = 0;
    // Instancia única para el patrón Singleton
    private final static Competencia instancia = new Competencia();
    // ID único de la competencia (final, se asigna una sola vez)
    private final int idCompetencia;
    // Arreglos para manejar las entidades relacionadas
    public Jugador[] jugadores;
    private Partida[] partidas;

    // Contadores para llevar el control de elementos actuales
    private int numJugadores = 0;
    private int numEnfrentamientos;
    private int numRecompensas;
    private int numPartidas;

    private void inicializarArreglos() {
        this.jugadores = new Jugador[CAPACIDAD_INICIAL_JUGADORES];
        this.partidas = new Partida[CAPACIDAD_INICIAL_PARTIDAS];
        this.numJugadores = 0;
        this.numEnfrentamientos = 0;
        this.numRecompensas = 0;
        this.numPartidas = 0;
    }
    public Competencia(){
        this("Sin nombre de Torneo",new Date(),new Date());
    }
    /**
     * Constructor para crear una competencia.
     * Verifica que el nombre y las fechas sean válidas antes de guardar.
     *
     * @param nombreTorneo nombre del torneo.
     * @param fechaInicio  cuándo empieza el torneo.
     * @param fechaFin     cuándo termina el torneo.
     */
    public Competencia(String nombreTorneo, Date fechaInicio, Date fechaFin) {

        //instancia = new Competencia(nombreTorneo, fechaInicio, fechaFin);
        // Validaciones del nombre
        if (nombreTorneo == null || nombreTorneo.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (!nombreTorneo.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras");
        }
        if (nombreTorneo.length() < 2) {
            throw new IllegalArgumentException("El nombre debe tener al menos 2 caracteres");
        }

        // Validaciones de fechas
        if (fechaInicio == null || fechaFin == null) {
            throw new IllegalArgumentException("Las fechas no pueden ser nulas.");
        }
        if (fechaFin.before(fechaInicio)) {
            throw new IllegalArgumentException("La fecha de fin no puede ser anterior a la de inicio.");
        }
        this.idCompetencia=++contadorCompetencias;
        this.nombreTorneo = nombreTorneo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.iniciada = false;
        this.finalizada = false;
        this.estado = EstadoCompetencia.NO_INICIADA;
        inicializarArreglos();
    }
    // Métodos Singleton
    public static Competencia getInstancia() {
//        if (instancia == null) {
//            instancia = new Competencia();
//        }
        return instancia;
    }
//        public static Competencia setInstancia(String nombreTorneo, Date fechaInicio, Date fechaFin) {
//        if (instancia == null) {
//
//        }
//        return instancia;
//    }

    // Método para reiniciar la instancia
//        public static void reiniciarInstancia() {
//        instancia = null;
//    }

    public static void reiniciarContador() {
        contadorCompetencias = 0;
    }
    /**
     * Agrega un nuevo participante a la competencia si no ha sido agregado antes.
     *
     * @param nombre Nombre del jugador a agregar.
     */
    public void registrarJugador(int id, String nombre, String apellido, String conocimiento, LocalDateTime fecha, Genero genero) {
        if (buscarJugador(id) != null) {
            throw new IllegalArgumentException("Ya existe un jugador con este id.");
        }

        if (numJugadores >= jugadores.length) {
            Jugador[] nuevoArreglo = new Jugador[jugadores.length * 2];
            System.arraycopy(jugadores, 0, nuevoArreglo, 0, jugadores.length);
            jugadores = nuevoArreglo;
        }

        jugadores[numJugadores] = new Jugador(id, nombre, apellido, conocimiento, fecha, genero);
        numJugadores++;
    }

    public void registrarJugador(Jugador jugador) {
        if (jugador == null || buscarJugador(jugador.getIdJugador()) != null) return;

        if (numJugadores >= jugadores.length) {
            Jugador[] nuevoArreglo = new Jugador[jugadores.length * 2];
            System.arraycopy(jugadores, 0, nuevoArreglo, 0, jugadores.length);
            jugadores = nuevoArreglo;
        }

        jugadores[numJugadores] = jugador;
        numJugadores++;
    }

    /**
     * Busca un jugador por su ID
     * @param id identifica el jugador a buscar
     * @return El jugador encontrado, o null si no existe
     */

    public Jugador buscarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                return jugadores[i];
            }
        }
        return null;
    }

    /**
     * Busca el índice de un jugador por su ID
     */
    public int buscarIndicePorId(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Editar los datos de un jugador existente en la posicion especifica
     * @param indice posicion del jugador a editar
     * @param id nuevo Id del jugador
     * @param nombre nuevo nombre del jugador
     * @param apellido nuevo apellido del jugador
     * @param conocimiento nuevo nivel de conocimiento
     * @param fecha nueva fecha de registro
     */
    public void modificarJugador(int indice, int id, String nombre, String apellido, String conocimiento, LocalDateTime fecha, Genero genero) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        jugadores[indice] = new Jugador(id, nombre, apellido, conocimiento, fecha, genero);
    }

    public void modificarJugador(int indice, Jugador jugador) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo.");
        }

        boolean idCambiado = jugadores[indice].getIdJugador() != jugador.getIdJugador();
        boolean idYaExiste = buscarJugador(jugador.getIdJugador()) != null;

        if (idCambiado && idYaExiste) {
            throw new IllegalArgumentException("Ya existe otro jugador con ese ID.");
        }

        jugadores[indice] = jugador;
    }
    /**
     * Elimina un jugador de la parida por su Id
     * @param id identificador del jugador a eliminar
     * @return true si el jugador fue eliminado o false si no es encontrado
     */
    public boolean borrarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i].getIdJugador() == id) {
                // Desplazar los jugadores a la izquierda
                for (int j = i; j < numJugadores - 1; j++) {
                    jugadores[j] = jugadores[j + 1];
                }
                jugadores[numJugadores - 1] = null;
                numJugadores--;
                return true;
            }
        }
        return false;
    }
    /**
     * Expande el arreglo de partidas
     */
    private void expandirArregloPartidas() {
        Partida[] nuevoArreglo = new Partida[partidas.length * 2];
        System.arraycopy(partidas, 0, nuevoArreglo, 0, partidas.length);
        partidas = nuevoArreglo;
    }
    /**
     * Agrega una partida a la competencia
     */
    public void agregarPartida(Partida partida) {
        if (numPartidas >= partidas.length) {
            expandirArregloPartidas();
        }
        partidas[numPartidas] = partida;
        numPartidas++;
    }

    public Partida obtenerPartida(int indice) {
        if (indice >= 0 && indice < numPartidas) {
            return partidas[indice];
        }
        return null;
    }

    public void editarPartida(int indice, Partida nuevaPartida) {
        if (indice < 0 || indice >= numPartidas) {
            throw new IndexOutOfBoundsException("Índice de partida no válido.");
        }

        if (nuevaPartida == null) {
            throw new IllegalArgumentException("La partida no puede ser nula.");
        }

        for (int i = 0; i < numPartidas; i++) {
            if (i != indice && partidas[i].equals(nuevaPartida)) {
                throw new IllegalArgumentException("Ya existe una partida igual.");
            }
        }

        partidas[indice] = nuevaPartida;
    }

    public boolean borrarPartida(int indice) {
        if (indice < 0 || indice >= numPartidas) {
            return false;
        }

        for (int i = indice; i < numPartidas - 1; i++) {
            partidas[i] = partidas[i + 1];
        }

        partidas[numPartidas - 1] = null;
        numPartidas--;
        return true;
    }
    public boolean validarDuplicado(Object obj) {
        if (obj == null) return false;

        // Validar duplicado de Jugador
        if (obj instanceof Jugador) {
            Jugador jugador = (Jugador) obj;
            for (int i = 0; i < numJugadores; i++) {
                if (jugadores[i] != null && jugadores[i].equals(jugador)) {
                    return true;
                }
            }
        }
        // Validar duplicado de Partida
        else if (obj instanceof Partida) {
            Partida partida = (Partida) obj;
            for (int i = 0; i < numPartidas; i++) {
                if (partidas[i] != null && partidas[i].equals(partida)) {
                    return true;
                }
            }
        }

        return false; // Si no es ninguno de los anteriores o no hay duplicado
    }

    /**
     * Método estático para obtener el número total de competencias creadas
     */
    public static int getTotalCompetenciasCreadas() {
        return contadorCompetencias;
    }
    /**
     * Inicia la competencia si aún no ha comenzado.
     * Muestra un mensaje diciendo si se pudo iniciar o si ya estaba iniciada.
     */
    public void iniciarCompetencia() {
        if (!iniciada) {
            this.iniciada = true;
            System.out.println("Competencia iniciada.");
        } else {
            System.out.println("La competencia ya estaba iniciada.");
        }
    }
    /**
     * Marca la competencia como iniciada directamente.
     */

    public void setIniciarCompetencia() {
        this.iniciada = true;
    }

    /**
     * Marca la competencia como finalizada y muestra un mensaje.
     */

    public void finalizarCompetencia() {
        this.finalizada = true;
        System.out.println("Competencia finalizada.");
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Competencia that = (Competencia) obj;
        return Objects.equals(nombreTorneo, that.nombreTorneo) &&
                Objects.equals(fechaInicio, that.fechaInicio) &&
                Objects.equals(fechaFin, that.fechaFin);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreTorneo, fechaInicio, fechaFin);
    }
    // Métodos getter y setter
    public String getNombreTorneo() {
        return nombreTorneo;
    }

    public void setNombreTorneo(String nombreTorneo) {
        this.nombreTorneo = nombreTorneo;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public boolean isIniciada() {
        return iniciada;
    }

    public boolean isFinalizada() {
        return finalizada;
    }

    public int getNumJugadores() {
        return numJugadores;
    }

    public int getNumEnfrentamientos() {
        return numEnfrentamientos;
    }

    public int getNumRecompensas() {
        return numRecompensas;
    }

    public int getNumPartidas() {
        return numPartidas;
    }

    public Jugador getJugadores(int indice) {
        if (indice >= 0 && indice < numJugadores) {
            return jugadores[indice];
        } else {
            return null;
        }
    }
    public Partida[] getPartidas() {
        return partidas;
    }

    /**
     * Representación en cadena de la competencia con toda su información
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        // Encabezado principal
        sb.append(String.format("%n╔%s╗%n", "═".repeat(70)));
        sb.append(String.format("║%70s║%n", "INFORMACIÓN DE LA COMPETENCIA"));
        sb.append(String.format("╚%s╝%n%n", "═".repeat(70)));

        // Información básica de la competencia
        sb.append(String.format("┌%s┐%n", "─".repeat(70)));
        sb.append(String.format("│%70s│%n", "DATOS BÁSICOS"));
        sb.append(String.format("├%s┤%n", "─".repeat(70)));
        sb.append(String.format("│ %-20s: %-47s│%n", "Nombre del Torneo", nombreTorneo));
        sb.append(String.format("│ %-20s: %-47s│%n", "Fecha de Inicio", fechaInicio));
        sb.append(String.format("│ %-20s: %-47s│%n", "Fecha de Fin", fechaFin));
        sb.append(String.format("│ %-20s: %-47s│%n", "Estado", estado.getDescripcion()));
        sb.append(String.format("└%s┘%n%n", "─".repeat(70)));

        // Información de jugadores
        sb.append(String.format("┌%s┐%n", "─".repeat(70)));
        sb.append(String.format("│%70s│%n", String.format("JUGADORES REGISTRADOS (%d)", numJugadores)));
        sb.append(String.format("├%s┤%n", "─".repeat(70)));

        if (numJugadores == 0) {
            sb.append(String.format("│%70s│%n", "No hay jugadores registrados"));
        } else {
            for (int i = 0; i < numJugadores; i++) {
                sb.append(String.format("│ %2d. %-64s│%n", (i + 1), jugadores[i].toString()));
            }
        }
        sb.append(String.format("└%s┘%n%n", "─".repeat(70)));

        // Información de partidas
        sb.append(String.format("┌%s┐%n", "─".repeat(70)));
        sb.append(String.format("│%70s│%n", String.format("PARTIDAS (%d)", numPartidas)));
        sb.append(String.format("├%s┤%n", "─".repeat(70)));

        if (numPartidas == 0) {
            sb.append(String.format("│%70s│%n", "No hay partidas registradas"));
        } else {
            for (int i = 0; i < numPartidas; i++) {
                sb.append(String.format("│ %2d. %-64s│%n", (i + 1), partidas[i].toString()));
            }
        }
        sb.append(String.format("└%s┘%n", "─".repeat(70)));

        return sb.toString();
    }

    public int compareTo(Competencia o) {
        int resultado = this.nombreTorneo.compareTo(o.getNombreTorneo());
        if(resultado>0){
            return 1;
        } else if (resultado<0) {
            return -1;
        }else
            return 0;
    }
}


