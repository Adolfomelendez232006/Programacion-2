package org.example.ordenamientos;

import org.example.dominio.Recompensa;

import java.util.Comparator;

public class OrdenarRecompensaNombre implements Comparator<Recompensa> {
    @Override
    public int compare(Recompensa o1, Recompensa o2) {
        int resultado = o1.getNombre().compareTo(o2.getNombre());
        if(resultado != 0){
            return resultado;
        }else {
            return 0;
        }
    }
}
