package org.example.ordenamientos;

import org.example.dominio.Jugador;

import java.util.Comparator;

public class OrdenarJugadorApellido implements Comparator<Jugador> {
    @Override
    public int compare(Jugador o1, Jugador o2) {
        int resultado= o1.getApellido().compareTo(o2.getApellido());
        if(resultado != 0){
            return resultado;
        }else
            return 0;
    }
}
