package org.example.Datos;

import org.example.dominio.Recompensa;

public interface SolicitudDeRecompensaDAO {
    boolean crearSolicitud(Recompensa recompensa);
    boolean rechazarSolicitud(String motivoDeRechazo);
    boolean aprobarSolicitud();
    boolean procesarSolicitud();
    String estadoDeSolicitud();
    boolean estaPendiente();
    boolean estaAprobado();
    boolean estRechazada();
    boolean estaProcesada();
}
