package org.example.Datos;

public interface RecompensaDAO {

    String mostrarMensaje();
    String completarLogro(String nombre);
    void reiniciarLogro();
    boolean estaPendiente();
    void asignarDescripcionPorDefecto();
}
