package org.example.dominio;

public enum EstadoCompetencia {
    NO_INICIADA("No iniciada"),
    EN_CURSO("En curso"),
    FINALIZADA("Finalizada"),
    CANCELADA("Cancelada"),
    PAUSADA("Pausada");

    private String descripcion;

    EstadoCompetencia(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
