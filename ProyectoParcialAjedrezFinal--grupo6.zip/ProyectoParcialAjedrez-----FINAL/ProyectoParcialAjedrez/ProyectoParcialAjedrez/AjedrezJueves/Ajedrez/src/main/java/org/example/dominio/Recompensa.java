package org.example.dominio;
import java.io.Serializable;
import java.util.Objects;

/**
 * Representacion de las recompensas que se le puede otorgar a un jugador,
 * con una la cantidad especifica de puntos
 *
 * <p>Los tipos de recompensa validos son:
 * <ul>
 *     <li><b>Ganador</b>: 100 puntos</li>
 *     <li><b>Empate</b>: 50 puntos</li>
 *     <li><b>Perdedor</b>: 0 puntos</li>
 * </ul>
 * </p>
 */
public abstract class Recompensa implements Comparable<Recompensa>, Serializable {
    private static final long serialVersionUID = 1L;

    private String nombre;
    private String descripcion;
    private int puntos;
    private String nombreNormalizado;

    /**
     * Constructor que cra una nueva recompensa del tipo especifico
     *  nombre de la recompensa (Ganador/Empate/Perdedor)
     */
    public Recompensa() {
        this.nombre = "";
        this.descripcion = "";
        this.puntos = 0;
        this.nombreNormalizado = "";
        mostrarMensaje();
    }
    public Recompensa(String nombre, String descripcion, int puntos) {
        setNombre(nombre);
        this.descripcion = descripcion;
        this.puntos = puntos;
        mostrarMensaje();
    }
    /**
     * Constructor específico para tipos predefinidos
     * @param tipoRecompensa tipo de recompensa (Ganador/Empate/Perdedor)
     */
    public Recompensa(String tipoRecompensa) {
        setNombre(tipoRecompensa);
        asignarDescripcionPorDefecto();
        mostrarMensaje();
    }

    /**
     * Obtiene la cantidad de puntos asociados a la recompensa
     *
     * @return los puntos de la recompensa
     */
    // Getters y Setters
    public String getNombre() { return nombre; }

    /* Establece el nombre de recompensa y asignación automática de los
     * puntos correspondientes
     * @param nombre el nombre de la recompensa
     */
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo o vacío");
        }

        this.nombreNormalizado = nombre.trim().toLowerCase();

        switch (this.nombreNormalizado) {
            case "ganador":
                this.nombre = "Ganador";
                this.puntos = 100;
                break;
            case "empate":
                this.nombre = "Empate";
                this.puntos = 50;
                break;
            case "perdedor":
                this.nombre = "Perdedor";
                this.puntos = 0;
                break;
            default:
                throw new IllegalArgumentException("El nombre debe ser 'Ganador', 'Empate' o 'Perdedor'");
        }
    }

    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion != null ? descripcion : "";
    }

    public int getPuntos() {
        return puntos;
    }
    public void setPuntos(int puntos) {
        if (puntos < 0) {
            throw new IllegalArgumentException("Los puntos no pueden ser negativos");
        }
        this.puntos = puntos;
    }
    /**
     * Imprime mensaje por consola indicando los puntos obtenidos de las
     * recompensas. Este metodo es privdo y se llama automaticamente al
     * crear la recompensa
     */
    private String mostrarMensaje() {
        if (!nombre.isEmpty()) {
            return "Tiene " + puntos + " puntos por ser " + nombre.toLowerCase();
        }
        return "";
    }

    public abstract String completarLogro(String nombre);
    public abstract void reiniciarLogro();
    public abstract boolean estaPendiente();
    public abstract String getEstadoTexto();
    /**
     * Asigna descripción por defecto según el tipo de recompensa
     */
    private void asignarDescripcionPorDefecto() {
        switch (this.nombreNormalizado) {
            case "ganador":
                this.descripcion = "¡Felicitaciones! Has ganado la partida";
                break;
            case "empate":
                this.descripcion = "Buen juego, ha sido un empate";
                break;
            case "perdedor":
                this.descripcion = "Sigue intentando, la próxima será mejor";
                break;
            default:
                this.descripcion = "Recompensa personalizada";
        }
    }

    /**
     * Devuelve una representacion en cadena de la recompensa
     * @return cadena que describe el nombre y puntos de la recompensa
     */

    @Override
    public String toString() {
        return String.format(
                "Recompensa:%n" +
                        "Nombre: %-20s%n" +
                        "Puntos: %-10d",
                nombre, puntos
        );
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Recompensa that = (Recompensa) obj;
        return Objects.equals(nombre, that.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
    //crear el metodo completar logro
    public void completarLogro() {}

    public int compareTo(Recompensa o) {
        int resultado = this.nombre.compareTo(o.getNombre());
        if(resultado>0){
            return 1;
        } else if (resultado<0) {
            return -1;
        }else
            return 0;
    }
}
