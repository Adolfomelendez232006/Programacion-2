package org.example.dominio;

import java.io.*;
import java.util.Objects;

/**
 * Proporciona un tutorial sobre ajedrez, incluyendo información
 * sobre piezas, fundamentos básicos, estrategias intermedias y
 * técnicas avanzadas.
 * <p>El tutorial está organizado en cuatro secciones principales:
 * <ol>
 *     <li>Descripción de las piezas de ajedrez</li>
 *     <li>Fundamentos básicos del juego</li>
 *     <li>Consejos y estrategias de nivel intermedio</li>
 *     <li>Técnicas avanzadas y tácticas</li>
 * </ol>
 * </p>
 */
public class Tutorial implements Serializable {
    // Serial version UID para compatibilidad de serialización
    private static final long serialVersionUID = 1L;

    public String piezasDeAjedrez;
    public String fundamentos;
    public String intermedio;
    public String avanzado;

    // final - estos campos estáticos no se serializan
    public static final String VERSION = "1.0";
    public static final String AUTOR = "Administrador";

    // Constructor predeterminado que configura el tutorial
    public Tutorial() {
        establecerTutorial();
    }

    // Constructor para deserialización JSON
    public Tutorial(String piezas, String fundamentos, String intermedio, String avanzado) {
        this.piezasDeAjedrez = piezas;
        this.fundamentos = fundamentos;
        this.intermedio = intermedio;
        this.avanzado = avanzado;
    }

    // Este metodo estático puede mostrarse sin crear un objeto Tutorial
    public static void mostrarIntroduccion() {
        String separador = "=".repeat(50);
        System.out.printf("%s%n", separador);
        System.out.printf("%-5s Tutorial de Ajedrez v%s%n", "", VERSION);
        System.out.printf("%-5s Creado por: %s%n", "", AUTOR);
        System.out.printf("%s%n", separador);
        System.out.printf("%s ¡Aprende desde lo básico hasta técnicas avanzadas!%n", "");
        System.out.printf("%s%n", separador);
    }

    // Constructor predeterminado que configura el tutorial
    public void establecerTutorial() {
        this.piezasDeAjedrez = String.format("Las piezas de ajedrez son: %s, %s, %s, %s, %s y %s.",
                "rey", "dama", "torre", "alfil", "caballo", "peón");

        this.fundamentos = String.format("El objetivo del juego es dar %s al %s del %s.",
                "jaque mate", "rey", "oponente");

        this.intermedio = String.format("%s el %s, %s las %s y %s al %s (%s).",
                "Controla", "centro", "desarrolla", "piezas", "protege", "rey", "enroque");

        this.avanzado = String.format("Tácticas: %s, %s, %s, y %s.",
                "clavadas", "ataques dobles", "sacrificios", "finales estratégicos");
    }

    public String mostrarTutorial() {
        return String.format(
                "%n╔══════════════════════════════════════════╗%n" +
                        "║            TUTORIAL DE AJEDREZ           ║%n" +
                        "╠══════════════════════════════════════════╣%n" +
                        "[1] Piezas de Ajedrez:   %-15s %n" +
                        "[2] Fundamentos:         %-15s %n" +
                        "[3] Nivel Intermedio:    %-15s %n" +
                        "[4] Nivel Avanzado:      %-15s %n",
                this.piezasDeAjedrez, this.fundamentos, this.intermedio, this.avanzado
        );
    }

    // Metodo principal para editar secciones
    public String editarTutorial(String seccion, String nuevoContenido) {
        switch (seccion.toLowerCase()) {
            case "piezas":
                this.piezasDeAjedrez = nuevoContenido;
                return "Sección 'piezas' actualizada.";
            case "fundamentos":
                this.fundamentos = nuevoContenido;
                return "Sección 'fundamentos' actualizada.";
            case "intermedio":
                this.intermedio = nuevoContenido;
                return "Sección 'intermedio' actualizada.";
            case "avanzado":
                this.avanzado = nuevoContenido;
                return "Sección 'avanzado' actualizada.";
            default:
                return "Sección no válida.";
        }
    }

    // Sobrecarga: permite editar todas las secciones a la vez
    public void editarTutorial(String piezas, String fundamentos, String intermedio, String avanzado) {
        this.piezasDeAjedrez = piezas;
        this.fundamentos = fundamentos;
        this.intermedio = intermedio;
        this.avanzado = avanzado;
    }

    // Elimina todo el contenido
    public void eliminarTutorial() {
        this.piezasDeAjedrez = "";
        this.fundamentos = "";
        this.intermedio = "";
        this.avanzado = "";
    }

    // Sobrecarga: elimina solo una sección específica
    public void eliminarTutorial(String seccion) {
        switch (seccion.toLowerCase()) {
            case "piezas":
                this.piezasDeAjedrez = "";
                break;
            case "fundamentos":
                this.fundamentos = "";
                break;
            case "intermedio":
                this.intermedio = "";
                break;
            case "avanzado":
                this.avanzado = "";
                break;
        }
    }

    // equals y hashCode
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Tutorial)) return false;
        Tutorial t = (Tutorial) obj;
        return Objects.equals(this.piezasDeAjedrez, t.piezasDeAjedrez) &&
                Objects.equals(this.fundamentos, t.fundamentos) &&
                Objects.equals(this.intermedio, t.intermedio) &&
                Objects.equals(this.avanzado, t.avanzado);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.piezasDeAjedrez, this.fundamentos, this.intermedio, this.avanzado);
    }

    // ====================== MÉTODOS DE SERIALIZACIÓN ======================

    // SERIALIZACIÓN BINARIA - Guardar en archivo
    public void guardarEnArchivo(String nombreArchivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            oos.writeObject(this);
            System.out.println("Tutorial guardado en: " + nombreArchivo);
        }
    }

    // DESERIALIZACIÓN BINARIA - Cargar desde archivo
    public static Tutorial cargarDesdeArchivo(String nombreArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            Tutorial tutorial = (Tutorial) ois.readObject();
            System.out.println("Tutorial cargado desde: " + nombreArchivo);
            return tutorial;
        }
    }


    // SERIALIZACIÓN A FORMATO PERSONALIZADO
    public String toCustomFormat() {
        StringBuilder sb = new StringBuilder();
        sb.append("TUTORIAL_DATA\n");
        sb.append("VERSION=").append(VERSION).append("\n");
        sb.append("AUTOR=").append(AUTOR).append("\n");
        sb.append("PIEZAS=").append(piezasDeAjedrez != null ? piezasDeAjedrez.replace("\n", "\\n") : "").append("\n");
        sb.append("FUNDAMENTOS=").append(fundamentos != null ? fundamentos.replace("\n", "\\n") : "").append("\n");
        sb.append("INTERMEDIO=").append(intermedio != null ? intermedio.replace("\n", "\\n") : "").append("\n");
        sb.append("AVANZADO=").append(avanzado != null ? avanzado.replace("\n", "\\n") : "").append("\n");
        sb.append("END_TUTORIAL");
        return sb.toString();
    }

    // DESERIALIZACIÓN DESDE FORMATO PERSONALIZADO
    public static Tutorial fromCustomFormat(String data) {
        Tutorial tutorial = new Tutorial();
        tutorial.piezasDeAjedrez = "";
        tutorial.fundamentos = "";
        tutorial.intermedio = "";
        tutorial.avanzado = "";

        String[] lineas = data.split("\n");
        for (String linea : lineas) {
            if (linea.startsWith("PIEZAS=")) {
                tutorial.piezasDeAjedrez = linea.substring(7).replace("\\n", "\n");
            } else if (linea.startsWith("FUNDAMENTOS=")) {
                tutorial.fundamentos = linea.substring(12).replace("\\n", "\n");
            } else if (linea.startsWith("INTERMEDIO=")) {
                tutorial.intermedio = linea.substring(11).replace("\\n", "\n");
            } else if (linea.startsWith("AVANZADO=")) {
                tutorial.avanzado = linea.substring(9).replace("\\n", "\n");
            }
        }
        return tutorial;
    }

    // GUARDAR EN FORMATO PERSONALIZADO
    public void guardarFormatoPersonalizado(String nombreArchivo) throws IOException {
        try (FileWriter writer = new FileWriter(nombreArchivo)) {
            writer.write(toCustomFormat());
            System.out.println("Tutorial guardado en formato personalizado: " + nombreArchivo);
        }
    }

    // CARGAR DESDE FORMATO PERSONALIZADO
    public static Tutorial cargarFormatoPersonalizado(String nombreArchivo) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
            StringBuilder data = new StringBuilder();
            String linea;
            while ((linea = reader.readLine()) != null) {
                data.append(linea).append("\n");
            }
            System.out.println("Tutorial cargado desde formato personalizado: " + nombreArchivo);
            return fromCustomFormat(data.toString());
        }
    }

    // SERIALIZACIÓN A BYTES (en memoria)
    public byte[] toBytes() throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeObject(this);
            return baos.toByteArray();
        }
    }

    // DESERIALIZACIÓN DESDE BYTES
    public static Tutorial fromBytes(byte[] bytes) throws IOException, ClassNotFoundException {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
             ObjectInputStream ois = new ObjectInputStream(bais)) {
            return (Tutorial) ois.readObject();
        }
    }

    @Override
    public String toString() {
        return String.format("Tutorial[piezas='%s', fundamentos='%s', intermedio='%s', avanzado='%s']",
                piezasDeAjedrez, fundamentos, intermedio, avanzado);
    }
}
