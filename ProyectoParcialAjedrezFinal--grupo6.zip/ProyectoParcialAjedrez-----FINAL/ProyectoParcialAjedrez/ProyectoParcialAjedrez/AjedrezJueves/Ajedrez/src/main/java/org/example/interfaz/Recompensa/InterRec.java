package org.example.interfaz.Recompensa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;


    public class InterRec extends JFrame {
        private JPanel PanelRe;
        private JButton volverButton;
        private JButton registrarRecompensaButton;
        private JButton registrarLogroButton;
        private JButton consultarRecompensasYLogrosButton;
        private JButton completarLogroButton;
        private JLabel textRecompensa;

        // Listas para almacenar datos
        private List<Recompensa> recompensas;
        private List<Logro> logros;
        private JFrame parentFrame;

        public InterRec(JFrame parentFrame) {
            this.parentFrame = parentFrame;
            initComponents();
            recompensas = new ArrayList<>();
            logros = new ArrayList<>();

            // Inicializar datos por defecto
            inicializarLogros();
            inicializarRecompensas();

            addListeners();
            setTitle("Gestión de Recompensas y Logros");
            setSize(800, 600);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }

        public InterRec() {
            this(null);
        }

        public static void showInterRec(JFrame parentFrame) {
            org.example.interfaz.Recompensa.InterRec ventana = new org.example.interfaz.Recompensa.InterRec(parentFrame);
            ventana.setVisible(true);
            if (parentFrame != null) {
                parentFrame.setVisible(false);
            }
        }

        private void initComponents() {
            // Configurar el panel principal
            PanelRe = new JPanel();
            PanelRe.setLayout(new BorderLayout());
            PanelRe.setBackground(new Color(130, 160, 180)); // Color azul similar a la imagen

            // Crear título
            textRecompensa = new JLabel("RECOMPENSAS", SwingConstants.CENTER);
            textRecompensa.setFont(new Font("Arial", Font.BOLD, 24));
            textRecompensa.setForeground(Color.BLACK);
            textRecompensa.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

            // Crear botón "Volver" en la esquina superior izquierda
            volverButton = new JButton("Volver");
            volverButton.setPreferredSize(new Dimension(100, 30));
            volverButton.setBackground(Color.WHITE);
            volverButton.setForeground(Color.BLACK);
            volverButton.setFocusPainted(false);
            volverButton.setBorder(BorderFactory.createRaisedBevelBorder());

            JPanel topPanel = new JPanel(new BorderLayout());
            topPanel.setBackground(new Color(130, 160, 180));
            topPanel.add(volverButton, BorderLayout.WEST);
            topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

            // Crear botones principales
            registrarRecompensaButton = new JButton("Registrar Recompensa");
            registrarLogroButton = new JButton("Registrar Logro");
            consultarRecompensasYLogrosButton = new JButton("Consultar Recompensas y Logros");
            completarLogroButton = new JButton("Completar Logro");

            // Configurar estilo de botones principales
            JButton[] botonesPrincipales = {
                    registrarRecompensaButton, registrarLogroButton,
                    consultarRecompensasYLogrosButton, completarLogroButton
            };

            for (JButton boton : botonesPrincipales) {
                boton.setPreferredSize(new Dimension(280, 40));
                boton.setMaximumSize(new Dimension(280, 40));
                boton.setBackground(Color.WHITE);
                boton.setForeground(Color.BLACK);
                boton.setFocusPainted(false);
                boton.setBorder(BorderFactory.createRaisedBevelBorder());
                boton.setFont(new Font("Arial", Font.PLAIN, 12));
            }

            // Crear panel central para los botones
            JPanel panelBotones = new JPanel();
            panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.Y_AXIS));
            panelBotones.setBackground(new Color(130, 160, 180));
            panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 50, 50, 50));

            // Añadir botones con espaciado
            panelBotones.add(Box.createVerticalGlue());
            panelBotones.add(registrarRecompensaButton);
            panelBotones.add(Box.createVerticalStrut(20));
            panelBotones.add(registrarLogroButton);
            panelBotones.add(Box.createVerticalStrut(20));
            panelBotones.add(consultarRecompensasYLogrosButton);
            panelBotones.add(Box.createVerticalStrut(20));
            panelBotones.add(completarLogroButton);
            panelBotones.add(Box.createVerticalGlue());

            // Centrar botones horizontalmente
            registrarRecompensaButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            registrarLogroButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            consultarRecompensasYLogrosButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            completarLogroButton.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Agregar componentes al panel principal
            PanelRe.add(topPanel, BorderLayout.NORTH);
            PanelRe.add(textRecompensa, BorderLayout.CENTER);
            PanelRe.add(panelBotones, BorderLayout.CENTER);

            // Añadir el panel principal al JFrame
            this.getContentPane().add(PanelRe);
        }

        // Método para inicializar logros por defecto
        public String inicializarLogros() {
            StringBuilder resul = new StringBuilder();
            try {
                Logro logro1 = new Logro("Ganador 100 veces", "Logro obtenido por ganar 100 partidas", 500, true);
                Logro logro2 = new Logro("Ganador 50 veces", "Logro obtenido por ganar 50 partidas", 250, true);
                Logro logro3 = new Logro("Ganador 200 veces", "Logro obtenido por ganar 200 partidas", 700, false);
                Logro logro4 = new Logro("Invicto x10", "Logro obtenido por ganar 10 partidas seguidas", 400, false);
                Logro logro5 = new Logro("Empezando con pie derecho", "Logro obtenido por ganar tu primera partida", 100, true);

                logros.add(logro1);
                logros.add(logro2);
                logros.add(logro3);
                logros.add(logro4);
                logros.add(logro5);

                resul.append("Logros inicializados correctamente");
            } catch (Exception e) {
                resul.append("Error al Inicializar logros: ").append(e.getMessage());
            }
            return resul.toString();
        }

        // Método para inicializar recompensas por defecto
        public String inicializarRecompensas() {
            StringBuilder resul = new StringBuilder();
            try {
                Recompensa rec1 = new Recompensa("Medalla de Oro", "Recompensa por excelencia en el juego", 1000);
                Recompensa rec2 = new Recompensa("Medalla de Plata", "Recompensa por buen desempeño", 500);
                Recompensa rec3 = new Recompensa("Medalla de Bronce", "Recompensa por participación", 250);
                Recompensa rec4 = new Recompensa("Trofeo del Campeón", "Recompensa especial para ganadores", 1500);
                Recompensa rec5 = new Recompensa("Insignia de Honor", "Recompensa por juego limpio", 300);

                recompensas.add(rec1);
                recompensas.add(rec2);
                recompensas.add(rec3);
                recompensas.add(rec4);
                recompensas.add(rec5);

                resul.append("Recompensas inicializadas correctamente");
            } catch (Exception e) {
                resul.append("Error al Inicializar recompensas: ").append(e.getMessage());
            }
            return resul.toString();
        }

        private void addListeners() {
            volverButton.addActionListener(e -> volverButtonActionPerformed(e));
            registrarRecompensaButton.addActionListener(e -> registrarRecompensaButtonActionPerformed(e));
            registrarLogroButton.addActionListener(e -> registrarLogroButtonActionPerformed(e));
            consultarRecompensasYLogrosButton.addActionListener(e -> consultarRecompensasYLogrosButtonActionPerformed(e));
            completarLogroButton.addActionListener(e -> completarLogroButtonActionPerformed(e));
        }

        private void volverButtonActionPerformed(ActionEvent evt) {
            int opcion = JOptionPane.showConfirmDialog(
                    this,
                    "¿Está seguro que desea volver al menú principal?",
                    "Confirmar",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (opcion == JOptionPane.YES_OPTION) {
                this.dispose();
                if (parentFrame != null) {
                    parentFrame.setVisible(true);
                }
            }
        }

        private void registrarRecompensaButtonActionPerformed(ActionEvent evt) {
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

            // Opciones para nombre de recompensa
            String[] nombresRecompensa = {"ganador", "empate", "perdedor", "personalizada"};
            JComboBox<String> nombreCombo = new JComboBox<>(nombresRecompensa);

            // Opciones para descripción
            String[] descripciones = {
                    "¡Felicitaciones! Has ganado la partida",
                    "Buen juego, ha sido un empate",
                    "Sigue intentando, la próxima será mejor",
                    "Recompensa personalizada"
            };
            JComboBox<String> descripcionCombo = new JComboBox<>(descripciones);

            // Opciones para puntos
            String[] puntosOpciones = {"100", "50", "0"};
            JComboBox<String> puntosCombo = new JComboBox<>(puntosOpciones);

            // Campo de texto personalizado para nombre (inicialmente oculto)
            JTextField nombrePersonalizadoField = new JTextField(20);
            JLabel nombrePersonalizadoLabel = new JLabel("Nombre personalizado:");
            nombrePersonalizadoField.setVisible(false);
            nombrePersonalizadoLabel.setVisible(false);

            // Campo de texto personalizado para descripción (inicialmente oculto)
            JTextField descripcionPersonalizadaField = new JTextField(20);
            JLabel descripcionPersonalizadaLabel = new JLabel("Descripción personalizada:");
            descripcionPersonalizadaField.setVisible(false);
            descripcionPersonalizadaLabel.setVisible(false);

            // Listener para mostrar/ocultar campos personalizados según la selección
            nombreCombo.addActionListener(e -> {
                boolean esPersonalizada = "personalizada".equals(nombreCombo.getSelectedItem());
                nombrePersonalizadoField.setVisible(esPersonalizada);
                nombrePersonalizadoLabel.setVisible(esPersonalizada);

                if (esPersonalizada) {
                    descripcionCombo.setSelectedItem("Recompensa personalizada");
                }

                panel.revalidate();
                panel.repaint();
            });

            descripcionCombo.addActionListener(e -> {
                boolean esPersonalizada = "Recompensa personalizada".equals(descripcionCombo.getSelectedItem());
                descripcionPersonalizadaField.setVisible(esPersonalizada);
                descripcionPersonalizadaLabel.setVisible(esPersonalizada);
                panel.revalidate();
                panel.repaint();
            });

            // Agregar componentes al panel
            panel.add(new JLabel("Nombre de la recompensa:"));
            panel.add(nombreCombo);
            panel.add(Box.createVerticalStrut(5));
            panel.add(nombrePersonalizadoLabel);
            panel.add(nombrePersonalizadoField);
            panel.add(Box.createVerticalStrut(10));

            panel.add(new JLabel("Descripción:"));
            panel.add(descripcionCombo);
            panel.add(Box.createVerticalStrut(5));
            panel.add(descripcionPersonalizadaLabel);
            panel.add(descripcionPersonalizadaField);
            panel.add(Box.createVerticalStrut(10));

            panel.add(new JLabel("Puntos requeridos:"));
            panel.add(puntosCombo);

            int result = JOptionPane.showConfirmDialog(
                    this,
                    panel,
                    "Registrar Nueva Recompensa",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                try {
                    // Obtener el nombre seleccionado
                    String nombreSeleccionado = (String) nombreCombo.getSelectedItem();
                    String nombre;

                    if ("personalizada".equals(nombreSeleccionado)) {
                        nombre = nombrePersonalizadoField.getText().trim();
                        if (nombre.isEmpty()) {
                            JOptionPane.showMessageDialog(this, "Debe ingresar un nombre personalizado", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    } else {
                        nombre = nombreSeleccionado;
                    }

                    // Obtener la descripción seleccionada
                    String descripcionSeleccionada = (String) descripcionCombo.getSelectedItem();
                    String descripcion;

                    if ("Recompensa personalizada".equals(descripcionSeleccionada)) {
                        descripcion = descripcionPersonalizadaField.getText().trim();
                        if (descripcion.isEmpty()) {
                            JOptionPane.showMessageDialog(this, "Debe ingresar una descripción personalizada", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    } else {
                        descripcion = descripcionSeleccionada;
                    }

                    // Obtener los puntos seleccionados
                    int puntos = Integer.parseInt((String) puntosCombo.getSelectedItem());

                    // Crear la nueva recompensa
                    Recompensa nuevaRecompensa = new Recompensa(nombre, descripcion, puntos);
                    recompensas.add(nuevaRecompensa);

                    JOptionPane.showMessageDialog(this,
                            "Recompensa registrada exitosamente:\n" + nuevaRecompensa.toString(),
                            "Éxito",
                            JOptionPane.INFORMATION_MESSAGE);

                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this,
                            "Error al procesar los puntos",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        private void registrarLogroButtonActionPerformed(ActionEvent evt) {
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

            JTextField nombreField = new JTextField(20);
            JTextField descripcionField = new JTextField(20);
            JTextField puntosField = new JTextField(20);

            panel.add(new JLabel("Nombre del logro:"));
            panel.add(nombreField);
            panel.add(Box.createVerticalStrut(10));
            panel.add(new JLabel("Descripción:"));
            panel.add(descripcionField);
            panel.add(Box.createVerticalStrut(10));
            panel.add(new JLabel("Puntos que otorga:"));
            panel.add(puntosField);

            int result = JOptionPane.showConfirmDialog(
                    this,
                    panel,
                    "Registrar Nuevo Logro",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                try {
                    String nombre = nombreField.getText().trim();
                    String descripcion = descripcionField.getText().trim();
                    String puntosText = puntosField.getText().trim();

                    if (nombre.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "El nombre es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (descripcion.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "La descripción es obligatoria", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (puntosText.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Los puntos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    int puntos = Integer.parseInt(puntosText);
                    if (puntos < 0) {
                        JOptionPane.showMessageDialog(this, "Los puntos deben ser un número positivo", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    Logro nuevoLogro = new Logro(nombre, descripcion, puntos, false);
                    logros.add(nuevoLogro);

                    JOptionPane.showMessageDialog(this,
                            "Logro registrado exitosamente:\n" + nuevoLogro.toString(),
                            "Éxito",
                            JOptionPane.INFORMATION_MESSAGE);

                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this,
                            "Los puntos deben ser un número válido",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        private void consultarRecompensasYLogrosButtonActionPerformed(ActionEvent evt) {
            StringBuilder mensaje = new StringBuilder();
            mensaje.append("════════════ RECOMPENSAS ════════════\n\n");

            if (recompensas.isEmpty()) {
                mensaje.append("❌ No hay recompensas registradas\n");
            } else {
                for (int i = 0; i < recompensas.size(); i++) {
                    mensaje.append((i + 1)).append(". ").append(recompensas.get(i).toString()).append("\n");
                }
            }

            mensaje.append("\n══════════════ LOGROS ══════════════\n\n");

            if (logros.isEmpty()) {
                mensaje.append("❌ No hay logros registrados\n");
            } else {
                for (int i = 0; i < logros.size(); i++) {
                    mensaje.append((i + 1)).append(". ").append(logros.get(i).toString()).append("\n");
                }
            }

            JTextArea textArea = new JTextArea(mensaje.toString());
            textArea.setEditable(false);
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
            textArea.setCaretPosition(0);

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(600, 400));

            JOptionPane.showMessageDialog(this,
                    scrollPane,
                    "Consulta de Recompensas y Logros",
                    JOptionPane.INFORMATION_MESSAGE);
        }

        private void completarLogroButtonActionPerformed(ActionEvent evt) {
            if (logros.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "❌ No hay logros disponibles para completar.\nPrimero debe registrar algunos logros.",
                        "Sin logros",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            List<Logro> logrosDisponibles = new ArrayList<>();
            for (Logro logro : logros) {
                if (!logro.isCompletado()) {
                    logrosDisponibles.add(logro);
                }
            }

            if (logrosDisponibles.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "🏆 ¡Felicitaciones!\nTodos los logros han sido completados.",
                        "Todos completados",
                        JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] opciones = new String[logrosDisponibles.size()];
            for (int i = 0; i < logrosDisponibles.size(); i++) {
                opciones[i] = logrosDisponibles.get(i).getNombre() + " (+" + logrosDisponibles.get(i).getPuntos() + " pts)";
            }

            String seleccion = (String) JOptionPane.showInputDialog(
                    this,
                    "Seleccione el logro que desea completar:",
                    "Completar Logro",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
            );

            if (seleccion != null) {
                String nombreLogro = seleccion.split(" \\(\\+")[0];
                for (Logro logro : logrosDisponibles) {
                    if (logro.getNombre().equals(nombreLogro)) {
                        logro.setCompletado(true);

                        JOptionPane.showMessageDialog(this,
                                "🎉 ¡Logro completado!\n\n" +
                                        "Logro: " + logro.getNombre() + "\n" +
                                        "Descripción: " + logro.getDescripcion() + "\n" +
                                        "Puntos ganados: +" + logro.getPuntos() + " pts\n\n" +
                                        "¡Felicitaciones por tu logro!",
                                "¡Logro Completado!",
                                JOptionPane.INFORMATION_MESSAGE);
                        break;
                    }
                }
            }
        }

        // Clase interna para Recompensa
        private static class Recompensa {
            private String nombre;
            private String descripcion;
            private int puntos;
            private String nombreNormalizado;

            public Recompensa(String nombre, String descripcion, int puntos) {
                this.nombre = nombre;
                this.descripcion = descripcion;
                this.puntos = puntos;
                this.nombreNormalizado = nombre.toLowerCase();
            }

            public String getNombre() {
                return nombre;
            }

            public String getDescripcion() {
                return descripcion;
            }

            public int getPuntos() {
                return puntos;
            }

            public void asignarDescripcionPorDefecto() {
                switch (this.nombreNormalizado) {
                    case "ganador":
                        this.descripcion = "¡Felicitaciones! Has ganado la partida";
                        break;
                    case "empate":
                        this.descripcion = "Buen juego, ha sido un empate";
                        break;
                    case "perdedor":
                        this.descripcion = "Sigue intentando, la próxima será mejor";
                        break;
                    default:
                        this.descripcion = "Recompensa personalizada";
                }
            }

            @Override
            public String toString() {
                return "🎁 " + nombre + " - " + descripcion + " (Requiere: " + puntos + " pts)";
            }
        }

        // Clase interna para Logro
        private static class Logro {
            private String nombre;
            private String descripcion;
            private int puntos;
            private boolean completado;

            public Logro(String nombre, String descripcion, int puntos, boolean completado) {
                this.nombre = nombre;
                this.descripcion = descripcion;
                this.puntos = puntos;
                this.completado = completado;
            }

            public Logro(String nombre, String descripcion, int puntos) {
                this(nombre, descripcion, puntos, false);
            }

            public String getNombre() {
                return nombre;
            }

            public String getDescripcion() {
                return descripcion;
            }

            public int getPuntos() {
                return puntos;
            }

            public boolean isCompletado() {
                return completado;
            }

            public void setCompletado(boolean completado) {
                this.completado = completado;
            }

            @Override
            public String toString() {
                String estado = completado ? "✅ COMPLETADO" : "⭕ Pendiente";
                return "🏆 " + nombre + " - " + descripcion + " (Otorga: " + puntos + " pts) [" + estado + "]";
            }
        }
    }
