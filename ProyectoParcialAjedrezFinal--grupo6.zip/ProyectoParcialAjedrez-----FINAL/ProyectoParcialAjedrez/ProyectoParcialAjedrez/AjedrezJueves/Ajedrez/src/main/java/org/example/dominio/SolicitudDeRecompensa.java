package org.example.dominio;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class SolicitudDeRecompensa implements Serializable {
    // Serial version UID para compatibilidad de serialización
    private static final long serialVersionUID = 1L;

    private EstadoDeSolicitud estado;
    private Recompensa recompensa;
    private LocalDateTime fechaDeSolicitud;
    private String ultimoMensaje;

    // Métodos constructores originales...
    public SolicitudDeRecompensa(){
        this.estado = EstadoDeSolicitud.PENDIENTE;
        this.recompensa = getRecompensa();
        this.fechaDeSolicitud = LocalDateTime.now();
    }

    public SolicitudDeRecompensa(EstadoDeSolicitud estado, Recompensa recompensa){
        this.estado = estado;
        this.recompensa = recompensa;
        this.fechaDeSolicitud = LocalDateTime.now();
    }

    public SolicitudDeRecompensa(Recompensa recompensa) {
        if (recompensa == null){
            String mensaje = String.format("La recompensa no puede ser nula");
        }
        this.estado = EstadoDeSolicitud.PENDIENTE;
        this.recompensa = recompensa;
        this.fechaDeSolicitud = LocalDateTime.now();
    }

    // Todos tus métodos originales permanecen igual...
    public boolean crearSolicitud(Recompensa recompensa) {
        if (recompensa == null) {
            this.ultimoMensaje = "La recompensa no puede ser nula";
            return false;
        }

        this.recompensa = recompensa;
        this.estado = EstadoDeSolicitud.PENDIENTE;
        this.fechaDeSolicitud = LocalDateTime.now();

        this.ultimoMensaje = String.format("Recompensa solicitada: %s\nFecha de solicitud: %s",
                recompensa.getNombre(),
                fechaDeSolicitud.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));

        return true;
    }

    public boolean rechazarSolicitud(String motivoDeRechazo) {
        if (this.estado == EstadoDeSolicitud.PENDIENTE) {
            this.estado = EstadoDeSolicitud.RECHAZADA;
            this.ultimoMensaje = String.format("Solicitud rechazada");
        }
        return true;
    }

    public boolean aprobarSolicitud() {
        if (this.estado != EstadoDeSolicitud.PENDIENTE) {
            this.ultimoMensaje = "Solo se pueden aprobar solicitudes en estado PENDIENTE";
            return false;
        }

        this.estado = EstadoDeSolicitud.APROBADA;
        this.ultimoMensaje = String.format("Solicitud aprobada exitosamente.");

        return true;
    }

    public boolean procesarSolicitud() {
        if (this.estado != EstadoDeSolicitud.APROBADA) {
            this.ultimoMensaje = "Solo se pueden procesar solicitudes APROBADAS";
            return false;
        }

        this.estado = EstadoDeSolicitud.PROCESADA;
        this.ultimoMensaje = "Solicitud procesada exitosamente.\nLa recompensa ha sido entregada al solicitante.";

        return true;
    }

    public String estadoDeSolicitud() {
        StringBuilder info = new StringBuilder();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        info.append(" ESTADO DE SOLICITUD \n");
        info.append("Estado actual: ").append(this.estado.getNombre()).append("\n");
        info.append("Descripción: ").append(this.estado.getDescripcion()).append("\n");
        info.append("Fecha de solicitud: ").append(this.fechaDeSolicitud.format(formatter)).append("\n");

        if (this.recompensa != null) {
            info.append("Recompensa solicitada: ").append(this.recompensa.getNombre()).append("\n");
            info.append("Puntos: ").append(this.recompensa.getPuntos()).append("\n");
        } else {
            info.append("Recompensa: No especificada\n");
        }
        return info.toString();
    }

    // Getters y setters originales...
    public EstadoDeSolicitud getEstado() {
        return estado;
    }

    public void setEstado(EstadoDeSolicitud estado) {
        this.estado = estado;
    }

    public Recompensa getRecompensa() {
        return recompensa;
    }

    public void setRecompensa(Recompensa recompensa) {
        this.recompensa = recompensa;
    }

    public LocalDateTime getFechaDeSolicitud() {
        return fechaDeSolicitud;
    }

    public void setFechaDeSolicitud(LocalDateTime fechaDeSolicitud) {
        this.fechaDeSolicitud = fechaDeSolicitud;
    }

    public String getUltimoMensaje() {
        return ultimoMensaje;
    }

    public boolean estaPendiente() {
        return this.estado == EstadoDeSolicitud.PENDIENTE;
    }

    public boolean estaAprobada() {
        return this.estado == EstadoDeSolicitud.APROBADA;
    }

    public boolean estaRechazada() {
        return this.estado == EstadoDeSolicitud.RECHAZADA;
    }

    public boolean estaProcesada() {
        return this.estado == EstadoDeSolicitud.PROCESADA;
    }

    @Override
    public String toString() {
        return String.format(
                "╔═══════════════════════════════════╗%n" +
                        "║      SOLICITUD DE RECOMPENSA      ║%n" +
                        "╠═══════════════════════════════════╣%n" +
                        "║ Estado: %-25s ║%n" +
                        "║ Fecha:  %-25s ║%n" +
                        "╚═══════════════════════════════════╝",
                estado.getNombre(),
                fechaDeSolicitud.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))
        );
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        SolicitudDeRecompensa that = (SolicitudDeRecompensa) obj;
        return Objects.equals(fechaDeSolicitud, that.fechaDeSolicitud) &&
                Objects.equals(recompensa, that.recompensa) &&
                estado == that.estado;
    }

    @Override
    public int hashCode() {
        return Objects.hash(fechaDeSolicitud, recompensa, estado);
    }

    public int getId() {
        return 0;
    }

    // ====================== MÉTODOS DE SERIALIZACIÓN BINARIA ======================

    /**
     * Serializa la solicitud en un archivo binario
     * @param nombreArchivo Nombre del archivo donde guardar
     * @throws IOException Si hay error al escribir el archivo
     */
    public void guardarEnArchivo(String nombreArchivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            oos.writeObject(this);
            System.out.println("SolicitudDeRecompensa guardada en: " + nombreArchivo);
        }
    }

    /**
     * Deserializa una solicitud desde un archivo binario
     * @param nombreArchivo Nombre del archivo a cargar
     * @return SolicitudDeRecompensa deserializada
     * @throws IOException Si hay error al leer el archivo
     * @throws ClassNotFoundException Si no encuentra la clase
     */
    public static SolicitudDeRecompensa cargarDesdeArchivo(String nombreArchivo)
            throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            SolicitudDeRecompensa solicitud = (SolicitudDeRecompensa) ois.readObject();
            System.out.println("SolicitudDeRecompensa cargada desde: " + nombreArchivo);
            return solicitud;
        }
    }

    /**
     * Serializa la solicitud a un array de bytes (en memoria)
     * @return Array de bytes que representa la solicitud
     * @throws IOException Si hay error en la serialización
     */
    public byte[] toBytes() throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeObject(this);
            oos.flush();
            byte[] bytes = baos.toByteArray();
            System.out.println("SolicitudDeRecompensa serializada a " + bytes.length + " bytes");
            return bytes;
        }
    }

    /**
     * Deserializa una solicitud desde un array de bytes
     * @param bytes Array de bytes que contiene la solicitud serializada
     * @return SolicitudDeRecompensa deserializada
     * @throws IOException Si hay error en la deserialización
     * @throws ClassNotFoundException Si no encuentra la clase
     */
    public static SolicitudDeRecompensa fromBytes(byte[] bytes)
            throws IOException, ClassNotFoundException {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
             ObjectInputStream ois = new ObjectInputStream(bais)) {
            SolicitudDeRecompensa solicitud = (SolicitudDeRecompensa) ois.readObject();
            System.out.println("SolicitudDeRecompensa deserializada desde " + bytes.length + " bytes");
            return solicitud;
        }
    }

    /**
     * Clona la solicitud usando serialización (deep copy)
     * @return Una copia exacta de la solicitud
     * @throws IOException Si hay error en la serialización
     * @throws ClassNotFoundException Si no encuentra la clase
     */
    public SolicitudDeRecompensa clonar() throws IOException, ClassNotFoundException {
        return fromBytes(this.toBytes());
    }

    /**
     * Guarda múltiples solicitudes en un solo archivo
     * @param solicitudes Array de solicitudes a guardar
     * @param nombreArchivo Nombre del archivo
     * @throws IOException Si hay error al escribir
     */
    public static void guardarMultiples(SolicitudDeRecompensa[] solicitudes, String nombreArchivo)
            throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            oos.writeInt(solicitudes.length); // Primero guardamos la cantidad
            for (SolicitudDeRecompensa solicitud : solicitudes) {
                oos.writeObject(solicitud);
            }
            System.out.println(solicitudes.length + " solicitudes guardadas en: " + nombreArchivo);
        }
    }

    /**
     * Carga múltiples solicitudes desde un archivo
     * @param nombreArchivo Nombre del archivo a cargar
     * @return Array de solicitudes
     * @throws IOException Si hay error al leer
     * @throws ClassNotFoundException Si no encuentra la clase
     */
    public static SolicitudDeRecompensa[] cargarMultiples(String nombreArchivo)
            throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            int cantidad = ois.readInt(); // Leemos la cantidad
            SolicitudDeRecompensa[] solicitudes = new SolicitudDeRecompensa[cantidad];

            for (int i = 0; i < cantidad; i++) {
                solicitudes[i] = (SolicitudDeRecompensa) ois.readObject();
            }

            System.out.println(cantidad + " solicitudes cargadas desde: " + nombreArchivo);
            return solicitudes;
        }
    }
}