package org.example.interfaz;

import org.example.dominio.Competencia;
import org.example.interfaz.Jugador.InterJu;
import org.example.interfaz.Partida.InterPar;
import org.example.interfaz.Recompensa.InterRec;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CheckMate {
    private JPanel mainPanel;
    private JLabel Jtitulo;
    private JLabel imagenReina;
    private JButton buttonPartida;
    private JButton buttonJugador;
    private JButton buttonRecompensa;
    private JLabel imagenPiezas1;
    private JLabel imagenPiezas2;
    private JLabel imagenPiezas3;
    private JLabel imagenPiezas4;
    private JLabel imagenPiezas5;
    private JLabel imagenPiezas6;

    //private JButton buttonJugar;
    //private JTextPane pane;
    //private JLabel label1;
    Competencia com = Competencia.getInstancia();
        public CheckMate(){
            imagenReina.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\img.png"));
            imagenPiezas1.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\img2.png"));
            imagenPiezas2.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\img2.png"));
            imagenPiezas3.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\img2.png"));

            buttonPartida.addActionListener(e -> {
                InterPar.showInterPar((JFrame) SwingUtilities.getWindowAncestor(buttonPartida));  // 'this' debe ser tu JFrame principal
            });

            buttonJugador.addActionListener(e -> {
                JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor(buttonJugador);
                InterJu.showInterJu(parentFrame, com);
            });

            buttonRecompensa.addActionListener(e -> {
                JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor(buttonRecompensa);
                InterRec ventanaRecompensas = new InterRec(parentFrame);
                ventanaRecompensas.setVisible(true);
                parentFrame.setVisible(false);
            });

        }

        public static void main(String[] args) {
            JFrame frame = new JFrame("CheckMate");
            frame.setContentPane(new org.example.interfaz.CheckMate().mainPanel);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setResizable(false);
            frame.setSize(1080,720);
            frame.setVisible(true);
        }
}
