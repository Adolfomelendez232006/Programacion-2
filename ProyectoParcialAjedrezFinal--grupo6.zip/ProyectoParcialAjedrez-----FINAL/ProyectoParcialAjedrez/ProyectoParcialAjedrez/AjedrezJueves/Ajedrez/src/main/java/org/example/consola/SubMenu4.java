package org.example.consola;

import org.example.dominio.*;
import org.example.ordenamientos.OrdenarRecompensaPuntos;
import org.example.util.Validador;


import java.util.*;

/**
 * Clase que representa el submenú para gestionar recompensas de un jugador.
 * Permite registrar nuevas recompensas y consultar el total de puntos acumulados.
 */
public class SubMenu4 {
    /**
     * Metodo que despliega el submenú para gestionar recompensas.
     * El usuario puede registrar recompensas de tipo Ganador, Empate o Perdedor,
     * consultar las recompensas registradas y ver el total de puntos acumulados.
     */
    public static void subMenu4(String[] args){
        Jugador jugador = new Jugador();
        Scanner leer = new Scanner(System.in);
        int op;
        boolean val1 = true, val2 = true;

        while (val1 == true) {
            System.out.printf(
                    "%n" +
                    "╔══════════════════════════════════════════════════════════╗%n" +
                    "║              🏆 GESTIONAR RECOMPENSAS Y LOGROS 🏆        ║%n" +
                    "╠══════════════════════════════════════════════════════════╣%n" +
                    "║  1. 🎁 Registrar recompensa                              ║%n" +
                    "║  2. 🏅 Registrar logro                                   ║%n" +
                    "║  3. 📋 Consultar recompensas y logros                    ║%n" +
                    "║  4. ✅ Completar logro                                   ║%n" +
                    "║  5. 🚪 Salir                                             ║%n" +
                    "╚══════════════════════════════════════════════════════════╝%n" +
                    "👉 Ingrese la opción que desea seleccionar: "
            );
            op = Validador.pedirNumero(leer);
            switch (op) {
                case 1:
                    System.out.println("H3.1. Registrar recompensa.");
                    System.out.print("Ingrese tipo de recompensa (Ganador, Empate, Perdedor): ");
                    String tipo = Validador.pedirNombre(leer);

                    try {
                        // Crear recompensa directamente con el constructor
                        Recompensa recompensa = new Recompensa(tipo) {
                            @Override
                            public String completarLogro(String nombre) {
                                return nombre;
                            }

                            @Override
                            public void reiniciarLogro() {

                            }

                            @Override
                            public boolean estaPendiente() {
                                return false;
                            }

                            @Override
                            public String getEstadoTexto() {
                                return "";
                            }
                        };

                        // Registrar la recompensa en el jugador
                        //recompensa.registrarRecompensa(Recompensa recompensa);
                        jugador.registrarRecompensa(recompensa);

                        System.out.println("Recompensa registrada con éxito.");
                        System.out.println("Tipo: " + recompensa.getNombre());
                        System.out.println("Puntos obtenidos: " + recompensa.getPuntos());
                        System.out.println("Descripción: " + recompensa.getDescripcion());

                    } catch (IllegalArgumentException e) {
                        System.out.println("Error: Tipo de recompensa no válido. Use: Ganador, Empate o Perdedor");
                    }
                    break;
                case 2:
                    System.out.println("H3.2. Registrar logro.");
                    System.out.print("Ingrese tipo de logro (Ganador, Empate, Perdedor): ");
                    String tipoLogro = Validador.pedirNombre(leer);

                    try {
                        // Crear logro con el constructor específico
                        Logro logro = new Logro(tipoLogro);

                        // Registrar el logro en el jugador
                        jugador.registrarLogro(logro);

                        System.out.println("Logro registrado con éxito.");
                        System.out.println("Tipo: " + logro.getNombre());
                        System.out.println("Estado: " + logro.getEstadoTexto());
                        System.out.println("Descripción: " + logro.getDescripcion());

                    } catch (IllegalArgumentException e) {
                        System.out.println("Error: Tipo de logro no válido. Use: Ganador, Empate o Perdedor");
                    }
                    break;
                case 3:
                    /*System.out.println("H3.3. Consultar recompensas y logros.");
                    System.out.println("1. Recompensas ordenadas por nombre." +
                                        "2. Recompensas ordenadas por puntos.");*/
                    Recompensa rem = new Logro();
                    Competencia com = new Competencia();
                    val2 = true;
                    do {
                        System.out.printf(
                            "%n" +
                                    "╔══════════════════════════════════════════════════════════╗%n" +
                                    "║              🏆 CONSULTAR RECOMPENSAS Y LOGROS 🏆        ║%n" +
                                    "╠══════════════════════════════════════════════════════════╣%n" +
                                    "║  1. 🏅 Recompensas ordenadas por nombre                  ║%n" +
                                    "║  2. 🏅 Recompensas ordenadas por puntos.                 ║%n" +
                                    "║  3. 🏅 Consultar logros                                  ║%n" +
                                    "║  4. 🏅 Puntos acumulados                                 ║%n" +
                                    "║  5. 🚪 Salir                                             ║%n" +
                                    "╚══════════════════════════════════════════════════════════╝%n" +
                                    "👉 Ingrese la opción que desea seleccionar: "
                        );
                        op = Validador.pedirNumero(leer);
                        switch (op){
                            case 1:
                                List<Recompensa> listaRecom1 = new ArrayList<>(4);
                                System.out.println("Ordenado por nombre: ");
                                Set<Recompensa> OrdenarRecomNom = new TreeSet<>();
                                listaRecom1.sort(new OrdenarRecompensaPuntos());
                                for (Recompensa re : OrdenarRecomNom) {
                                    System.out.println(re);
                                }
                                break;
                            case 2:
                                List<Recompensa> listaRecom = new ArrayList<>(4);  // Capacidad inicial de 4
                                System.out.println("Ordenando por ID: ");
                                listaRecom.sort(new OrdenarRecompensaPuntos());
                                for (Recompensa re : listaRecom) {
                                    System.out.println(re);
                                }
                                break;
                            case 3:
                                System.out.println(jugador.mostrarLogros());
                                break;
                            case 4:
                                System.out.println("\nTotal de puntos acumulados: " + jugador.calcularTotalPuntos());
                                break;
                            case 5:
                                System.out.println("Saliendo del menu...");
                                val2 = false;
                                break;
                            default:
                                System.out.println("Estos valores no estan permitidos.");
                        }
                    } while (val2 == true);
                    break;
                case 4:
                    System.out.println("H3.4. Completar logro.");
                    System.out.println(jugador.mostrarLogros());

                    Logro logro = new Logro();
                    System.out.print("Ingrese el nombre del logro a completar: ");
                    String nombreLogro = Validador.pedirNombre(leer);
                    //jugador.completarLogro(nombreLogro);

                    boolean completado = jugador.completarLogro(nombreLogro);
                    if (completado) {
                        System.out.println("¡Logro completado con éxito!");
                        jugador.getLogrosCompletados();
                    } else {
                        System.out.println("No se encontró el logro o ya está completado.");
                    }
                    break;
                case 5:
                    System.out.println("Saliendo del programa......");
                    val1 = false;
                    break;

                default:
                    System.out.println("Este valor no esta disponible.");
            }
        }
    }
}

