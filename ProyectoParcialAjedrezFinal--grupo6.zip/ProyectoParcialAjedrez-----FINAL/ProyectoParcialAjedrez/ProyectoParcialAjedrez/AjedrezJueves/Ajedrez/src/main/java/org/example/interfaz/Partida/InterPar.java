package org.example.interfaz.Partida;

import org.example.dominio.*;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class InterPar extends JFrame {
    private JButton buttonVolver;
    private JLabel Jimagen;
    private JButton buttonCrearPar;
    private JButton buttonEditarPar;
    private JButton buttonEliminarPar;
    private JPanel mainPanel2;
    private JButton buttonBuscarPar;
    private JButton buttonListarPar;
    private JButton enviarComentarioButton;
    private static JFrame parentWindow;
    //private static ArrayList<Partida> partidas = new ArrayList<>(3);

    private Competencia com = Competencia.getInstancia();

    public InterPar(JFrame parent) {
        Jimagen.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\games.png"));
        this.parentWindow = parent;
        initializeWindow();
        setupComponents();
        setupActionListeners();
    }

    private void initializeWindow() {
        setTitle("Gestión de Partidas - CheckMate");
        setContentPane(mainPanel2);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(parentWindow);
        setResizable(false);
    }

    private void setupComponents() {
        // Configuración de estilos
        Jimagen.setFont(new Font("Arial", Font.BOLD, 24));
        Jimagen.setHorizontalAlignment(SwingConstants.CENTER);

        // Configuración de botones
        buttonCrearPar.setFont(new Font("Arial", Font.PLAIN, 16));
        buttonEditarPar.setFont(new Font("Arial", Font.PLAIN, 16));
        buttonEliminarPar.setFont(new Font("Arial", Font.PLAIN, 16));
        buttonVolver.setFont(new Font("Arial", Font.PLAIN, 16));
        buttonBuscarPar.setFont(new Font("Arial", Font.PLAIN, 16));
        buttonListarPar.setFont(new Font("Arial", Font.PLAIN, 16));
    }

    private void setupActionListeners(){
        buttonVolver.addActionListener(e -> {
            this.dispose();
            parentWindow.setVisible(true);
        });
        buttonCrearPar.addActionListener(e ->
                CrearPartida.showCrearPartida((JFrame) SwingUtilities.getWindowAncestor(buttonCrearPar))
        );
        buttonEliminarPar.addActionListener(e -> eliminarPartida());
        buttonBuscarPar.addActionListener(e -> consultarPartida());
        buttonEditarPar.addActionListener(e -> editarPartida());
        buttonListarPar.addActionListener(e -> listarPartidas());

        enviarComentarioButton.addActionListener(e -> enviarComentario());
    }

    public static void showInterPar(JFrame parent) {
        SwingUtilities.invokeLater(() -> {
            InterPar gestionPartida = new InterPar(parent);
            parent.setVisible(false);
            gestionPartida.setVisible(true);
        });
    }

    private boolean esSoloLetras(String texto) {
        return texto.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+");
    }

    private void consultarPartida() {
        if (com.getPartidas().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay partidas registradas", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String idStr = JOptionPane.showInputDialog(this, "Ingresa el ID de la partida a consultar:", "Consultar Partida", JOptionPane.QUESTION_MESSAGE);

        if (idStr != null && !idStr.trim().isEmpty()) {
            try {
                int id = Integer.parseInt(idStr.trim());
                Partida partida = com.buscarPartidaPorId(id);

                if (partida != null) {
                    mostrarInformacionPartida(partida);
                } else {
                    JOptionPane.showMessageDialog(this, "Partida no encontrada", "Información", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void mostrarInformacionPartida(Partida partida) {
        StringBuilder info = new StringBuilder();
        info.append("INFORMACIÓN DE PARTIDA\n");
        info.append("========================\n\n");
        info.append("ID: ").append(partida.getIdPartida()).append("\n");
        info.append("Observación: ").append(partida.getObservaciones()).append("\n");
        info.append("Contrincante: ").append(partida.getContrincante()).append("\n");
        info.append("Estado: ").append(partida.getEstado()).append("\n");
        info.append("Puntaje Jugador 1: ").append(partida.getPuntajeJugador1()).append("\n");
        info.append("Puntaje Jugador 2: ").append(partida.getPuntajeJugador2()).append("\n");
        info.append("Fecha de Registro: ").append(partida.getFecha().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n");

        JTextArea textArea = new JTextArea(info.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(this, scrollPane, "Información de la partida", JOptionPane.INFORMATION_MESSAGE);
    }

    private void editarPartida(){
        if (com.getPartidas().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay partidas registradas", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // CORREGIDO: Usar la lista de partidas correctamente
        String[] parInfo = com.getPartidas().stream()
                .map(j -> "ID: " + j.getIdPartida() + " - " + j.getObservaciones() + " (" + j.getContrincante() + ")")
                .toArray(String[]::new);

        if (parInfo.length == 0) {
            JOptionPane.showMessageDialog(this, "No hay partidas registradas para editar", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String seleccion = (String) JOptionPane.showInputDialog(this, "Selecciona la partida a modificar:",
                "Modificar Partida", JOptionPane.QUESTION_MESSAGE,
                null, parInfo, parInfo[0]);

        if (seleccion != null) {
            int id = Integer.parseInt(seleccion.split(" - ")[0].replace("ID: ", ""));
            Partida partida = com.buscarPartidaPorId(id);

            if (partida != null) {
                mostrarFormularioModificar(partida);
            }
        }
    }

    private void mostrarFormularioModificar(Partida partida) {
        JDialog dialog = new JDialog(this, "Modificar Partida", true);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // CORREGIDO: Pre-llenar los campos con los datos existentes
        JTextField idPartida = new JTextField(String.valueOf(partida.getIdPartida()), 20);
        idPartida.setEnabled(false); // No permitir cambiar el ID
        idPartida.setBackground(Color.LIGHT_GRAY);

        JTextField observacion = new JTextField(partida.getObservaciones(), 20);

        JTextField puntaje1 = new JTextField(String.valueOf(partida.getPuntajeJugador1()), 20);
        JTextField puntaje2 = new JTextField(String.valueOf(partida.getPuntajeJugador2()), 20);

        // ComboBox para el contrincante
        JComboBox<Contrincante> contrincante = new JComboBox<>(Contrincante.values());
        contrincante.setSelectedItem(partida.getContrincante());

        // ComboBox para el estado
        JComboBox<EstadoEnfrentamiento> estado = new JComboBox<>(EstadoEnfrentamiento.values());
        estado.setSelectedItem(partida.getEstado());

        // Campo de fecha (solo lectura)
        JTextField fechaField = new JTextField(partida.getFecha().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")), 20);
        fechaField.setEnabled(false);
        fechaField.setBackground(Color.LIGHT_GRAY);

        // Layout del formulario
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        dialog.add(new JLabel("ID de la partida:"), gbc);
        gbc.gridx = 1;
        dialog.add(idPartida, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        dialog.add(new JLabel("Observación:"), gbc);
        gbc.gridx = 1;
        dialog.add(observacion, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        dialog.add(new JLabel("Puntaje Jugador 1:"), gbc);
        gbc.gridx = 1;
        dialog.add(puntaje1, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        dialog.add(new JLabel("Puntaje Jugador 2:"), gbc);
        gbc.gridx = 1;
        dialog.add(puntaje2, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        dialog.add(new JLabel("Contrincante:"), gbc);
        gbc.gridx = 1;
        dialog.add(contrincante, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        dialog.add(new JLabel("Estado:"), gbc);
        gbc.gridx = 1;
        dialog.add(estado, gbc);

        gbc.gridx = 0; gbc.gridy = 6;
        dialog.add(new JLabel("Fecha de Registro:"), gbc);
        gbc.gridx = 1;
        dialog.add(fechaField, gbc);

        // Botones
        JPanel buttonPanel = new JPanel();
        JButton guardarBtn = new JButton("Guardar Cambios");
        JButton cancelarBtn = new JButton("Cancelar");

        guardarBtn.addActionListener(e -> {
            try {
                String obs = observacion.getText().trim();

                if (obs.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "La observación es obligatoria.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!esSoloLetras(obs)) {
                    JOptionPane.showMessageDialog(dialog, "La observación solo puede contener letras.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // CORREGIDO: Actualizar los datos de la partida existente
                partida.setObservaciones(obs);
                partida.setPuntajeJugador1(Integer.parseInt(puntaje1.getText().trim()));
                partida.setPuntajeJugador2(Integer.parseInt(puntaje2.getText().trim()));
                partida.setContrincante((Contrincante) contrincante.getSelectedItem());
                partida.setEstado((EstadoEnfrentamiento) estado.getSelectedItem());

                JOptionPane.showMessageDialog(dialog, "Partida modificada exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Los puntajes deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error al modificar partida: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelarBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(guardarBtn);
        buttonPanel.add(cancelarBtn);

        gbc.gridx = 0; gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        dialog.add(buttonPanel, gbc);

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void eliminarPartida() {
        if (com.getPartidas().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay partidas registradas", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // CORREGIDO: Mostrar información más completa para selección
        String[] partidaInfo = com.getPartidas().stream()
                .map(j -> "ID: " + j.getIdPartida() + " - " + j.getObservaciones() + " (" + j.getContrincante() + ")")
                .toArray(String[]::new);

        String seleccion = (String) JOptionPane.showInputDialog(this, "Selecciona la partida a eliminar:",
                "Eliminar partida", JOptionPane.QUESTION_MESSAGE,
                null, partidaInfo, partidaInfo[0]);

        if (seleccion != null) {
            int id = Integer.parseInt(seleccion.split(" - ")[0].replace("ID: ", ""));
            Partida partida = com.buscarPartidaPorId(id);

            if (partida != null) {
                int confirmacion = JOptionPane.showConfirmDialog(this,
                        "¿Estás seguro de eliminar la partida con ID: " + id + "?\nObservación: " + partida.getObservaciones(),
                        "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

                if (confirmacion == JOptionPane.YES_OPTION) {
                    com.eliminarPartida(id);
                    JOptionPane.showMessageDialog(this, "Partida eliminada exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        }
    }

    // AGREGADO: Método para listar todas las partidas
    private void listarPartidas() {
        if (com.getPartidas().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay partidas registradas", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder lista = new StringBuilder();
        lista.append("LISTA DE PARTIDAS REGISTRADAS\n");
        lista.append("========================================\n\n");

        for (Partida partida : com.getPartidas()) {
            lista.append("ID: ").append(partida.getIdPartida()).append("\n");
            lista.append("Observación: ").append(partida.getObservaciones()).append("\n");
            lista.append("Contrincante: ").append(partida.getContrincante()).append("\n");
            lista.append("Estado: ").append(partida.getEstado()).append("\n");
            lista.append("Puntajes: ").append(partida.getPuntajeJugador1())
                    .append(" - ").append(partida.getPuntajeJugador2()).append("\n");
            lista.append("Fecha: ").append(partida.getFecha().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))).append("\n");
            lista.append("----------------------------------------\n");
        }

        JTextArea textArea = new JTextArea(lista.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));

        JOptionPane.showMessageDialog(this, scrollPane, "Lista de Partidas", JOptionPane.INFORMATION_MESSAGE);
    }
    private void enviarComentario() {
        if (com.getPartidas().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay partidas registradas para comentar", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Mostrar lista de partidas para seleccionar
        String[] partidaInfo = com.getPartidas().stream()
                .map(j -> "ID: " + j.getIdPartida() + " - " + j.getObservaciones() + " (" + j.getContrincante() + ")")
                .toArray(String[]::new);

        String seleccion = (String) JOptionPane.showInputDialog(this,
                "Selecciona la partida para comentar:",
                "Enviar Comentario", JOptionPane.QUESTION_MESSAGE,
                null, partidaInfo, partidaInfo[0]);

        if (seleccion != null) {
            int id = Integer.parseInt(seleccion.split(" - ")[0].replace("ID: ", ""));
            Partida partida = com.buscarPartidaPorId(id);

            if (partida != null) {
                mostrarFormularioComentario(partida);
            }
        }
    }

    private void mostrarFormularioComentario(Partida partida) {
        JDialog dialog = new JDialog(this, "Enviar Comentario - Partida ID: " + partida.getIdPartida(), true);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Información de la partida (solo lectura)
        JTextField idPartida = new JTextField(String.valueOf(partida.getIdPartida()), 20);
        idPartida.setEnabled(false);
        idPartida.setBackground(Color.LIGHT_GRAY);

        JTextField observacionActual = new JTextField(partida.getObservaciones(), 20);
        observacionActual.setEnabled(false);
        observacionActual.setBackground(Color.LIGHT_GRAY);

        // Campo para el nuevo comentario
        JTextArea nuevoComentario = new JTextArea(5, 20);
        nuevoComentario.setLineWrap(true);
        nuevoComentario.setWrapStyleWord(true);
        JScrollPane scrollComentario = new JScrollPane(nuevoComentario);

        // Campo para el nombre del comentarista
        JTextField nombreComentarista = new JTextField(20);

        // Timestamp del comentario
        JTextField fechaComentario = new JTextField(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")), 20);
        fechaComentario.setEnabled(false);
        fechaComentario.setBackground(Color.LIGHT_GRAY);

        // Layout del formulario
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        dialog.add(new JLabel("ID Partida:"), gbc);
        gbc.gridx = 1;
        dialog.add(idPartida, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        dialog.add(new JLabel("Observación Actual:"), gbc);
        gbc.gridx = 1;
        dialog.add(observacionActual, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        dialog.add(new JLabel("Tu Nombre:"), gbc);
        gbc.gridx = 1;
        dialog.add(nombreComentarista, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        dialog.add(new JLabel("Comentario:"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.BOTH;
        dialog.add(scrollComentario, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.NONE;
        dialog.add(new JLabel("Fecha:"), gbc);
        gbc.gridx = 1;
        dialog.add(fechaComentario, gbc);

        // Botones
        JPanel buttonPanel = new JPanel();
        JButton enviarBtn = new JButton("Enviar Comentario");
        JButton cancelarBtn = new JButton("Cancelar");

        enviarBtn.addActionListener(e -> {
            try {
                String nombre = nombreComentarista.getText().trim();
                String comentario = nuevoComentario.getText().trim();

                if (nombre.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "El nombre es obligatorio.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!esSoloLetras(nombre)) {
                    JOptionPane.showMessageDialog(dialog, "El nombre solo puede contener letras.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (comentario.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "El comentario no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (comentario.length() > 500) {
                    JOptionPane.showMessageDialog(dialog, "El comentario no puede exceder 500 caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Agregar el comentario a la observación existente
                String observacionActualizada = partida.getObservaciones() +
                        "\n[COMENTARIO - " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")) +
                        " por " + nombre + "]: " + comentario;

                partida.setObservaciones(observacionActualizada);

                JOptionPane.showMessageDialog(dialog,
                        "Comentario enviado exitosamente a la partida ID: " + partida.getIdPartida(),
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error al enviar comentario: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelarBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(enviarBtn);
        buttonPanel.add(cancelarBtn);

        gbc.gridx = 0; gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        dialog.add(buttonPanel, gbc);

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

}