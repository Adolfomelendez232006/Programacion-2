package org.example.ordenamientos;

import org.example.dominio.Recompensa;

import java.util.Comparator;

public class OrdenarRecompensaPuntos implements Comparator<Recompensa> {
    @Override
    public int compare(Recompensa o1, Recompensa o2) {
        if (o1.getPuntos()<o2.getPuntos()){
            return -1;
        } else if (o1.getPuntos()> o2.getPuntos()) {
            return 1;
        }else{return 0; }
    }
}
