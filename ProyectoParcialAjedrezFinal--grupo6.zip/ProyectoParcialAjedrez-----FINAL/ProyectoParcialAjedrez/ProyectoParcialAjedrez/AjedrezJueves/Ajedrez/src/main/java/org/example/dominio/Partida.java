package org.example.dominio;


import org.example.util.Excepcion;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 *Representacion de una partida de juego que gestiona un conjunto de
 * jugadores Permite registrar, buscar, editar y eliminar jugadores
 * asi como gestionar el arreglo dinamico de jugadores participantes
 */
public class Partida implements Serializable{
    private static final long serialVersionUID = 1L;

    private int numJugadores;
    public List<Jugador> jugadores;
    private int puntajeJugador1;
    private int puntajeJugador2;
    private LocalDateTime fecha;
    private String observaciones;
    private EstadoEnfrentamiento estado;
    public List<Partida> partidas;
    private int numPartidas;
    private Contrincante contrincante;
    private Jugador ganador;
    private Jugador jugador1;
    private Jugador jugador2;
    public static int contador;
    private int idPartida;

    static {contador = 0;}

    public Partida(){
        this(1,1,2,LocalDateTime.now(), "sin observaciones", Contrincante.SINCONTRINCANTE,EstadoEnfrentamiento.SIN_JUGAR);
    }

    public Partida(int id, int punJ1, int punJ2, LocalDateTime fecha, String obs, Contrincante contrincante,EstadoEnfrentamiento estado) {
        partidas = new ArrayList<>(10);
        jugadores = new ArrayList<>(6);
        this.puntajeJugador1 = punJ1;
        this.puntajeJugador2 = punJ2;
        this.fecha = LocalDateTime.now();
        this.observaciones = obs;
        this.estado = EstadoEnfrentamiento.SIN_JUGAR;
        this.contrincante = contrincante;
        this.idPartida = id;
    }

    public Partida(int id, int nuevoPuntajeJ1, int nuevoPuntajeJ2,
                   LocalDateTime nuevaFecha, String nuevasObservaciones, EstadoEnfrentamiento nuevoEstado, Contrincante nuevoContrincante) {
        this(id, nuevoPuntajeJ1, nuevoPuntajeJ2, nuevaFecha, nuevasObservaciones, nuevoContrincante, nuevoEstado);
    }

    // Serialización a bytes
    public byte[] toBytes() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(this);
        oos.close();
        return baos.toByteArray();
    }

    // Deserialización desde bytes
    public static Partida fromBytes(byte[] bytes) throws IOException, ClassNotFoundException {
        ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
        ObjectInputStream ois = new ObjectInputStream(bais);
        Partida partida = (Partida) ois.readObject();
        ois.close();
        return partida;
    }

    //Metodos get
    public Jugador getJugador(int indice){
        if (indice >= 0 && indice < numJugadores) {
            return jugadores.get(indice);
        } else {
            return null;
        }
    }
    public int getNumJugadores() {return numJugadores;}
    public String getObservaciones() {return observaciones;}
    public int getPuntajeJugador1() {return puntajeJugador1;}
    public Jugador getJugador2() {return jugador2;}
    public LocalDateTime getFecha() {return fecha;}
    public int getNumPartidas() {return numPartidas;}
    public Jugador getGanador() {return ganador;}
    public int getPuntajeJugador2() {return puntajeJugador2;}
    public List<Partida> getPartidas() {return partidas;}
    public EstadoEnfrentamiento getEstado() {return estado;}
    public Jugador getJugador1() {return jugador1;}
    public List<Jugador> getJugadores() {return jugadores;}
    public Contrincante getContrincante() {return contrincante;}
    public int getIdPartida() {return idPartida;}

    //Metodos set
    public void setJugador(int indice, Jugador jugador){jugadores.set(indice, jugador);}
    public void setNumJugadores(int numJugadores) {this.numJugadores = numJugadores;}
    public void setObservaciones(String observaciones) {this.observaciones = observaciones != null ? observaciones : "";}
    public void setPuntajeJugador1(int puntajeJugador1) {this.puntajeJugador1 = puntajeJugador1;}
    public void setJugador2(Jugador jugador2) {this.jugador2 = jugador2;}
    public void setFecha(LocalDateTime fecha) {this.fecha = fecha;}
    public void setNumPartidas(int numPartidas) {this.numPartidas = numPartidas;}
    public void setGanador(Jugador ganador) {this.ganador = ganador;}
    public void setPuntajeJugador2(int puntajeJugador2) {this.puntajeJugador2 = puntajeJugador2;}
    public void setPartidas(List<Partida> partidas) {this.partidas = partidas;}
    public void setEstado(EstadoEnfrentamiento estado) {this.estado = estado;}
    public void setJugador1(Jugador jugador1) {this.jugador1 = jugador1;}
    public void setJugadores(List<Jugador> jugadores) {this.jugadores = jugadores;}
    public void setContrincante(Contrincante contrincante) {this.contrincante = contrincante;}
    public void setIdPartida(int id){this.idPartida = id;}

    //Metodos CRUD
    public String crearPartidaMaquina() {
        return "Partida contra la maquina";
    }
    public String crearPartidaMultijugador() {
        if (jugadores.size() < 2) {
            throw new Excepcion("Deben haber por lo menos 2 jugadores registrados");
        }
        return "Partida multijugadore creada con exito";
    }

    //Metodos
    public String asignarEmpate() {
        this.estado = EstadoEnfrentamiento.EMPATE;
        this.puntajeJugador1 = 0;
        this.puntajeJugador2 = 0;
        if (puntajeJugador1 < 0 || puntajeJugador2 < 0) {
            throw new Excepcion("Los puntajes no pueden ser negativos");
        }
        return "Resultado asignado: Empate";
    }
    public String asignarResultadoConPuntaje(int puntajeJ1, int puntajeJ2) {
        this.puntajeJugador1 = puntajeJ1;
        this.puntajeJugador2 = puntajeJ2;

        if (puntajeJ1 > puntajeJ2) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR1;
            this.ganador = jugador1;
        } else if (puntajeJ2 > puntajeJ1) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR2;
            this.ganador = jugador2;
        } else {
            this.estado = EstadoEnfrentamiento.EMPATE;
            this.ganador = null;
        }

        return "Resultado asignado con puntajes: " + puntajeJ1 + " - " + puntajeJ2;
    }
    public String asignarGanador(Jugador nombreGanador) {
        String nombreJ1 = jugador1.getNombre() + " " + jugador1.getApellido();
        String nombreJ2 = jugador2.getNombre() + " " + jugador2.getApellido();

        if (nombreGanador.equals(nombreJ1)) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR1;
            this.puntajeJugador1 = 1;
            this.puntajeJugador2 = 0;
            return "Resultado asignado: Ganador - " + nombreJ1;
        } else if (nombreGanador.equals(nombreJ2)) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR2;
            this.puntajeJugador1 = 0;
            this.puntajeJugador2 = 1;
            return "Resultado asignado: Ganador - " + nombreJ2;
        } else {
            throw new IllegalArgumentException("El jugador ganador debe ser uno de los participantes del enfrentamiento.");
        }
    }
    public String asignarResultados(String resultado) {
        if (resultado == null) {
            return "Resultado no válido.";
        }

        String nombreJ1 = jugador1.getNombre() + " " + jugador1.getApellido();
        String nombreJ2 = jugador2.getNombre() + " " + jugador2.getApellido();

        if (resultado.equals(nombreJ1)) {
            asignarGanador(jugador1);
        } else if (resultado.equals(nombreJ2)) {
            asignarGanador(jugador2);
        } else if (resultado.equalsIgnoreCase("Empate")) {
            asignarEmpate();
        } else {
            return "Resultado no válido.";
        }
        return nombreJ1;
    }
    private String validarDuplicadoJugador(Jugador jugador) {
        if (jugadores == null || numJugadores == 0) {
            return "No hay jugadores registrados, no es duplicado";
        }

        for (int i = 0; i < numJugadores; i++) {
            if (jugadores.get(i) != null && jugadores.get(i).equals(jugador)) {
                return "Jugador duplicado encontrado: " +
                        jugador.getNombre() + " " + jugador.getApellido();
            }
        }

        return "Jugador no duplicado: " + jugador.getNombre() + " " + jugador.getApellido();

    }

    @Override
    public String toString() {
        return String.format(
                "=== INFORMACIÓN DE LA PARTIDA ===%n" +
                        "Partida ID:        %-20s%n" +
                        "Contrincante:      %-20s%n" +
                        "Fecha:             %-20s%n" +
                        "Puntaje Jugador 1: %-10d%n" +
                        "Puntaje Jugador 2: %-10d%n" +
                        "Observaciones:     %-30s%n" +
                        "================================",
                idPartida, contrincante, fecha, puntajeJugador1, puntajeJugador2, observaciones
        );
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Partida)) {
            return false;
        }

        Partida partida = (Partida) obj;

        return Objects.equals(fecha, partida.fecha) &&
                estado == partida.estado &&
                Objects.equals(contrincante, partida.contrincante);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(fecha, estado, contrincante);
        result = 31 * result;
        return result;
    }
}
