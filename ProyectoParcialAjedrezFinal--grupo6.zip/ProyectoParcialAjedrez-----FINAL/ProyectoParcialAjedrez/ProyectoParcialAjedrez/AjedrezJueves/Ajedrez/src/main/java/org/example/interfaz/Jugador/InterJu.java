package org.example.interfaz.Jugador;

import org.example.dominio.Competencia;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;

    public class InterJu extends JFrame{
        private JPanel mainPanel8;
        private JButton volverButton;
        private JButton buttonRegistrarJugador;
        private JButton buttonEliminarJugador;
        private JButton buttonModificarJugador;
        private JButton buttonConsultarJugador;
        private JButton buttonMostrarJugadoresOrdenados;
        private JLabel im1;
        private JLabel im2;
        private JLabel im3;
        private JLabel im4;
        private JLabel im5;
        private JLabel im6;
        private JLabel im7;
        private JLabel im8;
        private JLabel im9;
        private JLabel im10;
        private static JFrame parentWindow;
        private Competencia competencia;
        // Lista para almacenar los jugadores
        private static ArrayList<Jugador> jugadores = new ArrayList<>();
        private static int siguienteId = 1;

        public InterJu(JFrame parent, Competencia competencia) {
            im1.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im1.png"));
            im2.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im2.png"));
            im3.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im3.png"));
            im4.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im4.png"));
            im5.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im2.png"));
            im6.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im1.png"));
            im7.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im2.png"));
            im8.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im3.png"));
            im9.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im4.png"));
            im10.setIcon(new ImageIcon("C:\\Users\\adolf\\Downloads\\ProyectoParcialAjedrez\\cosas\\im2.png"));
            this.parentWindow = parent;
            this.competencia = competencia;

            initializeWindow();
            setupComponents();
            setupActionListeners();
            // Inicializar jugadores de la competencia al abrir la interfaz
            inicializarJugadoresDeCompetencia();
        }

        private void inicializarJugadoresDeCompetencia() {
            try {
                jugadores.clear();
                // Si la competencia tiene jugadores, agregarlos a nuestra lista local
                if (competencia.getJugadores() != null && !competencia.getJugadores().isEmpty()) {
                    // Convertir los jugadores de Competencia a jugadores locales
                    for (Object jugadorCompetencia : competencia.getJugadores()) {
                        // Asumiendo que el jugador de Competencia tiene métodos similares
                        // Aquí necesitarías adaptar según la estructura real de tu clase Jugador en Competencia
                        agregarJugadorDesdeCompetencia(jugadorCompetencia);
                    }

                    // Actualizar el siguienteId para evitar conflictos
                    if (!jugadores.isEmpty()) {
                        siguienteId = jugadores.stream()
                                .mapToInt(Jugador::getIdJugador)
                                .max()
                                .orElse(0) + 1;
                    }

                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(this,
                                "Jugadores cargados: " + jugadores.size(),
                                "Inicialización Completada",
                                JOptionPane.INFORMATION_MESSAGE);
                    });
                } else {
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(this,
                                "No hay jugadores registrados en la competencia ",
                                "Inicialización de Jugadores",
                                JOptionPane.INFORMATION_MESSAGE);
                    });
                }
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(this,
                            "Error al inicializar jugadores: " + e.getMessage(),
                            "Error de Inicialización",
                            JOptionPane.ERROR_MESSAGE);
                });
            }
        }

        private void agregarJugadorDesdeCompetencia(Object jugadorCompetencia) {
            // Aquí necesitas adaptar según la estructura de tu clase Jugador en Competencia
            // Este es un ejemplo genérico que debes modificar según tus clases reales
            try {
                // Usando reflexión como ejemplo, pero es mejor usar métodos directos
                String nombre = getValorCampo(jugadorCompetencia, "nombre");
                String apellido = getValorCampo(jugadorCompetencia, "apellido");
                String genero = getValorCampo(jugadorCompetencia, "genero");
                String conocimiento = getValorCampo(jugadorCompetencia, "conocimientoDeJuego");
                Integer id = (Integer) getValorCampoObjeto(jugadorCompetencia, "idJugador");

                // Si no tiene ID, asignar el siguiente disponible
                if (id == null || id == 0) {
                    id = siguienteId++;
                }

                // Valores por defecto si no existen
                if (genero == null || genero.isEmpty()) genero = "No especificado";
                if (conocimiento == null || conocimiento.isEmpty()) conocimiento = "principiante";

                Jugador jugadorLocal = new Jugador(id, nombre, apellido, genero, conocimiento);
                jugadores.add(jugadorLocal);

            } catch (Exception e) {
                System.err.println("Error al convertir jugador: " + e.getMessage());
            }
        }

        private String getValorCampo(Object objeto, String nombreCampo) {
            try {
                java.lang.reflect.Field campo = objeto.getClass().getDeclaredField(nombreCampo);
                campo.setAccessible(true);
                Object valor = campo.get(objeto);
                return valor != null ? valor.toString() : "";
            } catch (Exception e) {
                // Si no encuentra el campo, intentar con métodos getter
                try {
                    String metodGetter = "get" + nombreCampo.substring(0, 1).toUpperCase() + nombreCampo.substring(1);
                    java.lang.reflect.Method metodo = objeto.getClass().getMethod(metodGetter);
                    Object valor = metodo.invoke(objeto);
                    return valor != null ? valor.toString() : "";
                } catch (Exception ex) {
                    return "";
                }
            }
        }

        private Object getValorCampoObjeto(Object objeto, String nombreCampo) {
            try {
                java.lang.reflect.Field campo = objeto.getClass().getDeclaredField(nombreCampo);
                campo.setAccessible(true);
                return campo.get(objeto);
            } catch (Exception e) {
                try {
                    String metodGetter = "get" + nombreCampo.substring(0, 1).toUpperCase() + nombreCampo.substring(1);
                    java.lang.reflect.Method metodo = objeto.getClass().getMethod(metodGetter);
                    return metodo.invoke(objeto);
                } catch (Exception ex) {
                    return null;
                }
            }
        }

        private void initializeWindow() {
            setTitle("Gestión de Jugadores - CheckMate");
            setContentPane(mainPanel8);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setSize(800, 600);
            setLocationRelativeTo(parentWindow);
            setResizable(false);
        }
        private void setupComponents() {
            // Configuración de estilos
            /*textJugador.setFont(new Font("Arial", Font.BOLD, 24));
            textJugador.setHorizontalAlignment(SwingConstants.CENTER);*/

            // Configuración de botones
            buttonRegistrarJugador.setFont(new Font("Arial", Font.PLAIN, 16));
            buttonEliminarJugador.setFont(new Font("Arial", Font.PLAIN, 16));
            buttonModificarJugador.setFont(new Font("Arial", Font.PLAIN, 16));
            buttonConsultarJugador.setFont(new Font("Arial", Font.PLAIN, 16));
            buttonMostrarJugadoresOrdenados.setFont(new Font("Arial", Font.PLAIN, 16));
            volverButton.setFont(new Font("Arial", Font.PLAIN, 16));
        }

        private void setupActionListeners() {
            volverButton.addActionListener(e -> {
                this.dispose();
                parentWindow.setVisible(true);
            });

            buttonRegistrarJugador.addActionListener(e -> registrarJugador());
            buttonEliminarJugador.addActionListener(e -> eliminarJugador());
            buttonModificarJugador.addActionListener(e -> modificarJugador());
            buttonConsultarJugador.addActionListener(e -> consultarJugador());
            buttonMostrarJugadoresOrdenados.addActionListener(e -> mostrarJugadoresOrdenados());
        }

        private void registrarJugador() {
            JDialog dialog = new JDialog(this, "Registrar Jugador", true);
            dialog.setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();

            // Campos del formulario
            JTextField nombreField = new JTextField(20);
            JTextField apellidoField = new JTextField(20);
            JComboBox<String> generoCombo = new JComboBox<>(new String[]{"Masculino", "Femenino", "Otro"});
            JComboBox<String> conocimientoCombo = new JComboBox<>(new String[]{"principiante", "intermedio", "avanzado"});

            // Campo de fecha (solo lectura, se asigna automáticamente)
            JTextField fechaField = new JTextField(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")), 20);
            fechaField.setEnabled(false);
            fechaField.setBackground(Color.LIGHT_GRAY);

            // Layout del formulario
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.anchor = GridBagConstraints.WEST;

            gbc.gridx = 0; gbc.gridy = 0;
            dialog.add(new JLabel("Nombre:"), gbc);
            gbc.gridx = 1;
            dialog.add(nombreField, gbc);

            gbc.gridx = 0; gbc.gridy = 1;
            dialog.add(new JLabel("Apellido:"), gbc);
            gbc.gridx = 1;
            dialog.add(apellidoField, gbc);

            gbc.gridx = 0; gbc.gridy = 2;
            dialog.add(new JLabel("Género:"), gbc);
            gbc.gridx = 1;
            dialog.add(generoCombo, gbc);

            gbc.gridx = 0; gbc.gridy = 3;
            dialog.add(new JLabel("Conocimiento de Juego:"), gbc);
            gbc.gridx = 1;
            dialog.add(conocimientoCombo, gbc);

            gbc.gridx = 0; gbc.gridy = 4;
            dialog.add(new JLabel("Fecha de Registro:"), gbc);
            gbc.gridx = 1;
            dialog.add(fechaField, gbc);

            // Botones
            JPanel buttonPanel = new JPanel();
            JButton guardarBtn = new JButton("Guardar");
            JButton cancelarBtn = new JButton("Cancelar");

            guardarBtn.addActionListener(e -> {
                try {
                    String nombre = nombreField.getText().trim();
                    String apellido = apellidoField.getText().trim();
                    String genero = (String) generoCombo.getSelectedItem();
                    String conocimiento = (String) conocimientoCombo.getSelectedItem();

                    if (nombre.isEmpty() || apellido.isEmpty()) {
                        JOptionPane.showMessageDialog(dialog, "Nombre y apellido son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (!esSoloLetras(nombre) || !esSoloLetras(apellido)) {
                        JOptionPane.showMessageDialog(dialog, "Nombre y apellido solo pueden contener letras.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Crear jugador con todos los atributos
                    Jugador nuevoJugador = new Jugador(siguienteId++, nombre, apellido, genero, conocimiento);
                    jugadores.add(nuevoJugador);

                    // También agregarlo a la competencia si es posible
                    try {
                        if (competencia != null) {
                            // Aquí deberías llamar al método correspondiente de tu clase Competencia
                            // Por ejemplo: competencia.agregarJugador(nuevoJugador);
                            // O crear un jugador compatible con Competencia
                        }
                    } catch (Exception ex) {
                        System.err.println("Error al sincronizar con Competencia: " + ex.getMessage());
                    }

                    JOptionPane.showMessageDialog(dialog, "Jugador registrado exitosamente con ID: " + nuevoJugador.getIdJugador(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose();

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error al registrar jugador: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            cancelarBtn.addActionListener(e -> dialog.dispose());

            buttonPanel.add(guardarBtn);
            buttonPanel.add(cancelarBtn);

            gbc.gridx = 0; gbc.gridy = 5;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            dialog.add(buttonPanel, gbc);

            dialog.pack();
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        }

        private void eliminarJugador() {
            if (jugadores.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay jugadores registrados", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] jugadoresInfo = jugadores.stream()
                    .map(j -> "ID: " + j.getIdJugador() + " - " + j.getNombre() + " " + j.getApellido())
                    .toArray(String[]::new);
            String seleccion = (String) JOptionPane.showInputDialog(this, "Selecciona el jugador a eliminar:",
                    "Eliminar Jugador", JOptionPane.QUESTION_MESSAGE,
                    null, jugadoresInfo, jugadoresInfo[0]);

            if (seleccion != null) {
                int id = Integer.parseInt(seleccion.split(" - ")[0].replace("ID: ", ""));
                Jugador jugador = buscarJugadorPorId(id);

                if (jugador != null) {
                    int confirmacion = JOptionPane.showConfirmDialog(this,
                            "¿Estás seguro de eliminar al jugador " + jugador.getNombre() + " " + jugador.getApellido() + "?",
                            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

                    if (confirmacion == JOptionPane.YES_OPTION) {
                        jugadores.remove(jugador);

                        // También eliminar de la competencia si es posible
                        try {
                            if (competencia != null) {
                                // Aquí deberías llamar al método correspondiente de tu clase Competencia
                                // Por ejemplo: competencia.eliminarJugador(jugador.getIdJugador());
                            }
                        } catch (Exception ex) {
                            System.err.println("Error al sincronizar eliminación con Competencia: " + ex.getMessage());
                        }

                        JOptionPane.showMessageDialog(this, "Jugador eliminado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        }

        private void modificarJugador() {
            if (jugadores.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay jugadores registrados", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] jugadoresInfo = jugadores.stream()
                    .map(j -> "ID: " + j.getIdJugador() + " - " + j.getNombre() + " " + j.getApellido())
                    .toArray(String[]::new);
            String seleccion = (String) JOptionPane.showInputDialog(this, "Selecciona el jugador a modificar:",
                    "Modificar Jugador", JOptionPane.QUESTION_MESSAGE,
                    null, jugadoresInfo, jugadoresInfo[0]);

            if (seleccion != null) {
                int id = Integer.parseInt(seleccion.split(" - ")[0].replace("ID: ", ""));
                Jugador jugador = buscarJugadorPorId(id);

                if (jugador != null) {
                    mostrarFormularioModificar(jugador);
                }
            }
        }
        private boolean esSoloLetras(String texto) {
            return texto.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+");
        }

        private void mostrarFormularioModificar(Jugador jugador) {
            JDialog dialog = new JDialog(this, "Modificar Jugador", true);
            dialog.setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();

            // Campos prellenados con los datos actuales
            JTextField nombreField = new JTextField(jugador.getNombre(), 20);
            JTextField apellidoField = new JTextField(jugador.getApellido(), 20);
            JComboBox<String> generoCombo = new JComboBox<>(new String[]{"Masculino", "Femenino", "Otro"});
            generoCombo.setSelectedItem(jugador.getGenero());
            JComboBox<String> conocimientoCombo = new JComboBox<>(new String[]{"principiante", "intermedio", "avanzado"});
            conocimientoCombo.setSelectedItem(jugador.getConocimientoDeJuego());

            // Mostrar ID (solo lectura)
            JTextField idField = new JTextField(String.valueOf(jugador.getIdJugador()), 20);
            idField.setEnabled(false);

            // Mostrar fecha de registro (solo lectura)
            JTextField fechaField = new JTextField(jugador.getFechaDeRegistro().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")), 20);
            fechaField.setEnabled(false);
            fechaField.setBackground(Color.LIGHT_GRAY);

            // Layout del formulario
            gbc.insets = new Insets(5, 5, 5, 5);
            gbc.anchor = GridBagConstraints.WEST;

            gbc.gridx = 0; gbc.gridy = 0;
            dialog.add(new JLabel("ID:"), gbc);
            gbc.gridx = 1;
            dialog.add(idField, gbc);

            gbc.gridx = 0; gbc.gridy = 1;
            dialog.add(new JLabel("Nombre:"), gbc);
            gbc.gridx = 1;
            dialog.add(nombreField, gbc);

            gbc.gridx = 0; gbc.gridy = 2;
            dialog.add(new JLabel("Apellido:"), gbc);
            gbc.gridx = 1;
            dialog.add(apellidoField, gbc);

            gbc.gridx = 0; gbc.gridy = 3;
            dialog.add(new JLabel("Género:"), gbc);
            gbc.gridx = 1;
            dialog.add(generoCombo, gbc);

            gbc.gridx = 0; gbc.gridy = 4;
            dialog.add(new JLabel("Conocimiento:"), gbc);
            gbc.gridx = 1;
            dialog.add(conocimientoCombo, gbc);

            gbc.gridx = 0; gbc.gridy = 5;
            dialog.add(new JLabel("Fecha de Registro:"), gbc);
            gbc.gridx = 1;
            dialog.add(fechaField, gbc);

            // Botones
            JPanel buttonPanel = new JPanel();
            JButton guardarBtn = new JButton("Guardar Cambios");
            JButton cancelarBtn = new JButton("Cancelar");

            guardarBtn.addActionListener(e -> {
                try {
                    String nombre = nombreField.getText().trim();
                    String apellido = apellidoField.getText().trim();
                    String genero = (String) generoCombo.getSelectedItem();
                    String conocimiento = (String) conocimientoCombo.getSelectedItem();
                    if (nombre.isEmpty() || apellido.isEmpty()) {
                        JOptionPane.showMessageDialog(dialog, "Nombre y apellido son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (!esSoloLetras(nombre) || !esSoloLetras(apellido)) {
                        JOptionPane.showMessageDialog(dialog, "Nombre y apellido solo pueden contener letras.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    jugador.setNombre(nombre);
                    jugador.setApellido(apellido);
                    jugador.setGenero(genero);
                    jugador.setConocimientoDeJuego(conocimiento);

                    // También actualizar en la competencia si es posible
                    try {
                        if (competencia != null) {
                            competencia.actualizarJugador(jugador.getIdJugador(), nombre, apellido, genero, conocimiento);
                        }
                    } catch (Exception ex) {
                        System.err.println("Error al sincronizar modificación con Competencia: " + ex.getMessage());
                    }

                    JOptionPane.showMessageDialog(dialog, "Jugador modificado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose();

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error al modificar jugador: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            cancelarBtn.addActionListener(e -> dialog.dispose());

            buttonPanel.add(guardarBtn);
            buttonPanel.add(cancelarBtn);

            gbc.gridx = 0; gbc.gridy = 6;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            dialog.add(buttonPanel, gbc);

            dialog.pack();
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        }

        private void consultarJugador() {
            if (jugadores.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay jugadores registrados", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String idStr = JOptionPane.showInputDialog(this, "Ingresa el ID del jugador a consultar:", "Consultar Jugador", JOptionPane.QUESTION_MESSAGE);

            if (idStr != null && !idStr.trim().isEmpty()) {
                try {
                    int id = Integer.parseInt(idStr.trim());
                    Jugador jugador = buscarJugadorPorId(id);

                    if (jugador != null) {
                        mostrarInformacionJugador(jugador);
                    } else {
                        JOptionPane.showMessageDialog(this, "Jugador no encontrado", "Información", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "ID debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        private void mostrarInformacionJugador(Jugador jugador) {
            StringBuilder info = new StringBuilder();
            info.append("INFORMACIÓN DEL JUGADOR\n");
            info.append("========================\n\n");
            info.append("ID: ").append(jugador.getIdJugador()).append("\n");
            info.append("Nombre: ").append(jugador.getNombre()).append("\n");
            info.append("Apellido: ").append(jugador.getApellido()).append("\n");
            info.append("Género: ").append(jugador.getGenero()).append("\n");
            info.append("Conocimiento de Juego: ").append(jugador.getConocimientoDeJuego()).append("\n");
            info.append("Fecha de Registro: ").append(jugador.getFechaDeRegistro().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\n");

            JTextArea textArea = new JTextArea(info.toString());
            textArea.setEditable(false);
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 300));

            JOptionPane.showMessageDialog(this, scrollPane, "Información del Jugador", JOptionPane.INFORMATION_MESSAGE);
        }

        private void mostrarJugadoresOrdenados() {
            if (jugadores.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay jugadores registrados", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] opciones = {"Por Nombre", "Por ID"};
            String seleccion = (String) JOptionPane.showInputDialog(this, "¿Cómo deseas ordenar los jugadores?",
                    "Ordenar Jugadores", JOptionPane.QUESTION_MESSAGE,
                    null, opciones, opciones[0]);

            if (seleccion != null) {
                ArrayList<Jugador> jugadoresOrdenados = new ArrayList<>(jugadores);

                switch (seleccion) {
                    case "Por Nombre":
                        jugadoresOrdenados.sort(Comparator.comparing(j -> j.getNombre() + " " + j.getApellido()));
                        break;
                    case "Por ID":
                        jugadoresOrdenados.sort(Comparator.comparingInt(Jugador::getIdJugador));
                        break;
                }

                mostrarListaJugadores(jugadoresOrdenados, "Jugadores Ordenados " + seleccion);
            }
        }

        private void mostrarListaJugadores(ArrayList<Jugador> lista, String titulo) {
            StringBuilder listado = new StringBuilder();
            listado.append(titulo.toUpperCase()).append("\n");
            listado.append("=".repeat(titulo.length())).append("\n\n");

            for (int i = 0; i < lista.size(); i++) {
                Jugador j = lista.get(i);
                listado.append(String.format("%d. %s %s - ID: %d - Género: %s - Conocimiento: %s - Registro: %s\n",
                        i + 1, j.getNombre(), j.getApellido(), j.getIdJugador(), j.getGenero(),
                        j.getConocimientoDeJuego(), j.getFechaDeRegistro().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
            }

            JTextArea textArea = new JTextArea(listado.toString());
            textArea.setEditable(false);
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(600, 400));

            JOptionPane.showMessageDialog(this, scrollPane, titulo, JOptionPane.INFORMATION_MESSAGE);
        }

        private Jugador buscarJugadorPorId(int id) {
            return jugadores.stream()
                    .filter(j -> j.getIdJugador() == id)
                    .findFirst()
                    .orElse(null);
        }

        public static void showInterJu(JFrame parent, Competencia competencia) {
            SwingUtilities.invokeLater(() -> {
                org.example.interfaz.Jugador.InterJu gestionJugador = new org.example.interfaz.Jugador.InterJu(parent, competencia);
                parent.setVisible(false);
                gestionJugador.setVisible(true);
            });
        }

        // Clase interna para representar un Jugador - Con género y fecha de registro
        public static class Jugador {
            private int idJugador;
            private String nombre;
            private String apellido;
            private String genero;
            private String conocimientoDeJuego;
            private LocalDateTime fechaDeRegistro;

            public Jugador(int idJugador, String nombre, String apellido, String genero, String conocimientoDeJuego) {
                this.idJugador = idJugador;
                this.nombre = nombre;
                this.apellido = apellido;
                this.genero = genero;
                this.conocimientoDeJuego = conocimientoDeJuego;
                this.fechaDeRegistro = LocalDateTime.now();
            }

            // Getters y Setters
            public int getIdJugador() {
                return idJugador;
            }

            public void setIdJugador(int idJugador) {
                this.idJugador = idJugador;
            }

            public String getNombre() {
                return nombre;
            }

            public void setNombre(String nombre) {
                this.nombre = nombre;
            }

            public String getApellido() {
                return apellido;
            }

            public void setApellido(String apellido) {
                this.apellido = apellido;
            }

            public String getGenero() {
                return genero;
            }

            public void setGenero(String genero) {
                this.genero = genero;
            }

            public String getConocimientoDeJuego() {
                return conocimientoDeJuego;
            }

            public void setConocimientoDeJuego(String conocimientoDeJuego) {
                this.conocimientoDeJuego = conocimientoDeJuego;
            }

            public LocalDateTime getFechaDeRegistro() {
                return fechaDeRegistro;
            }

            public void setFechaDeRegistro(LocalDateTime fechaDeRegistro) {
                this.fechaDeRegistro = fechaDeRegistro;
            }
        }
    }

