package org.example.dominio;

import org.example.util.Excepcion;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * Esta clase representa una competencia o torneo.
 * Aquí se guarda la información del torneo, como su nombre, las fechas,
 * los participantes y los enfrentamientos que se generan.
 */
public class Competencia implements Serializable {
    private static final long serialVersionUID = 1L;

    public int IDPARTIDA;
    private String nombreTorneo;
    private Date fechaInicio;
    private Date fechaFin;
    private boolean iniciada;
    private boolean finalizada;
    private EstadoCompetencia estado;
    // Contador estático para llevar el control de competencias creadas
    private static int contadorCompetencias = 0;
    // Instancia única para el patrón Singleton
    private static Competencia instancia = null; // = new Competencia();
    // ID único de la competencia (final, se asigna una sola vez)
    private final int idCompetencia;
    // Arreglos para manejar las entidades relacionadas
    public List<Jugador> jugadores;
    private List<Partida> partidas;
    private List<Recompensa> recompensas;

    // Contadores para llevar el control de elementos actuales
    private int numJugadores = 0;
    private int numEnfrentamientos;
    private int numRecompensas;
    private int numPartidas;
    public static int contador;

    Jugador ju = new Jugador();
    Partida par = new Partida();
    public Competencia(){
        this("Sin nombre de Torneo",new Date(),new Date());
    }
    // Métodos Singleton
    /**public static Competencia getInstancia() {
     return instancia;
     }**/
    public static synchronized Competencia getInstancia() {
        if (instancia == null) {
            instancia = new Competencia();
        }
        return instancia;
    }
    /**
     * Constructor para crear una competencia.
     * Verifica que el nombre y las fechas sean válidas antes de guardar.
     *
     * @param nombreTorneo nombre del torneo.
     * @param fechaInicio  cuándo empieza el torneo.
     * @param fechaFin     cuándo termina el torneo.
     */
    public Competencia(String nombreTorneo, Date fechaInicio, Date fechaFin) {
        if (nombreTorneo == null || nombreTorneo.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        nombreTorneo = nombreTorneo.trim().replaceAll("\\s+", " ");
        if (!nombreTorneo.matches("[\\p{L}0-9\\s\\-()\\.]+")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras, números, espacios y algunos símbolos como guiones.");
        }

        if (nombreTorneo.length() < 2) {
            throw new IllegalArgumentException("El nombre debe tener al menos 2 caracteres.");
        }

        this.idCompetencia=++contadorCompetencias;
        this.nombreTorneo = nombreTorneo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.iniciada = false;
        this.finalizada = false;
        this.estado = EstadoCompetencia.NO_INICIADA;
        this.jugadores = new ArrayList<>(3);
        this.partidas = new ArrayList<>(8);
        inicializar();
    }

    public String inicializar(){
        StringBuilder resultado = new StringBuilder();
        try {
            registrarJugador(123,"Francisco","Salas","intermedio",LocalDateTime.now(),Genero.MASCULINO);
            registrarJugador(345,"Fernando","Rios","intermedio",LocalDateTime.now(),Genero.MASCULINO);
            registrarJugador(567,"Daniel","Salas","intermedio",LocalDateTime.now(),Genero.MASCULINO);
            registrarJugador(488, "Adolfo", "Melendez", "intermedio", LocalDateTime.now(), Genero.MASCULINO);
            registrarJugador(789, "Aylin", "Tapia", "intermedio", LocalDateTime.now(), Genero.FEMENINO);
            resultado.append("Competencia inicializada con ").append(numJugadores).append(" jugadores.");

            registrarPartida(5,100,0,LocalDateTime.now(), "no me pude mover bien", Contrincante.MAQUINA, EstadoEnfrentamiento.GANADOR_JUGADOR1);
            registrarPartida(8,0,0,LocalDateTime.now(), "la partida no inicio", Contrincante.JUGADOR, EstadoEnfrentamiento.SIN_JUGAR);
            registrarPartida(3,0,50,LocalDateTime.now(), "se distribuyeron mal los puntos", Contrincante.JUGADOR, EstadoEnfrentamiento.GANADOR_JUGADOR2);

            Recompensa re1 = new Logro("papure");
            Recompensa re2 = new Logro("papure", "increible", 500, true);
            Recompensa re3 = new Logro();
            Recompensa re4 = new Logro();
            Recompensa re5 = new Logro();
            ju.registrarRecompensa(re1);
            ju.registrarRecompensa(re2);
            ju.registrarRecompensa(re3);
            ju.registrarRecompensa(re4);
            ju.registrarRecompensa(re5);
        } catch (Exception e) {
            resultado.append("Error al inicializar jugadores: ").append(e.getMessage());
        }
        return resultado.toString();
    }

    public static void reiniciarContador() {
        contadorCompetencias = 0;
    }
    /**
     * Agrega un nuevo participante a la competencia si no ha sido agregado antes.
     *
     * @param nombre Nombre del jugador a agregar.
     */
    public void registrarJugador(int id, String nombre, String apellido, String conocimiento, LocalDateTime fecha, Genero genero) {
        if (buscarJugador(id) != null) {
            throw new IllegalArgumentException("Ya existe un jugador con este id.");
        }
        Jugador nuevoJugador = new Jugador(id, nombre, apellido, conocimiento, fecha, genero);
        jugadores.add(nuevoJugador);
    }

    public void registrarJugador(Jugador jugador) {
        if (jugador == null || jugadores.contains(jugador)) {
            throw new IllegalArgumentException("Jugador nulo o ya registrado.");
        }
        jugadores.add(jugador);
    }

    /**
     * Busca un jugador por su ID
     * @param id identifica el jugador a buscar
     * @return El jugador encontrado, o null si no existe
     */
    public boolean actualizarJugador(int id, String nuevoNombre, String nuevoApellido, String nuevoGenero, String nuevoConocimiento) {
        for (Jugador jugador : jugadores) {
            if (jugador.getIdJugador() == id) {
                jugador.setNombre(nuevoNombre);
                jugador.setApellido(nuevoApellido);
                jugador.setGenero(Genero.valueOf(nuevoGenero.toUpperCase()));
                jugador.setConocimientoDeJuego(nuevoConocimiento);
                return true;  // Se actualizó correctamente
            }
        }
        return false;  // No se encontró el jugador
    }

    public Jugador buscarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores.get(i).getIdJugador() == id) {
                return jugadores.get(i);
            }
        }
        return null;
    }

    /**
     * Busca el índice de un jugador por su ID
     */
    public int buscarIndicePorId(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores.get(i).getIdJugador() == id) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Editar los datos de un jugador existente en la posicion especifica
     * @param indice posicion del jugador a editar
     * @param id nuevo Id del jugador
     * @param nombre nuevo nombre del jugador
     * @param apellido nuevo apellido del jugador
     * @param conocimiento nuevo nivel de conocimiento
     * @param fecha nueva fecha de registro
     */
    public void modificarJugador(int indice, int id, String nombre, String apellido, String conocimiento, LocalDateTime fecha, Genero genero) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        jugadores.set(indice, new Jugador(id, nombre, apellido, conocimiento, fecha, genero));
    }

    public void modificarJugador(int indice, Jugador jugador) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo.");
        }

        boolean idCambiado = jugadores.get(indice).getIdJugador() != jugador.getIdJugador();
        boolean idYaExiste = buscarJugador(jugador.getIdJugador()) != null;

        if (idCambiado && idYaExiste) {
            throw new IllegalArgumentException("Ya existe otro jugador con ese ID.");
        }

        jugadores.set(indice, jugador);
    }
    /**
     * Elimina un jugador de la parida por su Id
     * @param id identificador del jugador a eliminar
     * @return true si el jugador fue eliminado o false si no es encontrado
     */
    public boolean borrarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores.get(i).getIdJugador() == id) {
                // Desplazar los jugadores a la izquierda
                for (int j = i; j < numJugadores - 1; j++) {
                    jugadores.set(j, jugadores.get(j + 1));
                }
                jugadores.set(numJugadores - 1, null);
                numJugadores--;
                return true;
            }
        }
        return false;
    }
    /**
     * Agrega una partida a la competencia
     */
    public String registrarPartida(int id, int punJ1, int punJ2, LocalDateTime fecha, String obs,Contrincante contrincante,
                                   EstadoEnfrentamiento estado) {
        Partida par = new Partida(id, punJ1, punJ2, fecha, obs, contrincante, estado);
        partidas.add(par);
        numPartidas++;
        return "Partida registrada con éxito: " ;
    }
    /*public void registrarPartida(Partida partida) {
        partidas.set(numPartidas, partida);
        numPartidas++;
    }*/
    public String registrarPartida(Partida partida) {
        if (partida == null) {
            return "Error: La partida no puede ser null";
        }
        partidas.add(partida);
        numPartidas++;
        return "Partida registrada desde objeto: ID " + partida.getIdPartida();
    }

    public Partida buscarPartidaPorId(int id) {
        for (Partida partidas: partidas) {
            if (partidas.getIdPartida() == id) {
                return partidas;
            }
        }
        return null;
    }
    public int buscarPartidaPorId(int id, Partida partida) {
        for (int i = 0; i < partidas.size(); i++) {
            if (partidas.get(i).getIdPartida() == id) {
                return i;
            }
        }
        return -1;
    }

    public String editarPartida(int indice, int id, int puntajeJugador1, int puntajeJugador2, String observaciones, LocalDateTime fecha,
                                EstadoEnfrentamiento estado, Contrincante contrincante) {
        if (indice < 0 ) {
            return "Índice de jugador no válido.";
        }

        try {
            Partida par = new Partida(id, puntajeJugador1, puntajeJugador2, fecha, observaciones, estado, contrincante);
            partidas.set(indice, par);
            return "Partida modificada correctamente.";
        } catch (IllegalArgumentException e) {
            return "Error al modificar la partida: " + e.getMessage();
        }
    }
    public String editarPartida(int indice, Partida nuevaPartida) {
        if (indice < 0 || indice >= partidas.size()) {
            return "Índice de partida no válido. Índice: " + indice + ", Tamaño: " + partidas.size();
        }
        try {
            partidas.set(indice, nuevaPartida);
            return "Partida modificada correctamente.";
        } catch (Exception e) {
            return "Error al modificar la partida: " + e.getMessage();
        }
    }

    public boolean eliminarPartida(int id) {
        for (int i = 0; i < partidas.size(); i++) {
            if (partidas.get(i).getIdPartida() == id) {
                partidas.remove(i);
                return true;
            }
        }
        return false;
    }
    public boolean eliminarPartida(Partida partida) {
        if (partida == null) {
            return false;
        }
        partidas.remove(partida);
        return true;
    }

    public List<Partida> consultarPartida() {
        StringBuilder sb = new StringBuilder("No hay partidas registradas");
        if (partidas.size() == 0) {
            sb.toString();
        }
        return partidas;
    }

    public boolean validarDuplicado(Object obj) {
        if (obj == null) return false;

        // Validar duplicado de Jugador
        if (obj instanceof Jugador) {
            Jugador jugador = (Jugador) obj;
            for (int i = 0; i < numJugadores; i++) {
                if (jugadores.get(i) != null && jugadores.get(i).equals(jugador)) {
                    return true;
                }
            }
        }
        // Validar duplicado de Partida
        else if (obj instanceof Partida) {
            Partida partida = (Partida) obj;
            for (int i = 0; i < numPartidas; i++) {
                if (partidas.get(i) != null && partidas.get(i).equals(partida)) {
                    return true;
                }
            }
        }

        return false; // Si no es ninguno de los anteriores o no hay duplicado
    }

    /**
     * Método estático para obtener el número total de competencias creadas
     */
    public static int getTotalCompetenciasCreadas() {
        return contadorCompetencias;
    }
    /**
     * Inicia la competencia si aún no ha comenzado.
     * Muestra un mensaje diciendo si se pudo iniciar o si ya estaba iniciada.
     */
    public void iniciarCompetencia() {
        if (!iniciada) {
            this.iniciada = true;
            System.out.println("Competencia iniciada.");

        } else {
            System.out.println("La competencia ya estaba iniciada.");
        }
    }
    /**
     * Marca la competencia como iniciada directamente.
     */

    public void setIniciarCompetencia() {
        this.iniciada = true;
    }

    /**
     * Marca la competencia como finalizada y muestra un mensaje.
     */

    public void finalizarCompetencia() {
        this.finalizada = true;
        System.out.println("Competencia finalizada.");
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Competencia that = (Competencia) obj;
        return Objects.equals(nombreTorneo, that.nombreTorneo) &&
                Objects.equals(fechaInicio, that.fechaInicio) &&
                Objects.equals(fechaFin, that.fechaFin);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreTorneo, fechaInicio, fechaFin);
    }
    // Métodos getter y setter
    public String getNombreTorneo() {
        return nombreTorneo;
    }
    public void setNombreTorneo(String nombreTorneo) {this.nombreTorneo = nombreTorneo;}

    public Date getFechaInicio() {
        return fechaInicio;
    }
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }
    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public boolean isIniciada() {
        return iniciada;
    }
    public boolean isFinalizada() {
        return finalizada;
    }

    public int getNumJugadores() {
        return numJugadores;
    }

    public int getNumEnfrentamientos() {
        return numEnfrentamientos;
    }

    public int getNumRecompensas() {
        return numRecompensas;
    }

    public int getNumPartidas() {
        return numPartidas;
    }

    public Jugador getJugadores(int indice) {
        if (indice >= 0 && indice < numJugadores) {
            return jugadores.get(indice);
        } else {
            return null;
        }
    }
    public List<Jugador> getJugadores() {
        return jugadores;
    }
    public List<Partida> getPartidas() {
        return partidas;
    }
    public List<Recompensa> getRecompensas() {return recompensas;}

    /**
     * Representación en cadena de la competencia con toda su información
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        // Encabezado principal
        sb.append("\n╔").append("═".repeat(70)).append("╗\n");
        sb.append("║").append(String.format("%70s", "INFORMACIÓN DE LA COMPETENCIA")).append("║\n");
        sb.append("╚").append("═".repeat(70)).append("╝\n\n");

        // Información básica de la competencia
        sb.append("┌").append("─".repeat(70)).append("┐\n");
        sb.append("│").append(String.format("%70s", "DATOS BÁSICOS")).append("│\n");
        sb.append("├").append("─".repeat(70)).append("┤\n");
        sb.append("│ Nombre del Torneo     : ").append(nombreTorneo);
        sb.append(" ".repeat(Math.max(0, 47 - nombreTorneo.length()))).append("│\n");
        sb.append("│ Fecha de Inicio       : ").append(fechaInicio);
        sb.append(" ".repeat(Math.max(0, 47 - fechaInicio.toString().length()))).append("│\n");
        sb.append("│ Fecha de Fin          : ").append(fechaFin);
        sb.append(" ".repeat(Math.max(0, 47 - fechaFin.toString().length()))).append("│\n");
        sb.append("│ Estado                : ").append(estado.getDescripcion());
        sb.append(" ".repeat(Math.max(0, 47 - estado.getDescripcion().length()))).append("│\n");
        sb.append("└").append("─".repeat(70)).append("┘\n\n");

        // Información de jugadores
        sb.append("┌").append("─".repeat(70)).append("┐\n");
        sb.append("│").append("JUGADORES REGISTRADOS (").append(numJugadores).append(")");
        sb.append(" ".repeat(Math.max(0, 70 - ("JUGADORES REGISTRADOS (" + numJugadores + ")").length()))).append("│\n");
        sb.append("├").append("─".repeat(70)).append("┤\n");

        if (numJugadores == 0) {
            sb.append("│").append("No hay jugadores registrados");
            sb.append(" ".repeat(70 - "No hay jugadores registrados".length())).append("│\n");
        } else {
            for (int i = 0; i < numJugadores; i++) {
                String jugadorStr = jugadores.get(i).toString();
                sb.append("│ ").append(String.format("%2d", i + 1)).append(". ").append(jugadorStr);
                int espacios = Math.max(0, 64 - jugadorStr.length());
                sb.append(" ".repeat(espacios)).append("│\n");
            }
        }
        sb.append("└").append("─".repeat(70)).append("┘\n\n");

        // Información de partidas
        sb.append("┌").append("─".repeat(70)).append("┐\n");
        sb.append("│").append("PARTIDAS (").append(numPartidas).append(")");
        sb.append(" ".repeat(Math.max(0, 70 - ("PARTIDAS (" + numPartidas + ")").length()))).append("│\n");
        sb.append("├").append("─".repeat(70)).append("┤\n");

        if (numPartidas == 0) {
            sb.append("│").append("No hay partidas registradas");
            sb.append(" ".repeat(70 - "No hay partidas registradas".length())).append("│\n");
        } else {
            for (int i = 0; i < numPartidas; i++) {
                String partidaStr = partidas.get(i).toString();
                sb.append("│ ").append(String.format("%2d", i + 1)).append(". ").append(partidaStr);
                int espacios = Math.max(0, 64 - partidaStr.length());
                sb.append(" ".repeat(espacios)).append("│\n");
            }
        }
        sb.append("└").append("─".repeat(70)).append("┘\n");

        return sb.toString();
    }


    public int compareTo(Competencia o) {
        int resultado = this.nombreTorneo.compareTo(o.getNombreTorneo());
        if(resultado>0){
            return 1;
        } else if (resultado<0) {
            return -1;
        }else
            return 0;
    }
}


