package org.example.interfaz.Partida;

import org.example.dominio.*;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class CrearPartida extends JFrame{
    private JLabel textCrearPartida;
    private JButton buttonPartidaMulti;
    private JButton buttonPartidaMaqui;
    private JButton buttonVolver3;
    private JPanel mainPanel3;
    private static JFrame parentWindow1;
    private static Competencia competenciaGlobal = Competencia.getInstancia();

    public CrearPartida(JFrame parent){
        this.parentWindow1 = parent;
        initializeWindow();
        setupComponents();

        buttonVolver3.addActionListener(e -> {
            this.dispose();
            parentWindow1.setVisible(true);
        });
        buttonPartidaMulti.addActionListener(e -> registrarPartidaMultijugador());
        // AGREGADO: Action listener para partida contra máquina
        buttonPartidaMaqui.addActionListener(e -> registrarPartidaMaquina());
    }

    private boolean esSoloLetras(String texto) {
        return texto.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+");
    }

    private void registrarPartidaMultijugador(){
        // Verificar si hay jugadores registrados
        if (competenciaGlobal.getJugadores().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay jugadores registrados. Primero debe registrar jugadores.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (competenciaGlobal.getJugadores().size() < 2) {
            JOptionPane.showMessageDialog(this, "Se necesitan al menos 2 jugadores registrados para una partida multijugador.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JDialog dialog = new JDialog(this, "Registrar Partida Multijugador", true);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Campos del formulario
        JTextField idPartida = new JTextField(20);
        JTextField observacion = new JTextField(20);

        // MEJORADO: ComboBox para seleccionar jugadores registrados
        JComboBox<String> jugador1ComboBox = new JComboBox<>();
        JComboBox<String> jugador2ComboBox = new JComboBox<>();

        // Llenar los ComboBox con jugadores registrados
        for (Jugador jugador : competenciaGlobal.getJugadores()) {
            String jugadorInfo = "ID: " + jugador.getIdJugador() + " - " + jugador.getNombre() + " " + jugador.getApellido();
            jugador1ComboBox.addItem(jugadorInfo);
            jugador2ComboBox.addItem(jugadorInfo);
        }

        // Campo de fecha (solo lectura, se asigna automáticamente)
        JTextField fechaField = new JTextField(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")), 20);
        fechaField.setEnabled(false);
        fechaField.setBackground(Color.LIGHT_GRAY);

        // Layout del formulario
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        dialog.add(new JLabel("Ingrese id de la partida:"), gbc);
        gbc.gridx = 1;
        dialog.add(idPartida, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        dialog.add(new JLabel("Ingrese su observación:"), gbc);
        gbc.gridx = 1;
        dialog.add(observacion, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        dialog.add(new JLabel("Seleccione Jugador 1:"), gbc);
        gbc.gridx = 1;
        dialog.add(jugador1ComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        dialog.add(new JLabel("Seleccione Jugador 2:"), gbc);
        gbc.gridx = 1;
        dialog.add(jugador2ComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        dialog.add(new JLabel("Fecha de Registro:"), gbc);
        gbc.gridx = 1;
        dialog.add(fechaField, gbc);

        // Botones
        JPanel buttonPanel = new JPanel();
        JButton guardarBtn = new JButton("Guardar");
        JButton cancelarBtn = new JButton("Cancelar");

        guardarBtn.addActionListener(e -> {
            try {
                // Validaciones
                String idText = idPartida.getText().trim();
                String obs = observacion.getText().trim();

                if (idText.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "El ID de partida es obligatorio.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (obs.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "La observación es obligatoria.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!esSoloLetras(obs)) {
                    JOptionPane.showMessageDialog(dialog, "La observación solo puede contener letras.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // MEJORADO: Extraer IDs de los jugadores seleccionados
                String jugador1Selected = (String) jugador1ComboBox.getSelectedItem();
                String jugador2Selected = (String) jugador2ComboBox.getSelectedItem();

                if (jugador1Selected == null || jugador2Selected == null) {
                    JOptionPane.showMessageDialog(dialog, "Debe seleccionar ambos jugadores.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Extraer los IDs de las cadenas seleccionadas
                int id1 = Integer.parseInt(jugador1Selected.split(" - ")[0].replace("ID: ", ""));
                int id2 = Integer.parseInt(jugador2Selected.split(" - ")[0].replace("ID: ", ""));

                // Verificar que no sean el mismo jugador
                if (id1 == id2) {
                    JOptionPane.showMessageDialog(dialog, "No puede seleccionar el mismo jugador para ambas posiciones.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // CORREGIDO: Verificar que el ID de partida no exista ya
                int id = Integer.parseInt(idText);
                if (competenciaGlobal.buscarPartidaPorId(id) != null) {
                    JOptionPane.showMessageDialog(dialog, "Ya existe una partida con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Crear partida con todos los atributos
                int puntaje1 = 0;
                int puntaje2 = 0;

                Partida par = new Partida(id, puntaje1, puntaje2, LocalDateTime.now(), obs, Contrincante.JUGADOR, EstadoEnfrentamiento.EMPATE);

                // CORREGIDO: Registrar la partida usando la instancia singleton
                competenciaGlobal.registrarPartida(par);

                // Obtener nombres de los jugadores para mostrar en el mensaje
                Jugador jug1 = competenciaGlobal.buscarJugador(id1);
                Jugador jug2 = competenciaGlobal.buscarJugador(id2);

                String nombresJugadores;
                if (jug1 != null && jug2 != null) {
                    nombresJugadores = jug1.getNombre() + " " + jug1.getApellido() + " vs " + jug2.getNombre() + " " + jug2.getApellido();
                } else {
                    // Fallback: usar los nombres del ComboBox si no se encuentran los jugadores
                    String nombre1 = jugador1Selected.split(" - ")[1];
                    String nombre2 = jugador2Selected.split(" - ")[1];
                    nombresJugadores = nombre1 + " vs " + nombre2;
                }

                JOptionPane.showMessageDialog(dialog,
                        "Partida multijugador registrada exitosamente:\n" +
                                "ID: " + par.getIdPartida() + "\n" +
                                "Jugadores: " + nombresJugadores,
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "El ID de partida debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error al registrar partida: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelarBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(guardarBtn);
        buttonPanel.add(cancelarBtn);

        gbc.gridx = 0; gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        dialog.add(buttonPanel, gbc);

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    // MEJORADO: Método para registrar partida contra máquina
    private void registrarPartidaMaquina(){
        // Verificar si hay jugadores registrados
        if (competenciaGlobal.getJugadores().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay jugadores registrados. Primero debe registrar jugadores.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JDialog dialog = new JDialog(this, "Registrar Partida contra Máquina", true);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Campos del formulario
        JTextField idPartida = new JTextField(20);
        JTextField observacion = new JTextField(20);

        // MEJORADO: ComboBox para seleccionar jugador registrado
        JComboBox<String> jugadorComboBox = new JComboBox<>();

        // Llenar el ComboBox con jugadores registrados
        for (Jugador jugador : competenciaGlobal.getJugadores()) {
            String jugadorInfo = "ID: " + jugador.getIdJugador() + " - " + jugador.getNombre() + " " + jugador.getApellido();
            jugadorComboBox.addItem(jugadorInfo);
        }

        // Campo de fecha (solo lectura, se asigna automáticamente)
        JTextField fechaField = new JTextField(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")), 20);
        fechaField.setEnabled(false);
        fechaField.setBackground(Color.LIGHT_GRAY);

        // Layout del formulario
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        dialog.add(new JLabel("Ingrese id de la partida:"), gbc);
        gbc.gridx = 1;
        dialog.add(idPartida, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        dialog.add(new JLabel("Ingrese su observación:"), gbc);
        gbc.gridx = 1;
        dialog.add(observacion, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        dialog.add(new JLabel("Seleccione Jugador:"), gbc);
        gbc.gridx = 1;
        dialog.add(jugadorComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        dialog.add(new JLabel("Fecha de Registro:"), gbc);
        gbc.gridx = 1;
        dialog.add(fechaField, gbc);

        // Botones
        JPanel buttonPanel = new JPanel();
        JButton guardarBtn = new JButton("Guardar");
        JButton cancelarBtn = new JButton("Cancelar");

        guardarBtn.addActionListener(e -> {
            try {
                // Validaciones
                String idText = idPartida.getText().trim();
                String obs = observacion.getText().trim();

                if (idText.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "El ID de partida es obligatorio.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (obs.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "La observación es obligatoria.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!esSoloLetras(obs)) {
                    JOptionPane.showMessageDialog(dialog, "La observación solo puede contener letras.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // MEJORADO: Extraer ID del jugador seleccionado
                String jugadorSelected = (String) jugadorComboBox.getSelectedItem();

                if (jugadorSelected == null) {
                    JOptionPane.showMessageDialog(dialog, "Debe seleccionar un jugador.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Extraer el ID de la cadena seleccionada
                int idJug = Integer.parseInt(jugadorSelected.split(" - ")[0].replace("ID: ", ""));

                // Verificar que el ID de partida no exista ya
                int id = Integer.parseInt(idText);
                if (competenciaGlobal.buscarPartidaPorId(id) != null) {
                    JOptionPane.showMessageDialog(dialog, "Ya existe una partida con ese ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Crear partida contra máquina
                int puntaje1 = 0;
                int puntaje2 = 0;

                Partida par = new Partida(id, puntaje1, puntaje2, LocalDateTime.now(), obs, Contrincante.MAQUINA, EstadoEnfrentamiento.EMPATE);

                // Registrar la partida
                competenciaGlobal.registrarPartida(par);

                // Obtener nombre del jugador para mostrar en el mensaje
                Jugador jugador = competenciaGlobal.buscarJugador(idJug);

                String nombreJugador;
                if (jugador != null) {
                    nombreJugador = jugador.getNombre() + " " + jugador.getApellido();
                } else {
                    // Fallback: usar el nombre del ComboBox si no se encuentra el jugador
                    nombreJugador = jugadorSelected.split(" - ")[1];
                }

                JOptionPane.showMessageDialog(dialog,
                        "Partida contra máquina registrada exitosamente:\n" +
                                "ID: " + par.getIdPartida() + "\n" +
                                "Jugador: " + nombreJugador + " vs Máquina",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "El ID de partida debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Error al registrar partida: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelarBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(guardarBtn);
        buttonPanel.add(cancelarBtn);

        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        dialog.add(buttonPanel, gbc);

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void initializeWindow() {
        setTitle("Crear Partida - CheckMate");
        setContentPane(mainPanel3);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(parentWindow1);
        setResizable(false);
    }

    private void setupComponents() {
        // Configuración de estilos
        textCrearPartida.setFont(new Font("Arial", Font.BOLD, 24));
        textCrearPartida.setHorizontalAlignment(SwingConstants.CENTER);

        // Configuración de botones
        buttonPartidaMaqui.setFont(new Font("Arial", Font.PLAIN, 16));
        buttonPartidaMulti.setFont(new Font("Arial", Font.PLAIN, 16));
        buttonVolver3.setFont(new Font("Arial", Font.PLAIN, 16));
    }

    public static void showCrearPartida(JFrame parent) {
        SwingUtilities.invokeLater(() -> {
            CrearPartida gestionPartidas = new CrearPartida(parent);
            parent.setVisible(false);
            gestionPartidas.setVisible(true);
        });
    }
}