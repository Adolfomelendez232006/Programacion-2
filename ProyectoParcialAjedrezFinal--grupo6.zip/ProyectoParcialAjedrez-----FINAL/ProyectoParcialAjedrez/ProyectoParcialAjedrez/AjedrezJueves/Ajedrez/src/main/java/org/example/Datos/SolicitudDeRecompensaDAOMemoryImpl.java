package org.example.Datos;

import org.example.dominio.EstadoDeSolicitud;
import org.example.dominio.Recompensa;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SolicitudDeRecompensaDAOMemoryImpl implements SolicitudDeRecompensaDAO{
    private static EstadoDeSolicitud estado;
    private static Recompensa recompensa; // Corregido: debe ser tipo Recompensa, no String
    private static LocalDateTime fechaDeSolicitud;
    private static String ultimoMensaje;

    @Override
    public boolean crearSolicitud(Recompensa recompensa) {
        if (recompensa == null) {
            this.ultimoMensaje = "La recompensa no puede ser nula";
            return false;
        }

        this.recompensa = recompensa;
        this.estado = EstadoDeSolicitud.PENDIENTE;
        this.fechaDeSolicitud = LocalDateTime.now();


        this.ultimoMensaje = String.format("Recompensa solicitada: %s\nFecha de solicitud: %s",
                recompensa.getNombre(),
                fechaDeSolicitud.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));

        return true;
    }

    @Override
    public boolean rechazarSolicitud(String motivoDeRechazo) {
        if (this.estado == EstadoDeSolicitud.PENDIENTE) {
            this.estado = EstadoDeSolicitud.RECHAZADA;
            this.ultimoMensaje = String.format("Solicitud rechazada");
        }
        return true;
    }

    @Override
    public boolean aprobarSolicitud() {
        if (this.estado != EstadoDeSolicitud.PENDIENTE) {
            this.ultimoMensaje = "Solo se pueden aprobar solicitudes en estado PENDIENTE";
            return false;
        }

        this.estado = EstadoDeSolicitud.APROBADA;
        this.ultimoMensaje = String.format("Solicitud aprobada exitosamente.");
        return true;
    }

    @Override
    public boolean procesarSolicitud() {
        if (this.estado != EstadoDeSolicitud.APROBADA) {
            this.ultimoMensaje = "Solo se pueden procesar solicitudes APROBADAS";
            return false;
        }

        this.estado = EstadoDeSolicitud.PROCESADA;
        this.ultimoMensaje = "Solicitud procesada exitosamente.\nLa recompensa ha sido entregada al solicitante.";

        return true;
    }

    @Override
    public String estadoDeSolicitud() {
        StringBuilder info = new StringBuilder();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        info.append(" ESTADO DE SOLICITUD \n");
        info.append("Estado actual: ").append(this.estado.getNombre()).append("\n");
        info.append("Descripción: ").append(this.estado.getDescripcion()).append("\n");
        info.append("Fecha de solicitud: ").append(this.fechaDeSolicitud.format(formatter)).append("\n");

        if (this.recompensa != null) {
            info.append("Recompensa solicitada: ").append(this.recompensa.getNombre()).append("\n");
            info.append("Puntos: ").append(this.recompensa.getPuntos()).append("\n");
        } else {
            info.append("Recompensa: No especificada\n");
        }
        return info.toString();
    }

    @Override
    public boolean estaPendiente() {return this.estado == EstadoDeSolicitud.PENDIENTE;}

    @Override
    public boolean estaAprobado() {return this.estado == EstadoDeSolicitud.APROBADA;}

    @Override
    public boolean estRechazada() {return this.estado == EstadoDeSolicitud.RECHAZADA;}

    @Override
    public boolean estaProcesada() {return this.estado == EstadoDeSolicitud.PROCESADA;}
}
