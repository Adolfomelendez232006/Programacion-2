package org.example.dominio;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;

class JugadorTest {

    @Test
    void getIDJugador() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        //jugador.setIdJugador(2);

        assertEquals(2, jugador.getIdJugador(), "El ID del jugador no se actualizó correctamente");
    }

    @Test
    void setiDJugador() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        //jugador.setIdJugador(2);

        assertEquals(2, jugador.getIdJugador(), "El ID del jugador no se actualizó correctamente");
    }

    @org.junit.jupiter.api.Test
    void getNombre() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        jugador.setNombre("A");

        assert jugador.getNombre().equals("A"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void setNombre() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        jugador.setNombre("N");

        assert jugador.getNombre().equals("N"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void getApellido() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        jugador.setApellido("A");

        assert jugador.getApellido().equals("A"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void setApellido() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        jugador.setApellido("A");

        assert jugador.getApellido().equals("A"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void getConocimientoDeJuego() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        jugador.setConocimientoDeJuego("M");

        assert jugador.getConocimientoDeJuego().equals("M"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void setConocimientoDeJuego() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        jugador.setConocimientoDeJuego("M");

        assert jugador.getConocimientoDeJuego().equals("M"):"Prueba erronea";
    }

    @org.junit.jupiter.api.Test
    void getFechaDeRegistro() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        jugador.setFechaDeRegistro();

        assert jugador.getFechaDeRegistro() != null:"Fecha incorrecta";
    }

    @org.junit.jupiter.api.Test
    void setFechaDeRegistro() {
        Jugador jugador = new Jugador(123,"Francisco","Salas","Medio", LocalDateTime.now(),Genero.MASCULINO);
        jugador.setFechaDeRegistro();

        assert jugador.getFechaDeRegistro() != null:"Fecha incorrecta";
    }

}