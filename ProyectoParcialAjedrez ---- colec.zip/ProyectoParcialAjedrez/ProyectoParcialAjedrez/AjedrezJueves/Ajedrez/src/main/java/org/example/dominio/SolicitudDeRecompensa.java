package org.example.dominio;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class SolicitudDeRecompensa {
    private EstadoDeSolicitud estado;
    private Recompensa recompensa; // Corregido: debe ser tipo Recompensa, no String
    private LocalDateTime fechaDeSolicitud;
    private String ultimoMensaje;

    //metodo constructor
    public SolicitudDeRecompensa(){
        this.estado = EstadoDeSolicitud.PENDIENTE;
        this.recompensa = getRecompensa();
        this.fechaDeSolicitud = LocalDateTime.now();

    }
    public SolicitudDeRecompensa(EstadoDeSolicitud estado, Recompensa recompensa){
        this.estado = estado;
        this.recompensa = recompensa;
        this.fechaDeSolicitud = LocalDateTime.now();

    }
    // Constructor con argumentos
    public SolicitudDeRecompensa( Recompensa recompensa) {
        if (recompensa == null){
            String mensaje = String.format("La recompensa no puede ser nula");
        }
        this.estado = EstadoDeSolicitud.PENDIENTE;
        this.recompensa = recompensa;
        this.fechaDeSolicitud = LocalDateTime.now();

    }
    /**
     * Metodo para crear una nueva solicitud
     */
    public boolean crearSolicitud(Recompensa recompensa) {
        if (recompensa == null) {
            this.ultimoMensaje = "La recompensa no puede ser nula";
            return false;
        }

        this.recompensa = recompensa;
        this.estado = EstadoDeSolicitud.PENDIENTE;
        this.fechaDeSolicitud = LocalDateTime.now();


        this.ultimoMensaje = String.format("Recompensa solicitada: %s\nFecha de solicitud: %s",
                recompensa.getNombre(),
                fechaDeSolicitud.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));

        return true;
    }

    /**
     * Metodo para rechazar la solicitud
     */
    public boolean rechazarSolicitud(String motivoDeRechazo) {
        if (this.estado == EstadoDeSolicitud.PENDIENTE) {
            this.estado = EstadoDeSolicitud.RECHAZADA;
            this.ultimoMensaje = String.format("Solicitud rechazada");
        }
        return true;
    }

    /**
     * Metodo para aprobar la solicitud
     */
    public boolean aprobarSolicitud() {
        if (this.estado != EstadoDeSolicitud.PENDIENTE) {
            this.ultimoMensaje = "Solo se pueden aprobar solicitudes en estado PENDIENTE";
            return false;
        }

        this.estado = EstadoDeSolicitud.APROBADA;


        this.ultimoMensaje = String.format("Solicitud aprobada exitosamente.");

        return true;
    }
    /**
     * Metodo para procesar la solicitud (marcarla como procesada después de ser aprobada)
     */
    public boolean procesarSolicitud() {
        if (this.estado != EstadoDeSolicitud.APROBADA) {
            this.ultimoMensaje = "Solo se pueden procesar solicitudes APROBADAS";
            return false;
        }

        this.estado = EstadoDeSolicitud.PROCESADA;
        this.ultimoMensaje = "Solicitud procesada exitosamente.\nLa recompensa ha sido entregada al solicitante.";

        return true;
    }

    /**
     * Metodo para obtener el estado de la solicitud con información detallada
     */
    public String estadoDeSolicitud() {
        StringBuilder info = new StringBuilder();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        info.append(" ESTADO DE SOLICITUD \n");
        info.append("Estado actual: ").append(this.estado.getNombre()).append("\n");
        info.append("Descripción: ").append(this.estado.getDescripcion()).append("\n");
        info.append("Fecha de solicitud: ").append(this.fechaDeSolicitud.format(formatter)).append("\n");

        if (this.recompensa != null) {
            info.append("Recompensa solicitada: ").append(this.recompensa.getNombre()).append("\n");
            info.append("Puntos: ").append(this.recompensa.getPuntos()).append("\n");
        } else {
            info.append("Recompensa: No especificada\n");
        }
        return info.toString();
    }
    // Metodos getters y  setters
    public EstadoDeSolicitud getEstado() {
        return estado;
    }

    public void setEstado(EstadoDeSolicitud estado) {
        this.estado = estado;
    }

    // retorna Recompensa, no String
    public Recompensa getRecompensa() {
        return recompensa;
    }

    // parámetro de tipo Recompensa
    public void setRecompensa(Recompensa recompensa) {
        this.recompensa = recompensa;
    }

    // nombre del metodo más descriptivo
    public LocalDateTime getFechaDeSolicitud() {
        return fechaDeSolicitud;
    }

    // nombre del parámetro
    public void setFechaDeSolicitud(LocalDateTime fechaDeSolicitud) {
        this.fechaDeSolicitud = fechaDeSolicitud;
    }

    public String getUltimoMensaje() {
        return ultimoMensaje;
    }
    /**
     * Metodo para verificar si la solicitud está pendiente
     */
    public boolean estaPendiente() {
        return this.estado == EstadoDeSolicitud.PENDIENTE;
    }

    /**
     * Metodo para verificar si la solicitud fue aprobada
     */
    public boolean estaAprobada() {
        return this.estado == EstadoDeSolicitud.APROBADA;
    }

    /**
     * Metodo para verificar si la solicitud fue rechazada
     */
    public boolean estaRechazada() {
        return this.estado == EstadoDeSolicitud.RECHAZADA;
    }

    /**
     * Metodo para verificar si la solicitud fue procesada
     */
    public boolean estaProcesada() {
        return this.estado == EstadoDeSolicitud.PROCESADA;
    }

    @Override
    public String toString() {
        return String.format(
                "╔═══════════════════════════════════╗%n" +
                "║      SOLICITUD DE RECOMPENSA      ║%n" +
                "╠═══════════════════════════════════╣%n" +
                "║ Estado: %-25s ║%n" +
                "║ Fecha:  %-25s ║%n" +
                "╚═══════════════════════════════════╝",
                estado.getNombre(),
                fechaDeSolicitud.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))
        );
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        SolicitudDeRecompensa that = (SolicitudDeRecompensa) obj;
        return Objects.equals(fechaDeSolicitud, that.fechaDeSolicitud) &&
                Objects.equals(recompensa, that.recompensa) &&
                estado == that.estado;
    }

    @Override
    public int hashCode() {
        return Objects.hash(fechaDeSolicitud, recompensa, estado);
    }

    public int getId() {
        return 0;
    }
}