package org.example.Datos;

public class RecompensaDAOMemoryImpl implements RecompensaDAO{
    private static String nombre;
    private static String descripcion;
    private static int puntos;
    private static String nombreNormalizado;

    @Override
    public String mostrarMensaje() {
        if (!nombre.isEmpty()) {
            return "Tiene " + puntos + " puntos por ser " + nombre.toLowerCase();
        }
        return "";
    }

    @Override
    public String completarLogro(String nombre) {
        return "";
    }

    @Override
    public void reiniciarLogro() {

    }

    @Override
    public boolean estaPendiente() {
        return false;
    }

    @Override
    public void asignarDescripcionPorDefecto() {
        switch (this.nombreNormalizado) {
            case "ganador":
                this.descripcion = "¡Felicitaciones! Has ganado la partida";
                break;
            case "empate":
                this.descripcion = "Buen juego, ha sido un empate";
                break;
            case "perdedor":
                this.descripcion = "Sigue intentando, la próxima será mejor";
                break;
            default:
                this.descripcion = "Recompensa personalizada";
        }
    }
}
