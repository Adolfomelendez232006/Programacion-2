package org.example.dominio;

public enum EstadoEnfrentamiento {
    SIN_JUGAR("Sin jugar"),
    GANADOR_JUGADOR1("Ganó Jugador 1"),
    GANADOR_JUGADOR2("Ganó Jugador 2"),
    EMPATE("Empate");

    private final String descripcion;

    EstadoEnfrentamiento(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
