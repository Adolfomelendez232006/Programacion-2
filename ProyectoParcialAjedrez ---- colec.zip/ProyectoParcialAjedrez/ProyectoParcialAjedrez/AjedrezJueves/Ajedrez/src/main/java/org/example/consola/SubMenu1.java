package org.example.consola;

import org.example.dominio.Competencia;
import org.example.dominio.Genero;
import org.example.dominio.Jugador;
import org.example.dominio.Tutorial;
import org.example.util.Validador;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
/**
 * Clase que muestra el submenú para gestionar competencias.
 * Desde aquí se puede crear un torneo o ver un tutorial relacionado.
 */
/*public class SubMenu1 {
    private static final String FORMATO_FECHA = "yyyy-MM-dd";
    /**
     * Método que muestra el submenú de gestión de competencias.
     * Permite al usuario crear un torneo con nombre y fechas, o ver un tutorial.
     *
     * @return retorna null porque no se necesita devolver nada en este caso.

    public static Date subMenu1(String[] args) {
        /**
         * Método que muestra el submenú de gestión de competencias.
         * Permite al usuario crear un torneo con nombre y fechas, o ver un tutorial.
         *
         * @return retorna null porque no se necesita devolver nada en este caso.

            Scanner leer = new Scanner(System.in);
            boolean val = true, val1 = true;
            int op;

            while (val1 == true) {
                System.out.println("");
                System.out.printf("╔════════════════════════════════════════╗%n");
                System.out.printf("║         🏆 GESTIONAR COMPETENCIA 🏆    ║%n");
                System.out.printf("╠════════════════════════════════════════╣%n");
                System.out.printf("║  %d. %-32s ║%n", 1, "🎯 Crear Torneo");
                System.out.printf("║  %d. %-32s ║%n", 2, "📚 Tutorial");
                System.out.printf("║  %d. %-32s ║%n", 3, "🚪 Salir");
                System.out.printf("╚════════════════════════════════════════╝%n");
                System.out.printf("➤ Ingrese su opción: ");
                op = Validador.pedirNumero(leer);
                System.out.println("");
                switch (op) {
                    case 1:
                        System.out.println("H0.1. Crear Torneo");
                        String nombreTorneo;
                        while (true) {
                            System.out.print("Ingrese el nombre del torneo: ");
                            nombreTorneo = Validador.pedirNombre(leer);
                            leer.nextLine();

                            // Validaciones previas al constructor
                            if (nombreTorneo == null || nombreTorneo.trim().isEmpty()) {
                                System.out.println("Error: El nombre no puede estar vacío.");
                            } else if (!nombreTorneo.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")) {
                                System.out.println("Error: El nombre solo puede contener letras.");
                            } else if (nombreTorneo.length() < 2) {
                                System.out.println("Error: El nombre debe tener al menos 2 caracteres.");
                            } else {
                                break;
                            }
                        }

                        Date fechaInicio = leerFecha(leer, "Ingrese fecha inicio (formato: yyyy-MM-dd): ");
                        Date fechaFin;

                        do {
                            fechaFin = leerFecha(leer, "Ingrese fecha fin (formato: yyyy-MM-dd): ");
                            if (fechaFin.before(fechaInicio)) {
                                System.out.println("Error: La fecha de fin no puede ser anterior a la fecha de inicio.");
                            }
                        } while (fechaFin.before(fechaInicio));


                        Competencia comp = null;
                        try {
                            comp = Competencia.getInstancia();
                        } catch (IllegalArgumentException e) {
                            System.out.println("Error al crear el torneo: " + e.getMessage());
                            return null;
                        }

                        break;
                    case 2:
                        System.out.println("H0.2. Tutorial");
                        Tutorial tutorial = new Tutorial();
                        tutorial.establecerTutorial(); // Establece el contenido
                        //System.out.println(tutorial.mostrarTutorial());
                        boolean verTutorial = true;
                        while (verTutorial) {
                            System.out.printf("%n╔════════════════════════════════════════╗%n");
                            System.out.printf("║            📚 TUTORIAL 📚             ║%n");
                            System.out.printf("╠════════════════════════════════════════╣%n");
                            System.out.printf("║  %d. %-32s ║%n", 1, "👀 Ver tutorial");
                            System.out.printf("║  %d. %-32s ║%n", 2, "✏️ Editar sección");
                            System.out.printf("║  %d. %-32s ║%n", 3, "🗑️ Eliminar contenido");
                            System.out.printf("║  %d. %-32s ║%n", 4, "🔙 Salir");
                            System.out.printf("╚════════════════════════════════════════╝%n");
                            System.out.printf("⚡ Elige una opción: ");
                            int opcionTutorial = Validador.pedirNumero(leer);

                            switch (opcionTutorial) {
                                case 1:
                                    Tutorial.mostrarIntroduccion();
                                    System.out.println(tutorial.mostrarTutorial());
                                    break;
                                case 2:
                                    System.out.print("¿Qué sección deseas editar? (piezas, fundamentos, intermedio, avanzado): ");
                                    leer.nextLine(); // limpiar buffer
                                    String seccion = leer.nextLine();
                                    System.out.print("Nuevo contenido: ");
                                    String nuevo = leer.nextLine();
                                    System.out.println(tutorial.editarTutorial(seccion, nuevo));
                                    break;
                                case 3:
                                    tutorial.eliminarTutorial();
                                    System.out.println("Contenido del tutorial eliminado.");
                                    break;
                                case 4:
                                    verTutorial = false;
                                    break;
                                default:
                                    System.out.println("Opción inválida.");
                            }
                        }
                        break;
                    case 3:
                        val1 = false;
                        break;
                }
            }
            return null;
    }
    /**
     * Metodo que permite al usuario ingresar una fecha desde teclado y valida que esté en el formato correcto (yyyy-MM-dd).
     *
     * @param scanner objeto Scanner para leer la entrada del usuario.
     * @param mensaje mensaje que se muestra al usuario.
     * @return la fecha ingresada convertida a formato SQL.

    public static java.sql.Date leerFecha(Scanner scanner, String mensaje) {
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
        formato.setLenient(false);
        java.util.Date fechaUtil = null;

        while (fechaUtil == null) {
            System.out.print(mensaje);
            String entrada = scanner.nextLine();

            try {
                fechaUtil = formato.parse(entrada);
            } catch (ParseException e) {
                System.out.println("Fecha inválida. Debe tener el formato yyyy-MM-dd.");
            }
        }

        return new java.sql.Date(fechaUtil.getTime());
    }
}*/