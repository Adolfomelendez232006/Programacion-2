package org.example.Datos;

import org.example.dominio.Contrincante;
import org.example.dominio.EstadoEnfrentamiento;
import org.example.dominio.Jugador;
import org.example.dominio.Partida;

import java.time.LocalDateTime;

public class PartidaDAOMemoryImpl implements PartidaDAO {
    private static Partida[] partidas;
    private static int numPartidas;
    private static Jugador[] jugadores;
    private static int numJugadores;
    private static Jugador jugador1;
    private static Jugador jugador2;
    private static Jugador ganador;
    private static EstadoEnfrentamiento estado;
    private static int puntajeJugador1;
    private static int puntajeJugador2;

    static {
        partidas = new Partida[3];
        numPartidas = 0;
        jugadores = new Jugador[2];
        numJugadores = 0;
        jugador1 = new Jugador();
        jugador2 = new Jugador();
        ganador = new Jugador();
        puntajeJugador1 = 0;
        puntajeJugador2 = 0;
    }

    @Override
    public String crearPartidaMaquina() {
        return "Partida contra la maquina";
    }

    @Override
    public String crearPartidaMaquina(String soPartida) {
        return "Partida contra la maquina";
    }

    @Override
    public String crearPartidaMultijugador() {
        if (jugadores.length < 2) {
            return "Es necesario que participen 2 jugadores.";
        }
        return "";
    }

    @Override
    public String crearPartidaMultijugador(String soPartida) {
        if (jugadores.length < 2) {
            return "Es necesario que participen 2 jugadores.";
        }
        return soPartida;
    }

    @Override
    public String registrarPartida(int idPartida, int punJ1, int punJ2, String obs,
                                   LocalDateTime fecha, EstadoEnfrentamiento estado, String contrincante) {
        // Expandir arreglo si es necesario
        if (numPartidas == partidas.length) {
            Partida[] partiaux = partidas;
            partidas = new Partida[numPartidas + 10];
            System.arraycopy(partiaux, 0, partidas, 0, numPartidas);
        }

        partidas[numPartidas] = new Partida(punJ1, punJ2, fecha, obs, Contrincante.SINCONTRINCANTE, EstadoEnfrentamiento.SIN_JUGAR);
        numPartidas++;
        return "Partida registrada con éxito";
    }

    @Override
    public String registrarPartida(Partida partida) {
        if (partida == null) {
            return "Error: La partida no puede ser null";
        }

        if (numPartidas == partidas.length) {
            Partida[] partiaux = partidas;
            partidas = new Partida[numPartidas + 10];
            System.arraycopy(partiaux, 0, partidas, 0, numPartidas);
        }

        partidas[numPartidas] = partida;
        numPartidas++;
        return "Partida registrada desde objeto: ID " + partida.getIdPartida();
    }

    @Override
    public String consultarPartida() {
        String resultado = "";
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i] != null) {
                resultado += "\n" + partidas[i].toString() + "\n\n";
            }
        }
        if (resultado.equals("")) {
            return "No hay partidas registradas.";
        }
        return resultado;
    }

    @Override
    public String consultarPartida(Partida partida) {
        String resultado = "";
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i] != null) {
                resultado += "\n" + partidas[i].toString() + "\n\n";
            }
        }
        if (resultado.equals("")) {
            return "No hay partidas registradas.";
        }
        return resultado;
    }

    @Override
    public int buscarPartidaPorId(int id) {
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i].getIdPartida() == id) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int buscarPartidaPorId(int id, Partida partida) {
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i].getIdPartida() == id) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void editarPartida(int indice, int idPartida, int puntajeJugador1, int puntajeJugador2,
                              String observaciones, LocalDateTime fecha) {
        if (indice < 0 || indice >= numPartidas) {
            System.out.println("Índice de partida no válido.");
            return;
        }

        try {
            partidas[indice] = new Partida(puntajeJugador1, puntajeJugador2, fecha, observaciones, Contrincante.SINCONTRINCANTE, EstadoEnfrentamiento.SIN_JUGAR);
            System.out.println("Partida modificada correctamente.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error al modificar la partida: " + e.getMessage());
        }
    }

    @Override
    public boolean eliminarPartida(int id) {
        for (int i = 0; i < numPartidas; i++) {
            if (partidas[i].getIdPartida() == id) {
                // Desplazar las partidas a la izquierda
                for (int j = i; j < numPartidas - 1; j++) {
                    partidas[j] = partidas[j + 1];
                }
                partidas[numPartidas - 1] = null;
                numPartidas--;
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean eliminarPartida(int id, Partida partida) {
        return eliminarPartida(id);
    }

    @Override
    public String asignarEmpate() {
        this.estado = EstadoEnfrentamiento.EMPATE;
        this.puntajeJugador1 = 0;
        this.puntajeJugador2 = 0;
        return "Resultado asignado: Empate";
    }

    @Override
    public String asignarResultadoConPuntaje(int puntajeJ1, int puntajeJ2) {
        this.puntajeJugador1 = puntajeJ1;
        this.puntajeJugador2 = puntajeJ2;

        if (puntajeJ1 > puntajeJ2) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR1;
            this.ganador = jugador1;
        } else if (puntajeJ2 > puntajeJ1) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR2;
            this.ganador = jugador2;
        } else {
            this.estado = EstadoEnfrentamiento.EMPATE;
            this.ganador = null;
        }

        return "Resultado asignado con puntajes: " + puntajeJ1 + " - " + puntajeJ2;
    }

    @Override
    public String asignarGanador(Jugador nombreGanador) {
        if (jugador1 == null || jugador2 == null) {
            throw new IllegalArgumentException("Los jugadores deben estar asignados antes de determinar un ganador.");
        }

        String nombreJ1 = jugador1.getNombre() + " " + jugador1.getApellido();
        String nombreJ2 = jugador2.getNombre() + " " + jugador2.getApellido();
        String nombreGanadorCompleto = nombreGanador.getNombre() + " " + nombreGanador.getApellido();

        if (nombreGanadorCompleto.equals(nombreJ1)) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR1;
            this.ganador = jugador1;
            this.puntajeJugador1 = 1;
            this.puntajeJugador2 = 0;
            return "Resultado asignado: Ganador - " + nombreJ1;
        } else if (nombreGanadorCompleto.equals(nombreJ2)) {
            this.estado = EstadoEnfrentamiento.GANADOR_JUGADOR2;
            this.ganador = jugador2;
            this.puntajeJugador1 = 0;
            this.puntajeJugador2 = 1;
            return "Resultado asignado: Ganador - " + nombreJ2;
        } else {
            throw new IllegalArgumentException("El jugador ganador debe ser uno de los participantes del enfrentamiento.");
        }
    }

    @Override
    public String asignarResultados(String resultado) {
        if (resultado == null) {
            return "Resultado no válido.";
        }

        if (jugador1 == null || jugador2 == null) {
            return "Los jugadores deben estar asignados antes de asignar resultados.";
        }

        String nombreJ1 = jugador1.getNombre() + " " + jugador1.getApellido();
        String nombreJ2 = jugador2.getNombre() + " " + jugador2.getApellido();

        if (resultado.equals(nombreJ1)) {
            asignarGanador(jugador1);
        } else if (resultado.equals(nombreJ2)) {
            asignarGanador(jugador2);
        } else if (resultado.equalsIgnoreCase("Empate")) {
            asignarEmpate();
        } else {
            return "Resultado no válido.";
        }
        return "Resultado asignado correctamente";
    }

    @Override
    public boolean validarDuplicadoJugador() {
        if (jugadores == null || numJugadores <= 1) {
            return false;
        }

        for (int i = 0; i < numJugadores; i++) {
            if (jugadores[i] == null) continue;

            for (int j = i + 1; j < numJugadores; j++) {
                if (jugadores[j] == null) continue;

                if (jugadores[i].equals(jugadores[j])) {
                    return true;
                }
            }
        }
        return false;
    }

}
