package org.example.dominio;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * Esta clase representa una competencia o torneo.
 * Aquí se guarda la información del torneo, como su nombre, las fechas,
 * los participantes y los enfrentamientos que se generan.
 */
public class Competencia {
    private String nombreTorneo;
    private Date fechaInicio;
    private Date fechaFin;
    private boolean iniciada;
    private boolean finalizada;
    private EstadoCompetencia estado;
    // Contador estático para llevar el control de competencias creadas
    private static int contadorCompetencias = 0;
    // Instancia única para el patrón Singleton
    private static Competencia instancia = null; // = new Competencia();
    // ID único de la competencia (final, se asigna una sola vez)
    private final int idCompetencia;
    // Arreglos para manejar las entidades relacionadas
    public List<Jugador> jugadores;
    private List<Partida> partidas;

    // Contadores para llevar el control de elementos actuales
    private int numJugadores = 0;
    private int numEnfrentamientos;
    private int numRecompensas;
    private int numPartidas;

    public Competencia(){
        this("Sin nombre de Torneo",new Date(),new Date());
    }
    // Métodos Singleton
    /**public static Competencia getInstancia() {
     return instancia;
     }**/
    public static synchronized Competencia getInstancia() {
        if (instancia == null) {
            instancia = new Competencia();
        }
        return instancia;
    }
    /**
     * Constructor para crear una competencia.
     * Verifica que el nombre y las fechas sean válidas antes de guardar.
     *
     * @param nombreTorneo nombre del torneo.
     * @param fechaInicio  cuándo empieza el torneo.
     * @param fechaFin     cuándo termina el torneo.
     */
    public Competencia(String nombreTorneo, Date fechaInicio, Date fechaFin) {
        if (nombreTorneo == null || nombreTorneo.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        nombreTorneo = nombreTorneo.trim().replaceAll("\\s+", " ");
        if (!nombreTorneo.matches("[\\p{L}0-9\\s\\-()\\.]+")) {
            throw new IllegalArgumentException("El nombre solo puede contener letras, números, espacios y algunos símbolos como guiones.");
        }

        if (nombreTorneo.length() < 2) {
            throw new IllegalArgumentException("El nombre debe tener al menos 2 caracteres.");
        }

        this.idCompetencia=++contadorCompetencias;
        this.nombreTorneo = nombreTorneo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.iniciada = false;
        this.finalizada = false;
        this.estado = EstadoCompetencia.NO_INICIADA;
        this.jugadores = new ArrayList<>();
        this.partidas = new ArrayList<>();
        inicializar();
    }

    public String inicializar(){
        StringBuilder resultado = new StringBuilder();
        try {
            registrarJugador(123,"Francisco","Salas","intermedio",LocalDateTime.now(),Genero.MASCULINO);
            registrarJugador(345,"Fernando","Rios","intermedio",LocalDateTime.now(),Genero.MASCULINO);
            registrarJugador(567,"Daniel","Salas","intermedio",LocalDateTime.now(),Genero.MASCULINO);
            registrarJugador(488, "Adolfo", "Melendez", "intermedio", LocalDateTime.now(), Genero.MASCULINO);
            registrarJugador(789, "Aylin", "Tapia", "intermedio", LocalDateTime.now(), Genero.FEMENINO);
            resultado.append("Competencia inicializada con ").append(numJugadores).append(" jugadores.");
        } catch (Exception e) {
            resultado.append("Error al inicializar jugadores: ").append(e.getMessage());
        }
        return resultado.toString();
    }

    public static void reiniciarContador() {
        contadorCompetencias = 0;
    }
    /**
     * Agrega un nuevo participante a la competencia si no ha sido agregado antes.
     *
     * @param nombre Nombre del jugador a agregar.
     */
    public void registrarJugador(int id, String nombre, String apellido, String conocimiento, LocalDateTime fecha, Genero genero) {
        if (buscarJugador(id) != null) {
            throw new IllegalArgumentException("Ya existe un jugador con este id.");
        }
        Jugador nuevoJugador = new Jugador(id, nombre, apellido, conocimiento, fecha, genero);
        jugadores.add(nuevoJugador);
    }

    public void registrarJugador(Jugador jugador) {
        if (jugador == null || jugadores.contains(jugador)) {
            throw new IllegalArgumentException("Jugador nulo o ya registrado.");
        }
        jugadores.add(jugador);
    }

    /**
     * Busca un jugador por su ID
     * @param id identifica el jugador a buscar
     * @return El jugador encontrado, o null si no existe
     */

    public Jugador buscarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores.get(i).getIdJugador() == id) {
                return jugadores.get(i);
            }
        }
        return null;
    }

    /**
     * Busca el índice de un jugador por su ID
     */
    public int buscarIndicePorId(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores.get(i).getIdJugador() == id) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Editar los datos de un jugador existente en la posicion especifica
     * @param indice posicion del jugador a editar
     * @param id nuevo Id del jugador
     * @param nombre nuevo nombre del jugador
     * @param apellido nuevo apellido del jugador
     * @param conocimiento nuevo nivel de conocimiento
     * @param fecha nueva fecha de registro
     */
    public void modificarJugador(int indice, int id, String nombre, String apellido, String conocimiento, LocalDateTime fecha, Genero genero) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        jugadores.set(indice, new Jugador(id, nombre, apellido, conocimiento, fecha, genero));
    }

    public void modificarJugador(int indice, Jugador jugador) {
        if (indice < 0 || indice >= numJugadores) {
            throw new IndexOutOfBoundsException("Índice de jugador no válido.");
        }

        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo.");
        }

        boolean idCambiado = jugadores.get(indice).getIdJugador() != jugador.getIdJugador();
        boolean idYaExiste = buscarJugador(jugador.getIdJugador()) != null;

        if (idCambiado && idYaExiste) {
            throw new IllegalArgumentException("Ya existe otro jugador con ese ID.");
        }

        jugadores.set(indice, jugador);
    }
    /**
     * Elimina un jugador de la parida por su Id
     * @param id identificador del jugador a eliminar
     * @return true si el jugador fue eliminado o false si no es encontrado
     */
    public boolean borrarJugador(int id) {
        for (int i = 0; i < numJugadores; i++) {
            if (jugadores.get(i).getIdJugador() == id) {
                // Desplazar los jugadores a la izquierda
                for (int j = i; j < numJugadores - 1; j++) {
                    jugadores.set(j, jugadores.get(j + 1));
                }
                jugadores.set(numJugadores - 1, null);
                numJugadores--;
                return true;
            }
        }
        return false;
    }
    /**
     * Agrega una partida a la competencia
     */
    public void registrarPartida(Partida partida) {
        partidas.set(numPartidas, partida);
        numPartidas++;
    }

    public Partida obtenerPartida(int indice) {
        if (indice >= 0 && indice < numPartidas) {
            return partidas.get(indice);
        }
        return null;
    }

    public void editarPartida(int indice, Partida nuevaPartida) {
        if (indice < 0 || indice >= numPartidas) {
            throw new IndexOutOfBoundsException("Índice de partida no válido.");
        }

        if (nuevaPartida == null) {
            throw new IllegalArgumentException("La partida no puede ser nula.");
        }

        for (int i = 0; i < numPartidas; i++) {
            if (i != indice && partidas.get(i).equals(nuevaPartida)) {
                throw new IllegalArgumentException("Ya existe una partida igual.");
            }
        }

        partidas.set(indice, nuevaPartida);
    }

    public boolean borrarPartida(int indice) {
        if (indice < 0 || indice >= partidas.size()) {
            return false;
        }
        partidas.remove(indice);
        return true;
    }
    public boolean validarDuplicado(Object obj) {
        if (obj == null) return false;

        // Validar duplicado de Jugador
        if (obj instanceof Jugador) {
            Jugador jugador = (Jugador) obj;
            for (int i = 0; i < numJugadores; i++) {
                if (jugadores.get(i) != null && jugadores.get(i).equals(jugador)) {
                    return true;
                }
            }
        }
        // Validar duplicado de Partida
        else if (obj instanceof Partida) {
            Partida partida = (Partida) obj;
            for (int i = 0; i < numPartidas; i++) {
                if (partidas.get(i) != null && partidas.get(i).equals(partida)) {
                    return true;
                }
            }
        }

        return false; // Si no es ninguno de los anteriores o no hay duplicado
    }

    /**
     * Método estático para obtener el número total de competencias creadas
     */
    public static int getTotalCompetenciasCreadas() {
        return contadorCompetencias;
    }
    /**
     * Inicia la competencia si aún no ha comenzado.
     * Muestra un mensaje diciendo si se pudo iniciar o si ya estaba iniciada.
     */
    public void iniciarCompetencia() {
        if (!iniciada) {
            this.iniciada = true;
            System.out.println("Competencia iniciada.");

        } else {
            System.out.println("La competencia ya estaba iniciada.");
        }
    }
    /**
     * Marca la competencia como iniciada directamente.
     */

    public void setIniciarCompetencia() {
        this.iniciada = true;
    }

    /**
     * Marca la competencia como finalizada y muestra un mensaje.
     */

    public void finalizarCompetencia() {
        this.finalizada = true;
        System.out.println("Competencia finalizada.");
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Competencia that = (Competencia) obj;
        return Objects.equals(nombreTorneo, that.nombreTorneo) &&
                Objects.equals(fechaInicio, that.fechaInicio) &&
                Objects.equals(fechaFin, that.fechaFin);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreTorneo, fechaInicio, fechaFin);
    }
    // Métodos getter y setter
    public String getNombreTorneo() {
        return nombreTorneo;
    }

    public void setNombreTorneo(String nombreTorneo) {
        this.nombreTorneo = nombreTorneo;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public boolean isIniciada() {
        return iniciada;
    }

    public boolean isFinalizada() {
        return finalizada;
    }

    public int getNumJugadores() {
        return numJugadores;
    }

    public int getNumEnfrentamientos() {
        return numEnfrentamientos;
    }

    public int getNumRecompensas() {
        return numRecompensas;
    }

    public int getNumPartidas() {
        return numPartidas;
    }

    public Jugador getJugadores(int indice) {
        if (indice >= 0 && indice < numJugadores) {
            return jugadores.get(indice);
        } else {
            return null;
        }
    }
    public List<Jugador> getJugadores() {
        return jugadores;
    }
    public List<Partida> getPartidas() {
        return partidas;
    }

    /**
     * Representación en cadena de la competencia con toda su información
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        // Encabezado principal
        sb.append("\n╔").append("═".repeat(70)).append("╗\n");
        sb.append("║").append(String.format("%70s", "INFORMACIÓN DE LA COMPETENCIA")).append("║\n");
        sb.append("╚").append("═".repeat(70)).append("╝\n\n");

        // Información básica de la competencia
        sb.append("┌").append("─".repeat(70)).append("┐\n");
        sb.append("│").append(String.format("%70s", "DATOS BÁSICOS")).append("│\n");
        sb.append("├").append("─".repeat(70)).append("┤\n");
        sb.append("│ Nombre del Torneo     : ").append(nombreTorneo);
        sb.append(" ".repeat(Math.max(0, 47 - nombreTorneo.length()))).append("│\n");
        sb.append("│ Fecha de Inicio       : ").append(fechaInicio);
        sb.append(" ".repeat(Math.max(0, 47 - fechaInicio.toString().length()))).append("│\n");
        sb.append("│ Fecha de Fin          : ").append(fechaFin);
        sb.append(" ".repeat(Math.max(0, 47 - fechaFin.toString().length()))).append("│\n");
        sb.append("│ Estado                : ").append(estado.getDescripcion());
        sb.append(" ".repeat(Math.max(0, 47 - estado.getDescripcion().length()))).append("│\n");
        sb.append("└").append("─".repeat(70)).append("┘\n\n");

        // Información de jugadores
        sb.append("┌").append("─".repeat(70)).append("┐\n");
        sb.append("│").append("JUGADORES REGISTRADOS (").append(numJugadores).append(")");
        sb.append(" ".repeat(Math.max(0, 70 - ("JUGADORES REGISTRADOS (" + numJugadores + ")").length()))).append("│\n");
        sb.append("├").append("─".repeat(70)).append("┤\n");

        if (numJugadores == 0) {
            sb.append("│").append("No hay jugadores registrados");
            sb.append(" ".repeat(70 - "No hay jugadores registrados".length())).append("│\n");
        } else {
            for (int i = 0; i < numJugadores; i++) {
                String jugadorStr = jugadores.get(i).toString();
                sb.append("│ ").append(String.format("%2d", i + 1)).append(". ").append(jugadorStr);
                int espacios = Math.max(0, 64 - jugadorStr.length());
                sb.append(" ".repeat(espacios)).append("│\n");
            }
        }
        sb.append("└").append("─".repeat(70)).append("┘\n\n");

        // Información de partidas
        sb.append("┌").append("─".repeat(70)).append("┐\n");
        sb.append("│").append("PARTIDAS (").append(numPartidas).append(")");
        sb.append(" ".repeat(Math.max(0, 70 - ("PARTIDAS (" + numPartidas + ")").length()))).append("│\n");
        sb.append("├").append("─".repeat(70)).append("┤\n");

        if (numPartidas == 0) {
            sb.append("│").append("No hay partidas registradas");
            sb.append(" ".repeat(70 - "No hay partidas registradas".length())).append("│\n");
        } else {
            for (int i = 0; i < numPartidas; i++) {
                String partidaStr = partidas.get(i).toString();
                sb.append("│ ").append(String.format("%2d", i + 1)).append(". ").append(partidaStr);
                int espacios = Math.max(0, 64 - partidaStr.length());
                sb.append(" ".repeat(espacios)).append("│\n");
            }
        }
        sb.append("└").append("─".repeat(70)).append("┘\n");

        return sb.toString();
    }


    public int compareTo(Competencia o) {
        int resultado = this.nombreTorneo.compareTo(o.getNombreTorneo());
        if(resultado>0){
            return 1;
        } else if (resultado<0) {
            return -1;
        }else
            return 0;
    }
}


