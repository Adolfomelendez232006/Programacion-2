package org.example.consola;

import java.util.Scanner;
/**
 * Clase que muestra el menú principal del programa de ajedrez.
 * Desde aquí el usuario puede ir a otros menús para gestionar diferentes partes del sistema.
 */
public class Menu {
    /**
     * Metodo principal que se ejecuta al iniciar el programa.
     * Muestra un menú con opciones y llama a otros submenús según lo que el usuario elija.
     *
     */
    public static void main(String[] args){
        Scanner leer = new Scanner(System.in);
        int op;
        boolean val = true;

        do {
            System.out.println("");
            System.out.printf("╔════════════════════════════════════╗%n");
            System.out.printf("║            MENU DE AJEDREZ         ║%n");
            System.out.printf("╠════════════════════════════════════╣%n");
            //System.out.printf("║ [1] %-30s ║%n", "Gestionar competencia");
            System.out.printf("║ [1] %-30s ║%n", "Gestionar partida");
            System.out.printf("║ [2] %-30s ║%n", "Gestionar jugador");
            System.out.printf("║ [3] %-30s ║%n", "Gestionar recompensa");
            System.out.printf("║ [4] %-30s ║%n", "Salir");
            System.out.printf("╚════════════════════════════════════╝%n");
            System.out.printf("Ingrese la opcion a la que desee acceder: ");
            op = leer.nextInt();
            System.out.println("");
            switch (op) {
                /*case 1:
                    //Menu para gestionar la competencia
                   SubMenu1.subMenu1(args);
                   break;*/
                case 1:
                    //Menu para gestionar la partida
                   SubMenu2.subMenu2(args);
                    break;
                case 2:
                    //Menu para gestionar al jugador
                    SubMenu3.subMenu3(args);
                    break;
                case 3:
                    //Menu para gestionar las recompensas
                    SubMenu4.subMenu4(args);
                    break;
                case 4:
                    System.out.println("Gracias por usar nuestro programa.");
                    val = false;
                    break;
                default:
                    System.out.println("Estos valores no son validos.");
            }
        } while (val == true);
    }
}
